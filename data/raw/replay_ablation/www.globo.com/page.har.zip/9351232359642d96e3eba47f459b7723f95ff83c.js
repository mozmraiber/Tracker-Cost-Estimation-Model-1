window.addEventListener("message", (event) => {
  if (event.data?.from === "STREAMSHOP" && event.data?.url) openStreamShopLive(event.data.url);      
}, false);