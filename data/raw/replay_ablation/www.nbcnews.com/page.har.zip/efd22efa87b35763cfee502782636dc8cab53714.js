/**/
cXJsonpCB1({"httpStatus":200,"response":{"userId":"cx:2vhjjdk9rx25z2xmzw41fbbacm:2f6lm66b2la2c","newUser":true}})