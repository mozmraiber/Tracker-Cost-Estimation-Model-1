"use strict";(function(){try{var record=function(name,detail){aps.get(accountId).queue.push(new CustomEvent(name,{detail}))};const accountId="1004";window._aps=window._aps||new Map;const aps=window._aps;aps.has(accountId)||aps.set(accountId,{queue:[],store:new Map}),record("_config/requestViewerCountry/define",{"code":"DE"});record("analytics/sampling/set",{"rates":{"error":0.001,"status":0.0001}});record("a3pes/video/activate",{"restrictions":{"block":{"accounts":["5220","e32f1423-28bc-43ed-8ab0-5ae6b4449cf8"]}}});record("a3pes/video/activate",{"bypassCountryCheck":true,"restrictions":{"allow":{"accountTypes":["ssw"]},"block":{"accounts":["e32f1423-28bc-43ed-8ab0-5ae6b4449cf8"]}}});record("a3pes/video/activate",{"bypassCountryCheck":true,"restrictions":{"allow":{"accountTypes":["mw"],"rate":0.5},"block":{"accounts":["5220"]}}});record("idVendors/enabled/set",{"bidParameterKeys":["liveintent","merkle","intimateMerger","pair","amx","33across","fTrack","captify","publink","anonymised","quantcast","idPlus","unifiedid","ddb_key_638","fabrick","uid","criteo","yahoo","liveRamp","id5","pubcommon","audigent","lightPublisherAudiences","lotame"]});record("idVendors/integration/execute",{"accountId":"1004","sourceId":"1004","countryCode":"DE","vendorId":"id5","allowedRegions":undefined,"blockedRegions":["BR"],"vendorLoadedSampleRate":5,"domainPrecedence":[],"defaultScript":function anonymous(
) {
undefined?undefined.includes("DE")&&(function anonymous(
) {
var id5PropertyId = '1431';
if (id5PropertyId && id5PropertyId.charAt(0) !== '%') {
    var id5Script = document.createElement('script');
    id5Script.src = '//cdn.id5-sync.com/api/1.0/id5-api.js';
    id5Script['onload'] = function(e) { 
        ID5.init({ partnerId: Number(id5PropertyId) , provider: 'aps' })
    };
    document.head.appendChild(id5Script);
}
})():(!["BR"]||["BR"]&&!["BR"].includes("DE"))&&(function anonymous(
) {
var id5PropertyId = '1431';
if (id5PropertyId && id5PropertyId.charAt(0) !== '%') {
    var id5Script = document.createElement('script');
    id5Script.src = '//cdn.id5-sync.com/api/1.0/id5-api.js';
    id5Script['onload'] = function(e) { 
        ID5.init({ partnerId: Number(id5PropertyId) , provider: 'aps' })
    };
    document.head.appendChild(id5Script);
}
})()
},"defaultPropertyId":"1431"});record("idVendors/integration/execute",{"accountId":"1004","sourceId":"1004","countryCode":"DE","vendorId":"liveRamp","allowedRegions":undefined,"blockedRegions":undefined,"vendorLoadedSampleRate":5,"domainPrecedence":[],"defaultScript":function anonymous(
) {
undefined?undefined.includes("DE")&&(function anonymous(
) {
(function(){if (window.apstag) {window.apstag.__liveRamp__ = false;}})();
})():(!undefined||undefined&&!undefined.includes("DE"))&&(function anonymous(
) {
(function(){if (window.apstag) {window.apstag.__liveRamp__ = false;}})();
})()
},"defaultPropertyId":"13795"});record("idVendors/integration/execute",{"accountId":"1004","sourceId":"1004","countryCode":"DE","vendorId":"lotame","allowedRegions":undefined,"blockedRegions":["BR"],"vendorLoadedSampleRate":5,"domainPrecedence":[],"defaultScript":function anonymous(
) {
undefined?undefined.includes("DE")&&(function anonymous(
) {
if (!window['lotame_sync_16576']) {
  var lotameClientId = '16576';

  initLotame(lotameClientId);
  createLotameScript(lotameClientId);

  function initLotame(propertyId) {
    var lotameConfig = {};
    var namespace = window['lotame_sync_' + propertyId] = {};
    namespace.config = lotameConfig;
    namespace.data = {};
    namespace.cmd = namespace.cmd || [];

    namespace.cmd.push(function () {
      namespace.sync();
    });
  };

  function createLotameScript(propertyId) {
    var lotameSyncUrl = "https://tags.crwdcntrl.net/lt/c/" + propertyId + "/sync.min.js";
    var lotameScriptTag = document.createElement('script');
    lotameScriptTag.src = lotameSyncUrl;
    document.head.appendChild(lotameScriptTag);
  };
}
})():(!["BR"]||["BR"]&&!["BR"].includes("DE"))&&(function anonymous(
) {
if (!window['lotame_sync_16576']) {
  var lotameClientId = '16576';

  initLotame(lotameClientId);
  createLotameScript(lotameClientId);

  function initLotame(propertyId) {
    var lotameConfig = {};
    var namespace = window['lotame_sync_' + propertyId] = {};
    namespace.config = lotameConfig;
    namespace.data = {};
    namespace.cmd = namespace.cmd || [];

    namespace.cmd.push(function () {
      namespace.sync();
    });
  };

  function createLotameScript(propertyId) {
    var lotameSyncUrl = "https://tags.crwdcntrl.net/lt/c/" + propertyId + "/sync.min.js";
    var lotameScriptTag = document.createElement('script');
    lotameScriptTag.src = lotameSyncUrl;
    document.head.appendChild(lotameScriptTag);
  };
}
})()
},"defaultPropertyId":undefined});record("idVendors/integration/execute",{"accountId":"1004","sourceId":"1004","countryCode":"DE","vendorId":"pubcommon","allowedRegions":undefined,"blockedRegions":["BR"],"vendorLoadedSampleRate":5,"domainPrecedence":[],"defaultScript":function anonymous(
) {
undefined?undefined.includes("DE")&&(function anonymous(
) {
if (!window.PublisherCommonId) {
    var pubcommonScript = document.createElement('script');
    pubcommonScript.src = '//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js';
    document.head.appendChild(pubcommonScript);
}
})():(!["BR"]||["BR"]&&!["BR"].includes("DE"))&&(function anonymous(
) {
if (!window.PublisherCommonId) {
    var pubcommonScript = document.createElement('script');
    pubcommonScript.src = '//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js';
    document.head.appendChild(pubcommonScript);
}
})()
},"defaultPropertyId":undefined});record("idVendors/integration/execute",{"accountId":"1004","sourceId":"1004","countryCode":"DE","vendorId":"liveintent","allowedRegions":undefined,"blockedRegions":["BR"],"vendorLoadedSampleRate":5,"domainPrecedence":[],"defaultScript":function anonymous(
) {
undefined?undefined.includes("DE")&&(function anonymous(
) {
(function(){if (window.apstag) {window.apstag.__liveintent__ = false;}})();
})():(!["BR"]||["BR"]&&!["BR"].includes("DE"))&&(function anonymous(
) {
(function(){if (window.apstag) {window.apstag.__liveintent__ = false;}})();
})()
},"defaultPropertyId":"001PM00000ZbEPO"});record("_config/config/didLoad",undefined)}catch(e){console.error(e)}})();
