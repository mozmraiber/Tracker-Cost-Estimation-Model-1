"use strict";
var mParticle = (function() {
  var Base64$1 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    // Input must be a string
    encode: function encode(input) {
      try {
        if (window.btoa && window.atob) {
          return window.btoa(unescape(encodeURIComponent(input)));
        }
      } catch (e) {
        console.error("Error encoding cookie values into Base64:" + e);
      }
      return this._encode(input);
    },
    _encode: function _encode(input) {
      var output = "";
      var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
      var i = 0;
      input = UTF8.encode(input);
      while (i < input.length) {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);
        enc1 = chr1 >> 2;
        enc2 = (chr1 & 3) << 4 | chr2 >> 4;
        enc3 = (chr2 & 15) << 2 | chr3 >> 6;
        enc4 = chr3 & 63;
        if (isNaN(chr2)) {
          enc3 = enc4 = 64;
        } else if (isNaN(chr3)) {
          enc4 = 64;
        }
        output = output + Base64$1._keyStr.charAt(enc1) + Base64$1._keyStr.charAt(enc2) + Base64$1._keyStr.charAt(enc3) + Base64$1._keyStr.charAt(enc4);
      }
      return output;
    },
    decode: function decode(input) {
      try {
        if (window.btoa && window.atob) {
          return decodeURIComponent(escape(window.atob(input)));
        }
      } catch (e) {
      }
      return Base64$1._decode(input);
    },
    _decode: function _decode(input) {
      var output = "";
      var chr1, chr2, chr3;
      var enc1, enc2, enc3, enc4;
      var i = 0;
      input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
      while (i < input.length) {
        enc1 = Base64$1._keyStr.indexOf(input.charAt(i++));
        enc2 = Base64$1._keyStr.indexOf(input.charAt(i++));
        enc3 = Base64$1._keyStr.indexOf(input.charAt(i++));
        enc4 = Base64$1._keyStr.indexOf(input.charAt(i++));
        chr1 = enc1 << 2 | enc2 >> 4;
        chr2 = (enc2 & 15) << 4 | enc3 >> 2;
        chr3 = (enc3 & 3) << 6 | enc4;
        output = output + String.fromCharCode(chr1);
        if (enc3 !== 64) {
          output = output + String.fromCharCode(chr2);
        }
        if (enc4 !== 64) {
          output = output + String.fromCharCode(chr3);
        }
      }
      output = UTF8.decode(output);
      return output;
    }
  };
  var UTF8 = {
    encode: function encode(s) {
      var utftext = "";
      for (var n = 0; n < s.length; n++) {
        var c = s.charCodeAt(n);
        if (c < 128) {
          utftext += String.fromCharCode(c);
        } else if (c > 127 && c < 2048) {
          utftext += String.fromCharCode(c >> 6 | 192);
          utftext += String.fromCharCode(c & 63 | 128);
        } else {
          utftext += String.fromCharCode(c >> 12 | 224);
          utftext += String.fromCharCode(c >> 6 & 63 | 128);
          utftext += String.fromCharCode(c & 63 | 128);
        }
      }
      return utftext;
    },
    decode: function decode(utftext) {
      var s = "";
      var i = 0;
      var c = 0, c1 = 0, c2 = 0;
      while (i < utftext.length) {
        c = utftext.charCodeAt(i);
        if (c < 128) {
          s += String.fromCharCode(c);
          i++;
        } else if (c > 191 && c < 224) {
          c1 = utftext.charCodeAt(i + 1);
          s += String.fromCharCode((c & 31) << 6 | c1 & 63);
          i += 2;
        } else {
          c1 = utftext.charCodeAt(i + 1);
          c2 = utftext.charCodeAt(i + 2);
          s += String.fromCharCode((c & 15) << 12 | (c1 & 63) << 6 | c2 & 63);
          i += 3;
        }
      }
      return s;
    }
  };
  var Polyfill = {
    // forEach polyfill
    // Production steps of ECMA-262, Edition 5, 15.4.4.18
    // Reference: http://es5.github.io/#x15.4.4.18
    forEach: function forEach(callback, thisArg) {
      var T, k;
      if (this == null) {
        throw new TypeError(" this is null or not defined");
      }
      var O = Object(this);
      var len = O.length >>> 0;
      if (typeof callback !== "function") {
        throw new TypeError(callback + " is not a function");
      }
      if (arguments.length > 1) {
        T = thisArg;
      }
      k = 0;
      while (k < len) {
        var kValue = void 0;
        if (k in O) {
          kValue = O[k];
          callback.call(T, kValue, k, O);
        }
        k++;
      }
    },
    // map polyfill
    // Production steps of ECMA-262, Edition 5, 15.4.4.19
    // Reference: http://es5.github.io/#x15.4.4.19
    map: function map(callback, thisArg) {
      var T, A, k;
      if (this === null) {
        throw new TypeError(" this is null or not defined");
      }
      var O = Object(this);
      var len = O.length >>> 0;
      if (typeof callback !== "function") {
        throw new TypeError(callback + " is not a function");
      }
      if (arguments.length > 1) {
        T = thisArg;
      }
      A = new Array(len);
      k = 0;
      while (k < len) {
        var kValue = void 0, mappedValue = void 0;
        if (k in O) {
          kValue = O[k];
          mappedValue = callback.call(T, kValue, k, O);
          A[k] = mappedValue;
        }
        k++;
      }
      return A;
    },
    // filter polyfill
    // Prodcution steps of ECMA-262, Edition 5
    // Reference: http://es5.github.io/#x15.4.4.20
    filter: function filter(fun) {
      if (this === void 0 || this === null) {
        throw new TypeError();
      }
      var t = Object(this);
      var len = t.length >>> 0;
      if (typeof fun !== "function") {
        throw new TypeError();
      }
      var res = [];
      var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
      for (var i = 0; i < len; i++) {
        if (i in t) {
          var val = t[i];
          if (fun.call(thisArg, val, i, t)) {
            res.push(val);
          }
        }
      }
      return res;
    },
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray
    isArray: function isArray(arg) {
      return Object.prototype.toString.call(arg) === "[object Array]";
    },
    Base64: Base64$1
  };
  var version = "2.81.0";
  var Constants = {
    sdkVersion: version,
    sdkVendor: "mparticle",
    platform: "web",
    Messages: {
      DeprecationMessages: {
        MethodHasBeenDeprecated: "has been deprecated.",
        MethodMarkedForDeprecationPostfix: "is a deprecated method and will be removed in future releases.",
        AlternativeMethodPrefix: "Please use the alternate method:"
      },
      ErrorMessages: {
        NoToken: "A token must be specified.",
        EventNameInvalidType: "Event name must be a valid string value.",
        EventDataInvalidType: "Event data must be a valid object hash.",
        LoggingDisabled: "Event logging is currently disabled.",
        CookieParseError: "Could not parse cookie",
        EventEmpty: "Event object is null or undefined, cancelling send",
        APIRequestEmpty: "APIRequest is null or undefined, cancelling send",
        NoEventType: "Event type must be specified.",
        TransactionIdRequired: "Transaction ID is required",
        TransactionRequired: "A transaction attributes object is required",
        PromotionIdRequired: "Promotion ID is required",
        BadAttribute: "Attribute value cannot be object or array",
        BadKey: "Key value cannot be object or array",
        BadLogPurchase: "Transaction attributes and a product are both required to log a purchase, https://docs.mparticle.com/?javascript#measuring-transactions",
        AudienceAPINotEnabled: "Your workspace is not enabled to retrieve user audiences."
      },
      InformationMessages: {
        CookieSearch: "Searching for cookie",
        CookieFound: "Cookie found, parsing values",
        CookieNotFound: "Cookies not found",
        CookieSet: "Setting cookie",
        CookieSync: "Performing cookie sync",
        SendBegin: "Starting to send event",
        SendIdentityBegin: "Starting to send event to identity server",
        SendWindowsPhone: "Sending event to Windows Phone container",
        SendIOS: "Calling iOS path: ",
        SendAndroid: "Calling Android JS interface method: ",
        SendHttp: "Sending event to mParticle HTTP service",
        SendAliasHttp: "Sending alias request to mParticle HTTP service",
        SendIdentityHttp: "Sending event to mParticle HTTP service",
        StartingNewSession: "Starting new Session",
        StartingLogEvent: "Starting to log event",
        StartingLogOptOut: "Starting to log user opt in/out",
        StartingEndSession: "Starting to end session",
        StartingInitialization: "Starting to initialize",
        StartingLogCommerceEvent: "Starting to log commerce event",
        StartingAliasRequest: "Starting to Alias MPIDs",
        LoadingConfig: "Loading configuration options",
        AbandonLogEvent: "Cannot log event, logging disabled or developer token not set",
        AbandonAliasUsers: "Cannot Alias Users, logging disabled or developer token not set",
        AbandonStartSession: "Cannot start session, logging disabled or developer token not set",
        AbandonEndSession: "Cannot end session, logging disabled or developer token not set",
        NoSessionToEnd: "Cannot end session, no active session found"
      },
      ValidationMessages: {
        ModifyIdentityRequestUserIdentitiesPresent: "identityRequests to modify require userIdentities to be present. Request not sent to server. Please fix and try again",
        IdentityRequesetInvalidKey: "There is an invalid key on your identityRequest object. It can only contain a `userIdentities` object and a `onUserAlias` function. Request not sent to server. Please fix and try again.",
        OnUserAliasType: "The onUserAlias value must be a function.",
        UserIdentities: "The userIdentities key must be an object with keys of identityTypes and values of strings. Request not sent to server. Please fix and try again.",
        UserIdentitiesInvalidKey: "There is an invalid identity key on your `userIdentities` object within the identityRequest. Request not sent to server. Please fix and try again.",
        UserIdentitiesInvalidValues: "All user identity values must be strings or null. Request not sent to server. Please fix and try again.",
        AliasMissingMpid: "Alias Request must contain both a destinationMpid and a sourceMpid",
        AliasNonUniqueMpid: "Alias Request's destinationMpid and sourceMpid must be unique",
        AliasMissingTime: "Alias Request must have both a startTime and an endTime",
        AliasStartBeforeEndTime: "Alias Request's endTime must be later than its startTime"
      }
    },
    NativeSdkPaths: {
      LogEvent: "logEvent",
      SetUserTag: "setUserTag",
      RemoveUserTag: "removeUserTag",
      SetUserAttribute: "setUserAttribute",
      RemoveUserAttribute: "removeUserAttribute",
      SetSessionAttribute: "setSessionAttribute",
      AddToCart: "addToCart",
      RemoveFromCart: "removeFromCart",
      ClearCart: "clearCart",
      LogOut: "logOut",
      SetUserAttributeList: "setUserAttributeList",
      RemoveAllUserAttributes: "removeAllUserAttributes",
      GetUserAttributesLists: "getUserAttributesLists",
      GetAllUserAttributes: "getAllUserAttributes",
      Identify: "identify",
      Logout: "logout",
      Login: "login",
      Modify: "modify",
      Alias: "aliasUsers",
      Upload: "upload"
    },
    StorageNames: {
      localStorageName: "mprtcl-api",
      localStorageNameV3: "mprtcl-v3",
      cookieName: "mprtcl-api",
      cookieNameV2: "mprtcl-v2",
      cookieNameV3: "mprtcl-v3",
      localStorageNameV4: "mprtcl-v4",
      localStorageProductsV4: "mprtcl-prodv4",
      cookieNameV4: "mprtcl-v4",
      currentStorageName: "mprtcl-v4",
      currentStorageProductsName: "mprtcl-prodv4"
    },
    DefaultConfig: {
      cookieDomain: null,
      cookieExpiration: 365,
      logLevel: null,
      timeout: 300,
      sessionTimeout: 30,
      maxProducts: 20,
      forwarderStatsTimeout: 5e3,
      integrationDelayTimeout: 5e3,
      maxCookieSize: 3e3,
      aliasMaxWindow: 90,
      uploadInterval: 0
      // Maximum milliseconds in between batch uploads, below 500 will mean immediate upload.  The server returns this as a string, but we are using it as a number internally
    },
    DefaultBaseUrls: {
      v1SecureServiceUrl: "jssdks.mparticle.com/v1/JS/",
      v2SecureServiceUrl: "jssdks.mparticle.com/v2/JS/",
      v3SecureServiceUrl: "jssdks.mparticle.com/v3/JS/",
      configUrl: "jssdkcdns.mparticle.com/JS/v2/",
      identityUrl: "identity.mparticle.com/v1/",
      aliasUrl: "jssdks.mparticle.com/v1/identity/",
      userAudienceUrl: "nativesdks.mparticle.com/v1/"
    },
    // These are the paths that are used to construct the CNAME urls
    CNAMEUrlPaths: {
      v1SecureServiceUrl: "/webevents/v1/JS/",
      v2SecureServiceUrl: "/webevents/v2/JS/",
      v3SecureServiceUrl: "/webevents/v3/JS/",
      configUrl: "/tags/JS/v2/",
      identityUrl: "/identity/v1/",
      aliasUrl: "/webevents/v1/identity/"
    },
    Base64CookieKeys: {
      csm: 1,
      sa: 1,
      ss: 1,
      lsa: 1,
      ua: 1,
      ui: 1,
      csd: 1,
      ia: 1,
      con: 1
    },
    // https://go.mparticle.com/work/SQDSDKS-6039
    SDKv2NonMPIDCookieKeys: {
      gs: 1,
      cu: 1,
      l: 1,
      globalSettings: 1,
      currentUserMPID: 1
    },
    HTTPCodes: {
      noHttpCoverage: -1,
      activeIdentityRequest: -2,
      activeSession: -3,
      validationIssue: -4,
      nativeIdentityRequest: -5,
      loggingDisabledOrMissingAPIKey: -6,
      tooManyRequests: 429
    },
    FeatureFlags: {
      ReportBatching: "reportBatching",
      EventBatchingIntervalMillis: "eventBatchingIntervalMillis",
      OfflineStorage: "offlineStorage",
      DirectUrlRouting: "directURLRouting",
      CacheIdentity: "cacheIdentity",
      AudienceAPI: "audienceAPI",
      // CaptureIntegrationSpecificIds (legacy): boolean flag from server/UI
      //   - 'True'  → capture all integration-specific IDs
      //   - 'False' → capture none
      CaptureIntegrationSpecificIds: "captureIntegrationSpecificIds",
      // CaptureIntegrationSpecificIdsV2 (new): string mode from server
      //   - 'all'      → capture all IDs
      //   - 'none'     → capture none
      //   - 'roktonly' → capture only Rokt-related IDs
      CaptureIntegrationSpecificIdsV2: "captureIntegrationSpecificIds.V2",
      AstBackgroundEvents: "astBackgroundEvents",
      AutoLogPageView: "autoLogPageView"
    },
    DefaultInstance: "default_instance",
    CCPAPurpose: "data_sale_opt_out",
    IdentityMethods: {
      Modify: "modify",
      Logout: "logout",
      Login: "login",
      Identify: "identify"
    },
    Environment: {
      Development: "development",
      Production: "production"
    },
    CaptureIntegrationSpecificIdsV2Modes: {
      All: "all",
      None: "none",
      RoktOnly: "roktonly"
    },
    Rokt: {
      LauncherInstanceGuidKey: "__rokt_li_guid__"
    }
  };
  var ONE_DAY_IN_SECONDS = 60 * 60 * 24;
  var MILLIS_IN_ONE_SEC = 1e3;
  var NO_TARGETING_ATTRIBUTE = "$NoTargeting";
  var HTTP_OK = 200;
  var HTTP_ACCEPTED = 202;
  var HTTP_BAD_REQUEST = 400;
  var HTTP_NOT_FOUND = 404;
  var HTTP_SERVER_ERROR = 500;
  function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof(o);
  }
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function() {
    __assign = Object.assign || function __assign2(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  };
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t[0] & 1) throw t[1];
      return t[1];
    }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n) {
      return function(v) {
        return step([n, v]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  }
  function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  }
  typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
  };
  var Messages$a = Constants.Messages;
  var createCookieString = function createCookieString2(value) {
    return replaceCommasWithPipes(replaceQuotesWithApostrophes(value));
  };
  var revertCookieString = function revertCookieString2(value) {
    return replacePipesWithCommas(replaceApostrophesWithQuotes(value));
  };
  var inArray = function inArray2(items, name) {
    if (!items) {
      return false;
    }
    var i = 0;
    if (Array.prototype.indexOf) {
      return items.indexOf(name, 0) >= 0;
    } else {
      for (var n = items.length; i < n; i++) {
        if (i in items && items[i] === name) {
          return true;
        }
      }
    }
    return false;
  };
  var findKeyInObject = function findKeyInObject2(obj, key) {
    if (key && obj) {
      for (var prop in obj) {
        if (obj.hasOwnProperty(prop) && prop.toLowerCase() === key.toLowerCase()) {
          return prop;
        }
      }
    }
    return null;
  };
  var generateDeprecationMessage = function generateDeprecationMessage2(methodName, isDeprecated, alternateMethod, docsUrl) {
    var messageArray = [methodName];
    if (isDeprecated) {
      messageArray.push(Messages$a.DeprecationMessages.MethodHasBeenDeprecated);
    } else {
      messageArray.push(Messages$a.DeprecationMessages.MethodMarkedForDeprecationPostfix);
    }
    if (alternateMethod) {
      messageArray.push(Messages$a.DeprecationMessages.AlternativeMethodPrefix);
      messageArray.push(alternateMethod + ".");
    }
    if (docsUrl) {
      messageArray.push("See - " + docsUrl);
    }
    return messageArray.join(" ");
  };
  function generateHash(name) {
    var hash = 0;
    var character;
    if (name === void 0 || name === null) {
      return 0;
    }
    name = name.toString().toLowerCase();
    if (Array.prototype.reduce) {
      return name.split("").reduce(function(a, b) {
        a = (a << 5) - a + b.charCodeAt(0);
        return a & a;
      }, 0);
    }
    if (name.length === 0) {
      return hash;
    }
    for (var i = 0; i < name.length; i++) {
      character = name.charCodeAt(i);
      hash = (hash << 5) - hash + character;
      hash = hash & hash;
    }
    return hash;
  }
  var generateRandomValue = function generateRandomValue2(value) {
    var randomValue;
    var a;
    if (window.crypto && window.crypto.getRandomValues) {
      randomValue = window.crypto.getRandomValues(new Uint8Array(1));
    }
    if (randomValue) {
      return (a ^ randomValue[0] % 16 >> a / 4).toString(16);
    }
    return (a ^ Math.random() * 16 >> a / 4).toString(16);
  };
  var generateUniqueId = function generateUniqueId2(a) {
    if (a === void 0) {
      a = "";
    }
    return a ? generateRandomValue() : (
      // [1e7] -> // 10000000 +
      // -1e3  -> // -1000 +
      // -4e3  -> // -4000 +
      // -8e3  -> // -80000000 +
      // -1e11 -> //-100000000000,
      "".concat(1e7, "-").concat(1e3, "-").concat(4e3, "-").concat(8e3, "-").concat(1e11).replace(
        /[018]/g,
        // zeroes, ones, and eights with
        generateUniqueId2
        // random hex digits
      )
    );
  };
  var getRampNumber = function getRampNumber2(value) {
    if (!value) {
      return 100;
    }
    var hash = generateHash(value);
    return Math.abs(hash % 100) + 1;
  };
  var isObject = function isObject2(value) {
    var objType = Object.prototype.toString.call(value);
    return objType === "[object Object]" || objType === "[object Error]";
  };
  var parseNumber = function parseNumber2(value) {
    if (isNaN(value) || !isFinite(value)) {
      return 0;
    }
    var floatValue = parseFloat(value);
    return isNaN(floatValue) ? 0 : floatValue;
  };
  var parseSettingsString = function parseSettingsString2(settingsString) {
    try {
      return settingsString ? JSON.parse(settingsString.replace(/&quot;/g, '"')) : [];
    } catch (error) {
      throw new Error("Settings string contains invalid JSON");
    }
  };
  var parseStringOrNumber = function parseStringOrNumber2(value) {
    if (isStringOrNumber(value)) {
      return value;
    } else {
      return null;
    }
  };
  var replaceCommasWithPipes = function replaceCommasWithPipes2(value) {
    return value.replace(/,/g, "|");
  };
  var replacePipesWithCommas = function replacePipesWithCommas2(value) {
    return value.replace(/\|/g, ",");
  };
  var replaceApostrophesWithQuotes = function replaceApostrophesWithQuotes2(value) {
    return value.replace(/\'/g, '"');
  };
  var replaceQuotesWithApostrophes = function replaceQuotesWithApostrophes2(value) {
    return value.replace(/\"/g, "'");
  };
  var replaceMPID = function replaceMPID2(value, mpid) {
    return value.replace("%%mpid%%", mpid);
  };
  var replaceAmpWithAmpersand = function replaceAmpWithAmpersand2(value) {
    return value.replace(/&amp;/g, "&");
  };
  var createCookieSyncUrl = function createCookieSyncUrl2(mpid, pixelUrl, redirectUrl, domain, base64Mpid) {
    var modifiedPixelUrl = replaceAmpWithAmpersand(pixelUrl);
    var modifiedDirectUrl = redirectUrl ? replaceAmpWithAmpersand(redirectUrl) : null;
    var url = replaceMPID(modifiedPixelUrl, mpid);
    var redirect = modifiedDirectUrl ? replaceMPID(modifiedDirectUrl, mpid) : "";
    var fullUrl = url + encodeURIComponent(redirect);
    if (domain) {
      var separator = fullUrl.includes("?") ? "&" : "?";
      fullUrl += "".concat(separator, "domain=").concat(domain);
    }
    if (base64Mpid) {
      var separator = fullUrl.includes("?") ? "&" : "?";
      fullUrl += "".concat(separator, "google_hm=").concat(base64Mpid);
    }
    return fullUrl;
  };
  var WEB_SAFE_BASE64_REPLACEMENTS = {
    "+": "-",
    "/": "_",
    "=": ""
  };
  var toWebSafeBase64 = function toWebSafeBase642(value) {
    return btoa(value).replace(/[+/=]/g, function(c) {
      return WEB_SAFE_BASE64_REPLACEMENTS[c];
    });
  };
  var returnConvertedBoolean = function returnConvertedBoolean2(data) {
    if (data === "false" || data === "0") {
      return false;
    } else {
      return Boolean(data);
    }
  };
  var decoded = function decoded2(s) {
    return decodeURIComponent(s.replace(/\+/g, " "));
  };
  var converted = function converted2(s) {
    if (s.indexOf('"') === 0) {
      s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\");
    }
    return s;
  };
  var isString = function isString2(value) {
    return typeof value === "string";
  };
  var isNumber = function isNumber2(value) {
    return typeof value === "number";
  };
  var isBoolean = function isBoolean2(value) {
    return typeof value === "boolean";
  };
  var isFunction = function isFunction2(fn) {
    return typeof fn === "function";
  };
  var isValidAttributeValue = function isValidAttributeValue2(value) {
    return value !== void 0 && !isObject(value) && !Array.isArray(value);
  };
  var isValidCustomFlagProperty = function isValidCustomFlagProperty2(value) {
    return isNumber(value) || isString(value) || isBoolean(value);
  };
  var toDataPlanSlug = function toDataPlanSlug2(value) {
    return isStringOrNumber(value) ? value.toString().toLowerCase().replace(/[^0-9a-zA-Z]+/g, "_") : "";
  };
  var isDataPlanSlug = function isDataPlanSlug2(str) {
    return str === toDataPlanSlug(str);
  };
  var isStringOrNumber = function isStringOrNumber2(value) {
    return isString(value) || isNumber(value);
  };
  var isEmpty = function isEmpty2(value) {
    return value == null || !(Object.keys(value) || value).length;
  };
  var moveElementToEnd = function moveElementToEnd2(array, index) {
    return array.slice(0, index).concat(array.slice(index + 1), array[index]);
  };
  var queryStringParser = function queryStringParser2(url, keys) {
    if (keys === void 0) {
      keys = [];
    }
    var urlParams;
    var results = {};
    var lowerCaseUrlParams = {};
    if (!url) return results;
    if (typeof URL !== "undefined" && typeof URLSearchParams !== "undefined") {
      var urlObject = new URL(url);
      urlParams = new URLSearchParams(urlObject.search);
    } else {
      urlParams = queryStringParserFallback(url);
    }
    urlParams.forEach(function(value, key) {
      lowerCaseUrlParams[key.toLowerCase()] = value;
    });
    if (isEmpty(keys)) {
      return lowerCaseUrlParams;
    } else {
      keys.forEach(function(key) {
        var value = lowerCaseUrlParams[key.toLowerCase()];
        if (value) {
          results[key] = value;
        }
      });
    }
    return results;
  };
  var queryStringParserFallback = function queryStringParserFallback2(url) {
    var params = {};
    var queryString = url.split("?")[1] || "";
    var pairs = queryString.split("&");
    pairs.forEach(function(pair) {
      var _a2 = pair.split("="), key = _a2[0], valueParts = _a2.slice(1);
      var value = valueParts.join("=");
      if (key && value !== void 0) {
        try {
          params[key] = decodeURIComponent(value || "");
        } catch (e) {
          console.error("Failed to decode value for key ".concat(key, ": ").concat(e));
        }
      }
    });
    return {
      get: function get(key) {
        return params[key];
      },
      forEach: function forEach(callback) {
        for (var key in params) {
          if (params.hasOwnProperty(key)) {
            callback(params[key], key);
          }
        }
      }
    };
  };
  var getCookies = function getCookies2(keys) {
    var parseCookies = function parseCookies2() {
      try {
        if (typeof window === "undefined") {
          return [];
        }
        return window.document.cookie.split(";").map(function(cookie) {
          return cookie.trim();
        });
      } catch (e) {
        console.error("Unable to parse cookies", e);
        return [];
      }
    };
    var filterCookies = function filterCookies2(cookies, keys2) {
      var results = {};
      for (var _i = 0, cookies_1 = cookies; _i < cookies_1.length; _i++) {
        var cookie = cookies_1[_i];
        var _a2 = cookie.split("="), key = _a2[0], value = _a2[1];
        if (!keys2 || keys2.includes(key)) {
          results[key] = value;
        }
      }
      return results;
    };
    var parsedCookies = parseCookies();
    return filterCookies(parsedCookies, keys);
  };
  var getHref = function getHref2() {
    return typeof window !== "undefined" && window.location ? window.location.href : "";
  };
  var filterDictionaryWithHash = function filterDictionaryWithHash2(dictionary, filterList, hashFn) {
    var filtered = {};
    if (!isEmpty(dictionary)) {
      for (var key in dictionary) {
        if (dictionary.hasOwnProperty(key)) {
          var hashedKey = hashFn(key);
          if (!inArray(filterList, hashedKey)) {
            filtered[key] = dictionary[key];
          }
        }
      }
    }
    return filtered;
  };
  var parseConfig = function parseConfig2(config, moduleName, moduleId) {
    var _a2;
    return ((_a2 = config.kitConfigs) === null || _a2 === void 0 ? void 0 : _a2.find(function(kitConfig) {
      return kitConfig.name === moduleName && kitConfig.moduleId === moduleId;
    })) || null;
  };
  var obfuscateData = function obfuscateData2(value) {
    if (value === null || value === void 0) {
      return value;
    }
    if (Array.isArray(value)) {
      return value.map(function(item) {
        return obfuscateData2(item);
      });
    }
    if (isObject(value)) {
      var obfuscated = {};
      for (var key in value) {
        if (value.hasOwnProperty(key)) {
          obfuscated[key] = obfuscateData2(value[key]);
        }
      }
      return obfuscated;
    }
    return _typeof(value);
  };
  var obfuscateDevData = function obfuscateDevData2(data, isDevelopmentMode) {
    return isDevelopmentMode ? data : obfuscateData(data);
  };
  function extend() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      args[_i] = arguments[_i];
    }
    var objectHelper = {
      hasOwn: Object.prototype.hasOwnProperty,
      class2type: {},
      type: function type(obj) {
        return obj == null ? String(obj) : objectHelper.class2type[Object.prototype.toString.call(obj)] || "object";
      },
      isPlainObject: function isPlainObject(obj) {
        if (!obj || objectHelper.type(obj) !== "object" || obj.nodeType || objectHelper.isWindow(obj)) {
          return false;
        }
        try {
          if (obj.constructor && !objectHelper.hasOwn.call(obj, "constructor") && !objectHelper.hasOwn.call(obj.constructor.prototype, "isPrototypeOf")) {
            return false;
          }
        } catch (e) {
          return false;
        }
        var key;
        for (key in obj) {
        }
        return key === void 0 || objectHelper.hasOwn.call(obj, key);
      },
      isArray: Array.isArray || function(obj) {
        return objectHelper.type(obj) === "array";
      },
      isFunction: function isFunction2(obj) {
        return objectHelper.type(obj) === "function";
      },
      isWindow: function isWindow(obj) {
        return obj != null && obj == obj.window;
      }
    };
    var options, name, src, copy, copyIsArray, clone, target = args[0] || {}, i = 1, deep = false;
    var length = args.length;
    if (typeof target === "boolean") {
      deep = target;
      target = args[1] || {};
      i = 2;
    }
    if (_typeof(target) !== "object" && !objectHelper.isFunction(target)) {
      target = {};
    }
    if (length === i) {
      target = {};
      --i;
    }
    for (; i < length; i++) {
      if ((options = args[i]) != null) {
        for (name in options) {
          if (name === "__proto__" || name === "constructor" || name === "prototype") {
            continue;
          }
          if (!Object.prototype.hasOwnProperty.call(options, name)) {
            continue;
          }
          src = target[name];
          copy = options[name];
          if (target === copy) {
            continue;
          }
          if (deep && copy && (objectHelper.isPlainObject(copy) || (copyIsArray = objectHelper.isArray(copy)))) {
            if (copyIsArray) {
              copyIsArray = false;
              clone = src && objectHelper.isArray(src) ? src : [];
            } else {
              clone = src && objectHelper.isPlainObject(src) ? src : {};
            }
            target[name] = extend(deep, clone, copy);
          } else if (copy !== void 0) {
            target[name] = copy;
          }
        }
      }
    }
    return target;
  }
  var getErrorMessage = function getErrorMessage2(e, fallback) {
    if (fallback === void 0) {
      fallback = "unknown error";
    }
    if (e instanceof Error) {
      return e.message;
    }
    if (typeof e === "string") {
      return e;
    }
    if (e && _typeof(e) === "object" && typeof e.message === "string") {
      return e.message;
    }
    return fallback;
  };
  var MessageType$1 = {
    SessionStart: 1,
    SessionEnd: 2,
    PageView: 3,
    PageEvent: 4,
    CrashReport: 5,
    OptOut: 6,
    AppStateTransition: 10,
    Profile: 14,
    Commerce: 16,
    Media: 20,
    UserAttributeChange: 17,
    UserIdentityChange: 18
  };
  var EventType = {
    Unknown: 0,
    Navigation: 1,
    Location: 2,
    Search: 3,
    Transaction: 4,
    UserContent: 5,
    UserPreference: 6,
    Social: 7,
    Other: 8,
    Media: 9,
    getName: function getName(id) {
      switch (id) {
        case EventType.Unknown:
          return "Unknown";
        case EventType.Navigation:
          return "Navigation";
        case EventType.Location:
          return "Location";
        case EventType.Search:
          return "Search";
        case EventType.Transaction:
          return "Transaction";
        case EventType.UserContent:
          return "User Content";
        case EventType.UserPreference:
          return "User Preference";
        case EventType.Social:
          return "Social";
        case CommerceEventType.ProductAddToCart:
          return "Product Added to Cart";
        case CommerceEventType.ProductAddToWishlist:
          return "Product Added to Wishlist";
        case CommerceEventType.ProductCheckout:
          return "Product Checkout";
        case CommerceEventType.ProductCheckoutOption:
          return "Product Checkout Options";
        case CommerceEventType.ProductClick:
          return "Product Click";
        case CommerceEventType.ProductImpression:
          return "Product Impression";
        case CommerceEventType.ProductPurchase:
          return "Product Purchased";
        case CommerceEventType.ProductRefund:
          return "Product Refunded";
        case CommerceEventType.ProductRemoveFromCart:
          return "Product Removed From Cart";
        case CommerceEventType.ProductRemoveFromWishlist:
          return "Product Removed from Wishlist";
        case CommerceEventType.ProductViewDetail:
          return "Product View Details";
        case CommerceEventType.PromotionClick:
          return "Promotion Click";
        case CommerceEventType.PromotionView:
          return "Promotion View";
        default:
          return "Other";
      }
    }
  };
  var CommerceEventType = {
    ProductAddToCart: 10,
    ProductRemoveFromCart: 11,
    ProductCheckout: 12,
    ProductCheckoutOption: 13,
    ProductClick: 14,
    ProductViewDetail: 15,
    ProductPurchase: 16,
    ProductRefund: 17,
    PromotionView: 18,
    PromotionClick: 19,
    ProductAddToWishlist: 20,
    ProductRemoveFromWishlist: 21,
    ProductImpression: 22
  };
  var IdentityType = {
    Other: 0,
    CustomerId: 1,
    Facebook: 2,
    Twitter: 3,
    Google: 4,
    Microsoft: 5,
    Yahoo: 6,
    Email: 7,
    FacebookCustomAudienceId: 9,
    Other2: 10,
    Other3: 11,
    Other4: 12,
    Other5: 13,
    Other6: 14,
    Other7: 15,
    Other8: 16,
    Other9: 17,
    Other10: 18,
    MobileNumber: 19,
    PhoneNumber2: 20,
    PhoneNumber3: 21,
    isValid: function isValid(identityType) {
      if (typeof identityType === "number") {
        for (var prop in IdentityType) {
          if (IdentityType.hasOwnProperty(prop)) {
            if (IdentityType[prop] === identityType) {
              return true;
            }
          }
        }
      }
      return false;
    },
    getName: function getName(identityType) {
      switch (identityType) {
        case window.mParticle.IdentityType.CustomerId:
          return "Customer ID";
        case window.mParticle.IdentityType.Facebook:
          return "Facebook ID";
        case window.mParticle.IdentityType.Twitter:
          return "Twitter ID";
        case window.mParticle.IdentityType.Google:
          return "Google ID";
        case window.mParticle.IdentityType.Microsoft:
          return "Microsoft ID";
        case window.mParticle.IdentityType.Yahoo:
          return "Yahoo ID";
        case window.mParticle.IdentityType.Email:
          return "Email";
        case window.mParticle.IdentityType.FacebookCustomAudienceId:
          return "Facebook App User ID";
        default:
          return "Other ID";
      }
    },
    getIdentityType: function getIdentityType(identityName) {
      switch (identityName) {
        case "other":
          return IdentityType.Other;
        case "customerid":
          return IdentityType.CustomerId;
        case "facebook":
          return IdentityType.Facebook;
        case "twitter":
          return IdentityType.Twitter;
        case "google":
          return IdentityType.Google;
        case "microsoft":
          return IdentityType.Microsoft;
        case "yahoo":
          return IdentityType.Yahoo;
        case "email":
          return IdentityType.Email;
        case "facebookcustomaudienceid":
          return IdentityType.FacebookCustomAudienceId;
        case "other2":
          return IdentityType.Other2;
        case "other3":
          return IdentityType.Other3;
        case "other4":
          return IdentityType.Other4;
        case "other5":
          return IdentityType.Other5;
        case "other6":
          return IdentityType.Other6;
        case "other7":
          return IdentityType.Other7;
        case "other8":
          return IdentityType.Other8;
        case "other9":
          return IdentityType.Other9;
        case "other10":
          return IdentityType.Other10;
        case "mobile_number":
          return IdentityType.MobileNumber;
        case "phone_number_2":
          return IdentityType.PhoneNumber2;
        case "phone_number_3":
          return IdentityType.PhoneNumber3;
        case "email_sha256":
          return IdentityType.Other;
        case "mobile_sha256":
          return IdentityType.Other2;
        default:
          return false;
      }
    },
    getIdentityName: function getIdentityName(identityType) {
      switch (identityType) {
        case IdentityType.Other:
          return "other";
        case IdentityType.CustomerId:
          return "customerid";
        case IdentityType.Facebook:
          return "facebook";
        case IdentityType.Twitter:
          return "twitter";
        case IdentityType.Google:
          return "google";
        case IdentityType.Microsoft:
          return "microsoft";
        case IdentityType.Yahoo:
          return "yahoo";
        case IdentityType.Email:
          return "email";
        case IdentityType.FacebookCustomAudienceId:
          return "facebookcustomaudienceid";
        case IdentityType.Other2:
          return "other2";
        case IdentityType.Other3:
          return "other3";
        case IdentityType.Other4:
          return "other4";
        case IdentityType.Other5:
          return "other5";
        case IdentityType.Other6:
          return "other6";
        case IdentityType.Other7:
          return "other7";
        case IdentityType.Other8:
          return "other8";
        case IdentityType.Other9:
          return "other9";
        case IdentityType.Other10:
          return "other10";
        case IdentityType.MobileNumber:
          return "mobile_number";
        case IdentityType.PhoneNumber2:
          return "phone_number_2";
        case IdentityType.PhoneNumber3:
          return "phone_number_3";
        default:
          return null;
      }
    },
    // Strips out functions from Identity Types for easier lookups
    getValuesAsStrings: function getValuesAsStrings() {
      return Object.values(IdentityType).map(function(value) {
        return isNumber(value) ? value.toString() : void 0;
      }).filter(function(value) {
        return value !== void 0;
      });
    },
    getNewIdentitiesByName: function getNewIdentitiesByName(newIdentitiesByType) {
      var newIdentitiesByName = {};
      var identityTypeValuesAsStrings = IdentityType.getValuesAsStrings();
      for (var key in newIdentitiesByType) {
        if (identityTypeValuesAsStrings.includes(key)) {
          var identityNameKey = IdentityType.getIdentityName(parseNumber(key));
          newIdentitiesByName[identityNameKey] = newIdentitiesByType[key];
        }
      }
      return newIdentitiesByName;
    }
  };
  var ProductActionType = {
    Unknown: 0,
    AddToCart: 1,
    RemoveFromCart: 2,
    Checkout: 3,
    CheckoutOption: 4,
    Click: 5,
    ViewDetail: 6,
    Purchase: 7,
    Refund: 8,
    AddToWishlist: 9,
    RemoveFromWishlist: 10,
    // Rokt Brain commerce-adjacent types
    ViewCart: 11,
    AddShippingInfo: 12,
    AddPaymentInfo: 13,
    PaymentMethodSelected: 14,
    PaymentAttempted: 15,
    PaymentSucceeded: 16,
    PaymentFailed: 17,
    RefundInitiated: 18,
    isRoktCommerceType: function isRoktCommerceType(id) {
      return id >= ProductActionType.ViewCart && id <= ProductActionType.RefundInitiated;
    },
    getName: function getName(id) {
      switch (id) {
        case ProductActionType.AddToCart:
          return "Add to Cart";
        case ProductActionType.RemoveFromCart:
          return "Remove from Cart";
        case ProductActionType.Checkout:
          return "Checkout";
        case ProductActionType.CheckoutOption:
          return "Checkout Option";
        case ProductActionType.Click:
          return "Click";
        case ProductActionType.ViewDetail:
          return "View Detail";
        case ProductActionType.Purchase:
          return "Purchase";
        case ProductActionType.Refund:
          return "Refund";
        case ProductActionType.AddToWishlist:
          return "Add to Wishlist";
        case ProductActionType.RemoveFromWishlist:
          return "Remove from Wishlist";
        case ProductActionType.ViewCart:
          return "View Cart";
        case ProductActionType.AddShippingInfo:
          return "Add Shipping Info";
        case ProductActionType.AddPaymentInfo:
          return "Add Payment Info";
        case ProductActionType.PaymentMethodSelected:
          return "Payment Method Selected";
        case ProductActionType.PaymentAttempted:
          return "Payment Attempted";
        case ProductActionType.PaymentSucceeded:
          return "Payment Succeeded";
        case ProductActionType.PaymentFailed:
          return "Payment Failed";
        case ProductActionType.RefundInitiated:
          return "Refund Initiated";
        default:
          return "Unknown";
      }
    },
    // these are the action names used by server and mobile SDKs when expanding a CommerceEvent
    getExpansionName: function getExpansionName(id) {
      switch (id) {
        case ProductActionType.AddToCart:
          return "add_to_cart";
        case ProductActionType.RemoveFromCart:
          return "remove_from_cart";
        case ProductActionType.Checkout:
          return "checkout";
        case ProductActionType.CheckoutOption:
          return "checkout_option";
        case ProductActionType.Click:
          return "click";
        case ProductActionType.ViewDetail:
          return "view_detail";
        case ProductActionType.Purchase:
          return "purchase";
        case ProductActionType.Refund:
          return "refund";
        case ProductActionType.AddToWishlist:
          return "add_to_wishlist";
        case ProductActionType.RemoveFromWishlist:
          return "remove_from_wishlist";
        case ProductActionType.ViewCart:
          return "view_cart";
        case ProductActionType.AddShippingInfo:
          return "add_shipping_info";
        case ProductActionType.AddPaymentInfo:
          return "add_payment_info";
        case ProductActionType.PaymentMethodSelected:
          return "payment_method_selected";
        case ProductActionType.PaymentAttempted:
          return "payment_attempted";
        case ProductActionType.PaymentSucceeded:
          return "payment_succeeded";
        case ProductActionType.PaymentFailed:
          return "payment_failed";
        case ProductActionType.RefundInitiated:
          return "refund_initiated";
        default:
          return "unknown";
      }
    }
  };
  var RoktEvents = {
    SignUp: "sign_up",
    Subscribe: "subscribe",
    StartTrial: "start_trial",
    GenerateLead: "generate_lead",
    Search: "search",
    Upsell: "upsell",
    EarnVirtualCurrency: "earn_virtual_currency",
    DwellTime: "dwell_time",
    Hover: "hover",
    Scroll: "scroll",
    ClickToExpand: "click_to_expand"
  };
  var PromotionActionType = {
    Unknown: 0,
    PromotionView: 1,
    PromotionClick: 2,
    getName: function getName(id) {
      switch (id) {
        case PromotionActionType.PromotionView:
          return "view";
        case PromotionActionType.PromotionClick:
          return "click";
        default:
          return "unknown";
      }
    },
    // these are the names that the server and mobile SDKs use while expanding CommerceEvent
    getExpansionName: function getExpansionName(id) {
      switch (id) {
        case PromotionActionType.PromotionView:
          return "view";
        case PromotionActionType.PromotionClick:
          return "click";
        default:
          return "unknown";
      }
    }
  };
  var ProfileMessageType = {
    Logout: 3
  };
  var ApplicationTransitionType$1 = {
    AppInit: 1
  };
  var PerformanceMarkType = {
    SdkStart: "mp:sdkStart",
    JointSdkSelectPlacements: "mp:jointSdkSelectPlacements",
    JointSdkRoktKitInit: "mp:jointSdkRoktKitInit"
  };
  var Types = {
    MessageType: MessageType$1,
    EventType,
    CommerceEventType,
    IdentityType,
    ProfileMessageType,
    ApplicationTransitionType: ApplicationTransitionType$1,
    ProductActionType,
    PromotionActionType,
    RoktEvents,
    Environment: Constants.Environment
  };
  var SDKProductActionType;
  (function(SDKProductActionType2) {
    SDKProductActionType2[SDKProductActionType2["Unknown"] = 0] = "Unknown";
    SDKProductActionType2[SDKProductActionType2["AddToCart"] = 1] = "AddToCart";
    SDKProductActionType2[SDKProductActionType2["RemoveFromCart"] = 2] = "RemoveFromCart";
    SDKProductActionType2[SDKProductActionType2["Checkout"] = 3] = "Checkout";
    SDKProductActionType2[SDKProductActionType2["CheckoutOption"] = 4] = "CheckoutOption";
    SDKProductActionType2[SDKProductActionType2["Click"] = 5] = "Click";
    SDKProductActionType2[SDKProductActionType2["ViewDetail"] = 6] = "ViewDetail";
    SDKProductActionType2[SDKProductActionType2["Purchase"] = 7] = "Purchase";
    SDKProductActionType2[SDKProductActionType2["Refund"] = 8] = "Refund";
    SDKProductActionType2[SDKProductActionType2["AddToWishlist"] = 9] = "AddToWishlist";
    SDKProductActionType2[SDKProductActionType2["RemoveFromWishlist"] = 10] = "RemoveFromWishlist";
    SDKProductActionType2[SDKProductActionType2["ViewCart"] = 11] = "ViewCart";
    SDKProductActionType2[SDKProductActionType2["AddShippingInfo"] = 12] = "AddShippingInfo";
    SDKProductActionType2[SDKProductActionType2["AddPaymentInfo"] = 13] = "AddPaymentInfo";
    SDKProductActionType2[SDKProductActionType2["PaymentMethodSelected"] = 14] = "PaymentMethodSelected";
    SDKProductActionType2[SDKProductActionType2["PaymentAttempted"] = 15] = "PaymentAttempted";
    SDKProductActionType2[SDKProductActionType2["PaymentSucceeded"] = 16] = "PaymentSucceeded";
    SDKProductActionType2[SDKProductActionType2["PaymentFailed"] = 17] = "PaymentFailed";
    SDKProductActionType2[SDKProductActionType2["RefundInitiated"] = 18] = "RefundInitiated";
  })(SDKProductActionType || (SDKProductActionType = {}));
  var LogLevelType = {
    None: "none",
    Verbose: "verbose",
    Warning: "warning",
    Error: "error"
  };
  var dist = {};
  (function(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    (function(ApplicationInformationOsEnum) {
      ApplicationInformationOsEnum["unknown"] = "Unknown";
      ApplicationInformationOsEnum["iOS"] = "IOS";
      ApplicationInformationOsEnum["android"] = "Android";
      ApplicationInformationOsEnum["windowsPhone"] = "WindowsPhone";
      ApplicationInformationOsEnum["mobileWeb"] = "MobileWeb";
      ApplicationInformationOsEnum["unityIOS"] = "UnityIOS";
      ApplicationInformationOsEnum["unityAndroid"] = "UnityAndroid";
      ApplicationInformationOsEnum["desktop"] = "Desktop";
      ApplicationInformationOsEnum["tvOS"] = "TVOS";
      ApplicationInformationOsEnum["roku"] = "Roku";
      ApplicationInformationOsEnum["outOfBand"] = "OutOfBand";
      ApplicationInformationOsEnum["alexa"] = "Alexa";
      ApplicationInformationOsEnum["smartTV"] = "SmartTV";
      ApplicationInformationOsEnum["fireTV"] = "FireTV";
      ApplicationInformationOsEnum["xbox"] = "Xbox";
    })(exports.ApplicationInformationOsEnum || (exports.ApplicationInformationOsEnum = {}));
    (function(ApplicationStateTransitionEventEventTypeEnum) {
      ApplicationStateTransitionEventEventTypeEnum["applicationStateTransition"] = "application_state_transition";
    })(exports.ApplicationStateTransitionEventEventTypeEnum || (exports.ApplicationStateTransitionEventEventTypeEnum = {}));
    (function(ApplicationStateTransitionEventDataApplicationTransitionTypeEnum) {
      ApplicationStateTransitionEventDataApplicationTransitionTypeEnum["applicationInitialized"] = "application_initialized";
      ApplicationStateTransitionEventDataApplicationTransitionTypeEnum["applicationExit"] = "application_exit";
      ApplicationStateTransitionEventDataApplicationTransitionTypeEnum["applicationBackground"] = "application_background";
      ApplicationStateTransitionEventDataApplicationTransitionTypeEnum["applicationForeground"] = "application_foreground";
    })(exports.ApplicationStateTransitionEventDataApplicationTransitionTypeEnum || (exports.ApplicationStateTransitionEventDataApplicationTransitionTypeEnum = {}));
    (function(BatchEnvironmentEnum) {
      BatchEnvironmentEnum["unknown"] = "unknown";
      BatchEnvironmentEnum["development"] = "development";
      BatchEnvironmentEnum["production"] = "production";
    })(exports.BatchEnvironmentEnum || (exports.BatchEnvironmentEnum = {}));
    (function(BreadcrumbEventEventTypeEnum) {
      BreadcrumbEventEventTypeEnum["breadcrumb"] = "breadcrumb";
    })(exports.BreadcrumbEventEventTypeEnum || (exports.BreadcrumbEventEventTypeEnum = {}));
    (function(CommerceEventEventTypeEnum) {
      CommerceEventEventTypeEnum["commerceEvent"] = "commerce_event";
    })(exports.CommerceEventEventTypeEnum || (exports.CommerceEventEventTypeEnum = {}));
    (function(CommerceEventDataCustomEventTypeEnum) {
      CommerceEventDataCustomEventTypeEnum["addToCart"] = "add_to_cart";
      CommerceEventDataCustomEventTypeEnum["removeFromCart"] = "remove_from_cart";
      CommerceEventDataCustomEventTypeEnum["checkout"] = "checkout";
      CommerceEventDataCustomEventTypeEnum["checkoutOption"] = "checkout_option";
      CommerceEventDataCustomEventTypeEnum["click"] = "click";
      CommerceEventDataCustomEventTypeEnum["viewDetail"] = "view_detail";
      CommerceEventDataCustomEventTypeEnum["purchase"] = "purchase";
      CommerceEventDataCustomEventTypeEnum["refund"] = "refund";
      CommerceEventDataCustomEventTypeEnum["promotionView"] = "promotion_view";
      CommerceEventDataCustomEventTypeEnum["promotionClick"] = "promotion_click";
      CommerceEventDataCustomEventTypeEnum["addToWishlist"] = "add_to_wishlist";
      CommerceEventDataCustomEventTypeEnum["removeFromWishlist"] = "remove_from_wishlist";
      CommerceEventDataCustomEventTypeEnum["impression"] = "impression";
    })(exports.CommerceEventDataCustomEventTypeEnum || (exports.CommerceEventDataCustomEventTypeEnum = {}));
    (function(CrashReportEventEventTypeEnum) {
      CrashReportEventEventTypeEnum["crashReport"] = "crash_report";
    })(exports.CrashReportEventEventTypeEnum || (exports.CrashReportEventEventTypeEnum = {}));
    (function(CustomEventEventTypeEnum) {
      CustomEventEventTypeEnum["customEvent"] = "custom_event";
    })(exports.CustomEventEventTypeEnum || (exports.CustomEventEventTypeEnum = {}));
    (function(CustomEventDataCustomEventTypeEnum) {
      CustomEventDataCustomEventTypeEnum["navigation"] = "navigation";
      CustomEventDataCustomEventTypeEnum["location"] = "location";
      CustomEventDataCustomEventTypeEnum["search"] = "search";
      CustomEventDataCustomEventTypeEnum["transaction"] = "transaction";
      CustomEventDataCustomEventTypeEnum["userContent"] = "user_content";
      CustomEventDataCustomEventTypeEnum["userPreference"] = "user_preference";
      CustomEventDataCustomEventTypeEnum["social"] = "social";
      CustomEventDataCustomEventTypeEnum["media"] = "media";
      CustomEventDataCustomEventTypeEnum["other"] = "other";
      CustomEventDataCustomEventTypeEnum["unknown"] = "unknown";
    })(exports.CustomEventDataCustomEventTypeEnum || (exports.CustomEventDataCustomEventTypeEnum = {}));
    (function(DeviceCurrentStateDeviceOrientationEnum) {
      DeviceCurrentStateDeviceOrientationEnum["portrait"] = "portrait";
      DeviceCurrentStateDeviceOrientationEnum["portraitUpsideDown"] = "portrait_upside_down";
      DeviceCurrentStateDeviceOrientationEnum["landscape"] = "landscape";
      DeviceCurrentStateDeviceOrientationEnum["landscapeLeft"] = "LandscapeLeft";
      DeviceCurrentStateDeviceOrientationEnum["landscapeRight"] = "LandscapeRight";
      DeviceCurrentStateDeviceOrientationEnum["faceUp"] = "FaceUp";
      DeviceCurrentStateDeviceOrientationEnum["faceDown"] = "FaceDown";
      DeviceCurrentStateDeviceOrientationEnum["square"] = "Square";
    })(exports.DeviceCurrentStateDeviceOrientationEnum || (exports.DeviceCurrentStateDeviceOrientationEnum = {}));
    (function(DeviceCurrentStateStatusBarOrientationEnum) {
      DeviceCurrentStateStatusBarOrientationEnum["portrait"] = "portrait";
      DeviceCurrentStateStatusBarOrientationEnum["portraitUpsideDown"] = "portrait_upside_down";
      DeviceCurrentStateStatusBarOrientationEnum["landscape"] = "landscape";
      DeviceCurrentStateStatusBarOrientationEnum["landscapeLeft"] = "LandscapeLeft";
      DeviceCurrentStateStatusBarOrientationEnum["landscapeRight"] = "LandscapeRight";
      DeviceCurrentStateStatusBarOrientationEnum["faceUp"] = "FaceUp";
      DeviceCurrentStateStatusBarOrientationEnum["faceDown"] = "FaceDown";
      DeviceCurrentStateStatusBarOrientationEnum["square"] = "Square";
    })(exports.DeviceCurrentStateStatusBarOrientationEnum || (exports.DeviceCurrentStateStatusBarOrientationEnum = {}));
    (function(DeviceInformationPlatformEnum) {
      DeviceInformationPlatformEnum["iOS"] = "iOS";
      DeviceInformationPlatformEnum["android"] = "Android";
      DeviceInformationPlatformEnum["web"] = "web";
      DeviceInformationPlatformEnum["desktop"] = "desktop";
      DeviceInformationPlatformEnum["tvOS"] = "tvOS";
      DeviceInformationPlatformEnum["roku"] = "roku";
      DeviceInformationPlatformEnum["outOfBand"] = "out_of_band";
      DeviceInformationPlatformEnum["smartTV"] = "smart_tv";
      DeviceInformationPlatformEnum["xbox"] = "xbox";
    })(exports.DeviceInformationPlatformEnum || (exports.DeviceInformationPlatformEnum = {}));
    (function(EventTypeEnum) {
      EventTypeEnum["unknown"] = "unknown";
      EventTypeEnum["sessionStart"] = "session_start";
      EventTypeEnum["sessionEnd"] = "session_end";
      EventTypeEnum["screenView"] = "screen_view";
      EventTypeEnum["customEvent"] = "custom_event";
      EventTypeEnum["crashReport"] = "crash_report";
      EventTypeEnum["optOut"] = "opt_out";
      EventTypeEnum["firstRun"] = "first_run";
      EventTypeEnum["preAttribution"] = "pre_attribution";
      EventTypeEnum["pushRegistration"] = "push_registration";
      EventTypeEnum["applicationStateTransition"] = "application_state_transition";
      EventTypeEnum["pushMessage"] = "push_message";
      EventTypeEnum["networkPerformance"] = "network_performance";
      EventTypeEnum["breadcrumb"] = "breadcrumb";
      EventTypeEnum["profile"] = "profile";
      EventTypeEnum["pushReaction"] = "push_reaction";
      EventTypeEnum["commerceEvent"] = "commerce_event";
      EventTypeEnum["userAttributeChange"] = "user_attribute_change";
      EventTypeEnum["userIdentityChange"] = "user_identity_change";
      EventTypeEnum["uninstall"] = "uninstall";
      EventTypeEnum["validationResult"] = "validation_result";
    })(exports.EventTypeEnum || (exports.EventTypeEnum = {}));
    (function(IdentityTypeEnum) {
      IdentityTypeEnum["other"] = "other";
      IdentityTypeEnum["customerId"] = "customer_id";
      IdentityTypeEnum["facebook"] = "facebook";
      IdentityTypeEnum["twitter"] = "twitter";
      IdentityTypeEnum["google"] = "google";
      IdentityTypeEnum["microsoft"] = "microsoft";
      IdentityTypeEnum["yahoo"] = "yahoo";
      IdentityTypeEnum["email"] = "email";
      IdentityTypeEnum["alias"] = "alias";
      IdentityTypeEnum["facebookCustomAudienceId"] = "facebook_custom_audience_id";
      IdentityTypeEnum["otherId2"] = "other_id_2";
      IdentityTypeEnum["otherId3"] = "other_id_3";
      IdentityTypeEnum["otherId4"] = "other_id_4";
      IdentityTypeEnum["otherId5"] = "other_id_5";
      IdentityTypeEnum["otherId6"] = "other_id_6";
      IdentityTypeEnum["otherId7"] = "other_id_7";
      IdentityTypeEnum["otherId8"] = "other_id_8";
      IdentityTypeEnum["otherId9"] = "other_id_9";
      IdentityTypeEnum["otherId10"] = "other_id_10";
      IdentityTypeEnum["mobileNumber"] = "mobile_number";
      IdentityTypeEnum["phoneNumber2"] = "phone_number_2";
      IdentityTypeEnum["phoneNumber3"] = "phone_number_3";
    })(exports.IdentityTypeEnum || (exports.IdentityTypeEnum = {}));
    (function(NetworkPerformanceEventEventTypeEnum) {
      NetworkPerformanceEventEventTypeEnum["networkPerformance"] = "network_performance";
    })(exports.NetworkPerformanceEventEventTypeEnum || (exports.NetworkPerformanceEventEventTypeEnum = {}));
    (function(OptOutEventEnum) {
      OptOutEventEnum["optOut"] = "opt_out";
    })(exports.OptOutEventEnum || (exports.OptOutEventEnum = {}));
    (function(ProductActionActionEnum) {
      ProductActionActionEnum["unknown"] = "unknown";
      ProductActionActionEnum["addToCart"] = "add_to_cart";
      ProductActionActionEnum["removeFromCart"] = "remove_from_cart";
      ProductActionActionEnum["checkout"] = "checkout";
      ProductActionActionEnum["checkoutOption"] = "checkout_option";
      ProductActionActionEnum["click"] = "click";
      ProductActionActionEnum["viewDetail"] = "view_detail";
      ProductActionActionEnum["purchase"] = "purchase";
      ProductActionActionEnum["refund"] = "refund";
      ProductActionActionEnum["addToWishlist"] = "add_to_wishlist";
      ProductActionActionEnum["removeFromWishlist"] = "remove_from_wish_list";
    })(exports.ProductActionActionEnum || (exports.ProductActionActionEnum = {}));
    (function(ProfileEventEventTypeEnum) {
      ProfileEventEventTypeEnum["profile"] = "profile";
    })(exports.ProfileEventEventTypeEnum || (exports.ProfileEventEventTypeEnum = {}));
    (function(ProfileEventDataProfileEventTypeEnum) {
      ProfileEventDataProfileEventTypeEnum["signup"] = "signup";
      ProfileEventDataProfileEventTypeEnum["login"] = "login";
      ProfileEventDataProfileEventTypeEnum["logout"] = "logout";
      ProfileEventDataProfileEventTypeEnum["update"] = "update";
      ProfileEventDataProfileEventTypeEnum["delete"] = "delete";
    })(exports.ProfileEventDataProfileEventTypeEnum || (exports.ProfileEventDataProfileEventTypeEnum = {}));
    (function(PromotionActionActionEnum) {
      PromotionActionActionEnum["view"] = "view";
      PromotionActionActionEnum["click"] = "click";
    })(exports.PromotionActionActionEnum || (exports.PromotionActionActionEnum = {}));
    (function(PushMessageEventEventTypeEnum) {
      PushMessageEventEventTypeEnum["pushMessage"] = "push_message";
    })(exports.PushMessageEventEventTypeEnum || (exports.PushMessageEventEventTypeEnum = {}));
    (function(PushMessageEventDataPushMessageTypeEnum) {
      PushMessageEventDataPushMessageTypeEnum["sent"] = "sent";
      PushMessageEventDataPushMessageTypeEnum["received"] = "received";
      PushMessageEventDataPushMessageTypeEnum["action"] = "action";
    })(exports.PushMessageEventDataPushMessageTypeEnum || (exports.PushMessageEventDataPushMessageTypeEnum = {}));
    (function(PushMessageEventDataApplicationStateEnum) {
      PushMessageEventDataApplicationStateEnum["notRunning"] = "not_running";
      PushMessageEventDataApplicationStateEnum["background"] = "background";
      PushMessageEventDataApplicationStateEnum["foreground"] = "foreground";
    })(exports.PushMessageEventDataApplicationStateEnum || (exports.PushMessageEventDataApplicationStateEnum = {}));
    (function(PushMessageEventDataPushMessageBehaviorEnum) {
      PushMessageEventDataPushMessageBehaviorEnum["received"] = "Received";
      PushMessageEventDataPushMessageBehaviorEnum["directOpen"] = "DirectOpen";
      PushMessageEventDataPushMessageBehaviorEnum["read"] = "Read";
      PushMessageEventDataPushMessageBehaviorEnum["influencedOpen"] = "InfluencedOpen";
      PushMessageEventDataPushMessageBehaviorEnum["displayed"] = "Displayed";
    })(exports.PushMessageEventDataPushMessageBehaviorEnum || (exports.PushMessageEventDataPushMessageBehaviorEnum = {}));
    (function(PushRegistrationEventEventTypeEnum) {
      PushRegistrationEventEventTypeEnum["pushRegistration"] = "push_registration";
    })(exports.PushRegistrationEventEventTypeEnum || (exports.PushRegistrationEventEventTypeEnum = {}));
    (function(SessionEndEventEventTypeEnum) {
      SessionEndEventEventTypeEnum["sessionEnd"] = "session_end";
    })(exports.SessionEndEventEventTypeEnum || (exports.SessionEndEventEventTypeEnum = {}));
    (function(SessionStartEventEventTypeEnum) {
      SessionStartEventEventTypeEnum["sessionStart"] = "session_start";
    })(exports.SessionStartEventEventTypeEnum || (exports.SessionStartEventEventTypeEnum = {}));
    (function(SourceInformationChannelEnum) {
      SourceInformationChannelEnum["native"] = "native";
      SourceInformationChannelEnum["javascript"] = "javascript";
      SourceInformationChannelEnum["pixel"] = "pixel";
      SourceInformationChannelEnum["desktop"] = "desktop";
      SourceInformationChannelEnum["partner"] = "partner";
      SourceInformationChannelEnum["serverToServer"] = "server_to_server";
    })(exports.SourceInformationChannelEnum || (exports.SourceInformationChannelEnum = {}));
    (function(UserAttributeChangeEventEventTypeEnum) {
      UserAttributeChangeEventEventTypeEnum["userAttributeChange"] = "user_attribute_change";
    })(exports.UserAttributeChangeEventEventTypeEnum || (exports.UserAttributeChangeEventEventTypeEnum = {}));
    (function(UserIdentityChangeEventEventTypeEnum) {
      UserIdentityChangeEventEventTypeEnum["userIdentityChange"] = "user_identity_change";
    })(exports.UserIdentityChangeEventEventTypeEnum || (exports.UserIdentityChangeEventEventTypeEnum = {}));
  })(dist);
  var SDKIdentityTypeEnum;
  (function(SDKIdentityTypeEnum2) {
    SDKIdentityTypeEnum2["other"] = "other";
    SDKIdentityTypeEnum2["customerId"] = "customerid";
    SDKIdentityTypeEnum2["facebook"] = "facebook";
    SDKIdentityTypeEnum2["twitter"] = "twitter";
    SDKIdentityTypeEnum2["google"] = "google";
    SDKIdentityTypeEnum2["microsoft"] = "microsoft";
    SDKIdentityTypeEnum2["yahoo"] = "yahoo";
    SDKIdentityTypeEnum2["email"] = "email";
    SDKIdentityTypeEnum2["alias"] = "alias";
    SDKIdentityTypeEnum2["facebookCustomAudienceId"] = "facebookcustomaudienceid";
    SDKIdentityTypeEnum2["otherId2"] = "other2";
    SDKIdentityTypeEnum2["otherId3"] = "other3";
    SDKIdentityTypeEnum2["otherId4"] = "other4";
    SDKIdentityTypeEnum2["otherId5"] = "other5";
    SDKIdentityTypeEnum2["otherId6"] = "other6";
    SDKIdentityTypeEnum2["otherId7"] = "other7";
    SDKIdentityTypeEnum2["otherId8"] = "other8";
    SDKIdentityTypeEnum2["otherId9"] = "other9";
    SDKIdentityTypeEnum2["otherId10"] = "other10";
    SDKIdentityTypeEnum2["mobileNumber"] = "mobile_number";
    SDKIdentityTypeEnum2["phoneNumber2"] = "phone_number_2";
    SDKIdentityTypeEnum2["phoneNumber3"] = "phone_number_3";
  })(SDKIdentityTypeEnum || (SDKIdentityTypeEnum = {}));
  var FeatureFlags$2 = Constants.FeatureFlags;
  var CaptureIntegrationSpecificIds$1 = FeatureFlags$2.CaptureIntegrationSpecificIds, CaptureIntegrationSpecificIdsV2$1 = FeatureFlags$2.CaptureIntegrationSpecificIdsV2;
  function convertEvents(mpid, sdkEvents, mpInstance) {
    if (!mpid) {
      return null;
    }
    if (!sdkEvents || sdkEvents.length < 1) {
      return null;
    }
    var _IntegrationCapture = mpInstance._IntegrationCapture, _Helpers = mpInstance._Helpers;
    var getFeatureFlag = _Helpers.getFeatureFlag;
    var user = mpInstance.Identity.getCurrentUser();
    var uploadEvents = [];
    var lastEvent = null;
    for (var _i = 0, sdkEvents_1 = sdkEvents; _i < sdkEvents_1.length; _i++) {
      var sdkEvent = sdkEvents_1[_i];
      if (sdkEvent) {
        lastEvent = sdkEvent;
        var baseEvent = convertEvent(sdkEvent);
        if (baseEvent) {
          uploadEvents.push(baseEvent);
        }
      }
    }
    if (!lastEvent) {
      return null;
    }
    var currentConsentState = null;
    if (!isEmpty(lastEvent.ConsentState)) {
      currentConsentState = lastEvent.ConsentState;
    } else if (!isEmpty(user)) {
      currentConsentState = user.getConsentState();
    }
    var upload = {
      source_request_id: mpInstance._Helpers.generateUniqueId(),
      mpid,
      timestamp_unixtime_ms: (/* @__PURE__ */ new Date()).getTime(),
      environment: lastEvent.Debug ? dist.BatchEnvironmentEnum.development : dist.BatchEnvironmentEnum.production,
      events: uploadEvents,
      mp_deviceid: lastEvent.DeviceId,
      sdk_version: lastEvent.SDKVersion,
      // TODO: Refactor this to read from _Store or a global config
      application_info: {
        application_version: lastEvent.AppVersion,
        application_name: lastEvent.AppName,
        "package": lastEvent.Package,
        sideloaded_kits_count: mpInstance._Store.sideloadedKitsCount
      },
      device_info: {
        platform: dist.DeviceInformationPlatformEnum.web,
        screen_width: typeof window !== "undefined" && typeof window.screen !== "undefined" ? window.screen.width : 0,
        screen_height: typeof window !== "undefined" && typeof window.screen !== "undefined" ? window.screen.height : 0
      },
      user_attributes: lastEvent.UserAttributes,
      user_identities: convertUserIdentities(lastEvent.UserIdentities),
      consent_state: convertConsentState(currentConsentState),
      integration_attributes: lastEvent.IntegrationAttributes
    };
    if (lastEvent.DataPlan && lastEvent.DataPlan.PlanId) {
      upload.context = {
        data_plan: {
          plan_id: lastEvent.DataPlan.PlanId,
          plan_version: lastEvent.DataPlan.PlanVersion || void 0
        }
      };
    }
    var integrationSpecificIds = getFeatureFlag && Boolean(getFeatureFlag(CaptureIntegrationSpecificIds$1));
    var integrationSpecificIdsV2 = getFeatureFlag && getFeatureFlag(CaptureIntegrationSpecificIdsV2$1);
    var isIntegrationCaptureEnabled = integrationSpecificIdsV2 && integrationSpecificIdsV2 !== Constants.CaptureIntegrationSpecificIdsV2Modes.None || integrationSpecificIds === true;
    if (isIntegrationCaptureEnabled) {
      var capturedPartnerIdentities = _IntegrationCapture === null || _IntegrationCapture === void 0 ? void 0 : _IntegrationCapture.getClickIdsAsPartnerIdentities();
      if (!isEmpty(capturedPartnerIdentities)) {
        upload.partner_identities = capturedPartnerIdentities;
      }
    }
    return upload;
  }
  function convertConsentState(sdkConsentState) {
    if (isEmpty(sdkConsentState)) {
      return null;
    }
    var consentState = {
      gdpr: convertGdprConsentState(sdkConsentState.getGDPRConsentState()),
      ccpa: convertCcpaConsentState(sdkConsentState.getCCPAConsentState())
    };
    return consentState;
  }
  function convertGdprConsentState(sdkGdprConsentState) {
    if (!sdkGdprConsentState) {
      return null;
    }
    var state = {};
    for (var purpose in sdkGdprConsentState) {
      if (sdkGdprConsentState.hasOwnProperty(purpose)) {
        state[purpose] = {
          consented: sdkGdprConsentState[purpose].Consented,
          hardware_id: sdkGdprConsentState[purpose].HardwareId,
          document: sdkGdprConsentState[purpose].ConsentDocument,
          timestamp_unixtime_ms: sdkGdprConsentState[purpose].Timestamp,
          location: sdkGdprConsentState[purpose].Location
        };
      }
    }
    return state;
  }
  function convertCcpaConsentState(sdkCcpaConsentState) {
    if (!sdkCcpaConsentState) {
      return null;
    }
    var state = {
      data_sale_opt_out: {
        consented: sdkCcpaConsentState.Consented,
        hardware_id: sdkCcpaConsentState.HardwareId,
        document: sdkCcpaConsentState.ConsentDocument,
        timestamp_unixtime_ms: sdkCcpaConsentState.Timestamp,
        location: sdkCcpaConsentState.Location
      }
    };
    return state;
  }
  function convertUserIdentities(sdkUserIdentities) {
    if (!sdkUserIdentities || !sdkUserIdentities.length) {
      return null;
    }
    var batchIdentities = {};
    for (var _i = 0, sdkUserIdentities_1 = sdkUserIdentities; _i < sdkUserIdentities_1.length; _i++) {
      var identity = sdkUserIdentities_1[_i];
      switch (identity.Type) {
        case Types.IdentityType.CustomerId:
          batchIdentities.customer_id = identity.Identity;
          break;
        case Types.IdentityType.Email:
          batchIdentities.email = identity.Identity;
          break;
        case Types.IdentityType.Facebook:
          batchIdentities.facebook = identity.Identity;
          break;
        case Types.IdentityType.FacebookCustomAudienceId:
          batchIdentities.facebook_custom_audience_id = identity.Identity;
          break;
        case Types.IdentityType.Google:
          batchIdentities.google = identity.Identity;
          break;
        case Types.IdentityType.Microsoft:
          batchIdentities.microsoft = identity.Identity;
          break;
        case Types.IdentityType.Other:
          batchIdentities.other = identity.Identity;
          break;
        case Types.IdentityType.Other2:
          batchIdentities.other_id_2 = identity.Identity;
          break;
        case Types.IdentityType.Other3:
          batchIdentities.other_id_3 = identity.Identity;
          break;
        case Types.IdentityType.Other4:
          batchIdentities.other_id_4 = identity.Identity;
          break;
        case Types.IdentityType.Other5:
          batchIdentities.other_id_5 = identity.Identity;
          break;
        case Types.IdentityType.Other6:
          batchIdentities.other_id_6 = identity.Identity;
          break;
        case Types.IdentityType.Other7:
          batchIdentities.other_id_7 = identity.Identity;
          break;
        case Types.IdentityType.Other8:
          batchIdentities.other_id_8 = identity.Identity;
          break;
        case Types.IdentityType.Other9:
          batchIdentities.other_id_9 = identity.Identity;
          break;
        case Types.IdentityType.Other10:
          batchIdentities.other_id_10 = identity.Identity;
          break;
        case Types.IdentityType.MobileNumber:
          batchIdentities.mobile_number = identity.Identity;
          break;
        case Types.IdentityType.PhoneNumber2:
          batchIdentities.phone_number_2 = identity.Identity;
          break;
        case Types.IdentityType.PhoneNumber3:
          batchIdentities.phone_number_3 = identity.Identity;
          break;
      }
    }
    return batchIdentities;
  }
  function convertEvent(sdkEvent) {
    if (!sdkEvent) {
      return null;
    }
    switch (sdkEvent.EventDataType) {
      case Types.MessageType.AppStateTransition:
        return convertAST(sdkEvent);
      case Types.MessageType.Commerce:
        return convertCommerceEvent(sdkEvent);
      case Types.MessageType.CrashReport:
        return convertCrashReportEvent(sdkEvent);
      case Types.MessageType.OptOut:
        return convertOptOutEvent(sdkEvent);
      case Types.MessageType.PageEvent:
        return convertCustomEvent(sdkEvent);
      case Types.MessageType.PageView:
        return convertPageViewEvent(sdkEvent);
      case Types.MessageType.Profile:
        return null;
      case Types.MessageType.SessionEnd:
        return convertSessionEndEvent(sdkEvent);
      case Types.MessageType.SessionStart:
        return convertSessionStartEvent(sdkEvent);
      case Types.MessageType.UserAttributeChange:
        return convertUserAttributeChangeEvent(sdkEvent);
      case Types.MessageType.UserIdentityChange:
        return convertUserIdentityChangeEvent(sdkEvent);
    }
    return null;
  }
  function convertProductActionType(actionType) {
    if (!actionType) {
      return dist.ProductActionActionEnum.unknown;
    }
    switch (actionType) {
      case SDKProductActionType.AddToCart:
        return dist.ProductActionActionEnum.addToCart;
      case SDKProductActionType.AddToWishlist:
        return dist.ProductActionActionEnum.addToWishlist;
      case SDKProductActionType.Checkout:
        return dist.ProductActionActionEnum.checkout;
      case SDKProductActionType.CheckoutOption:
        return dist.ProductActionActionEnum.checkoutOption;
      case SDKProductActionType.Click:
        return dist.ProductActionActionEnum.click;
      case SDKProductActionType.Purchase:
        return dist.ProductActionActionEnum.purchase;
      case SDKProductActionType.Refund:
        return dist.ProductActionActionEnum.refund;
      case SDKProductActionType.RemoveFromCart:
        return dist.ProductActionActionEnum.removeFromCart;
      case SDKProductActionType.RemoveFromWishlist:
        return dist.ProductActionActionEnum.removeFromWishlist;
      case SDKProductActionType.ViewDetail:
        return dist.ProductActionActionEnum.viewDetail;
      default:
        return dist.ProductActionActionEnum.unknown;
    }
  }
  function convertProductAction(sdkEvent) {
    if (!sdkEvent.ProductAction) {
      return null;
    }
    var productAction = {
      action: convertProductActionType(sdkEvent.ProductAction.ProductActionType),
      checkout_step: sdkEvent.ProductAction.CheckoutStep,
      checkout_options: sdkEvent.ProductAction.CheckoutOptions,
      transaction_id: sdkEvent.ProductAction.TransactionId,
      affiliation: sdkEvent.ProductAction.Affiliation,
      total_amount: sdkEvent.ProductAction.TotalAmount,
      tax_amount: sdkEvent.ProductAction.TaxAmount,
      shipping_amount: sdkEvent.ProductAction.ShippingAmount,
      coupon_code: sdkEvent.ProductAction.CouponCode,
      products: convertProducts(sdkEvent.ProductAction.ProductList)
    };
    return productAction;
  }
  function convertProducts(sdkProducts) {
    if (!sdkProducts || !sdkProducts.length) {
      return null;
    }
    var products = [];
    for (var _i = 0, sdkProducts_1 = sdkProducts; _i < sdkProducts_1.length; _i++) {
      var sdkProduct = sdkProducts_1[_i];
      var product = {
        id: sdkProduct.Sku,
        name: sdkProduct.Name,
        brand: sdkProduct.Brand,
        category: sdkProduct.Category,
        variant: sdkProduct.Variant,
        total_product_amount: sdkProduct.TotalAmount,
        position: sdkProduct.Position,
        price: sdkProduct.Price,
        quantity: sdkProduct.Quantity,
        coupon_code: sdkProduct.CouponCode,
        custom_attributes: sdkProduct.Attributes
      };
      products.push(product);
    }
    return products;
  }
  function convertPromotionAction(sdkEvent) {
    if (!sdkEvent.PromotionAction) {
      return null;
    }
    var promotionAction = {
      action: sdkEvent.PromotionAction.PromotionActionType,
      promotions: convertPromotions(sdkEvent.PromotionAction.PromotionList)
    };
    return promotionAction;
  }
  function convertPromotions(sdkPromotions) {
    if (!sdkPromotions || !sdkPromotions.length) {
      return null;
    }
    var promotions = [];
    for (var _i = 0, sdkPromotions_1 = sdkPromotions; _i < sdkPromotions_1.length; _i++) {
      var sdkPromotion = sdkPromotions_1[_i];
      var promotion = {
        id: sdkPromotion.Id,
        name: sdkPromotion.Name,
        creative: sdkPromotion.Creative,
        position: sdkPromotion.Position
      };
      promotions.push(promotion);
    }
    return promotions;
  }
  function convertImpressions(sdkEvent) {
    if (!sdkEvent.ProductImpressions) {
      return null;
    }
    var impressions = [];
    for (var _i = 0, _a2 = sdkEvent.ProductImpressions; _i < _a2.length; _i++) {
      var sdkImpression = _a2[_i];
      var impression = {
        product_impression_list: sdkImpression.ProductImpressionList,
        products: convertProducts(sdkImpression.ProductList)
      };
      impressions.push(impression);
    }
    return impressions;
  }
  function convertShoppingCart(sdkEvent) {
    if (!sdkEvent.ShoppingCart || !sdkEvent.ShoppingCart.ProductList || !sdkEvent.ShoppingCart.ProductList.length) {
      return null;
    }
    var shoppingCart = {
      products: convertProducts(sdkEvent.ShoppingCart.ProductList)
    };
    return shoppingCart;
  }
  function convertCommerceEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var commerceEventData = {
      custom_flags: sdkEvent.CustomFlags,
      product_action: convertProductAction(sdkEvent),
      promotion_action: convertPromotionAction(sdkEvent),
      product_impressions: convertImpressions(sdkEvent),
      shopping_cart: convertShoppingCart(sdkEvent),
      currency_code: sdkEvent.CurrencyCode
    };
    commerceEventData = Object.assign(commerceEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.commerceEvent,
      data: commerceEventData
    };
  }
  function convertCrashReportEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var crashReportEventData = {
      message: sdkEvent.EventName
    };
    crashReportEventData = Object.assign(crashReportEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.crashReport,
      data: crashReportEventData
    };
  }
  function convertAST(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var _a2 = dist.ApplicationStateTransitionEventDataApplicationTransitionTypeEnum, applicationBackground = _a2.applicationBackground, applicationInitialized = _a2.applicationInitialized;
    var transitionType = sdkEvent.IsBackgroundAST ? applicationBackground : applicationInitialized;
    var astEventData = {
      application_transition_type: transitionType,
      is_first_run: sdkEvent.IsFirstRun,
      is_upgrade: false,
      launch_referral: sdkEvent.LaunchReferral
    };
    astEventData = Object.assign(astEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.applicationStateTransition,
      data: astEventData
    };
  }
  function convertSessionEndEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var sessionEndEventData = {
      session_duration_ms: sdkEvent.SessionLength
      //note: External Events DTO does not support the session mpids array as of this time.
      //spanning_mpids: sdkEvent.SessionMpids
    };
    sessionEndEventData = Object.assign(sessionEndEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.sessionEnd,
      data: sessionEndEventData
    };
  }
  function convertSessionStartEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var sessionStartEventData = {};
    sessionStartEventData = Object.assign(sessionStartEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.sessionStart,
      data: sessionStartEventData
    };
  }
  function convertPageViewEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var screenViewEventData = {
      custom_flags: sdkEvent.CustomFlags,
      screen_name: sdkEvent.EventName
    };
    screenViewEventData = Object.assign(screenViewEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.screenView,
      data: screenViewEventData
    };
  }
  function convertOptOutEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var optOutEventData = {
      is_opted_out: sdkEvent.OptOut
    };
    optOutEventData = Object.assign(optOutEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.optOut,
      data: optOutEventData
    };
  }
  function convertCustomEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var customEventData = {
      custom_event_type: convertSdkEventType(sdkEvent.EventCategory),
      custom_flags: sdkEvent.CustomFlags,
      event_name: sdkEvent.EventName
    };
    customEventData = Object.assign(customEventData, commonEventData);
    return {
      event_type: dist.EventTypeEnum.customEvent,
      data: customEventData
    };
  }
  function convertSdkEventType(sdkEventType) {
    switch (sdkEventType) {
      case Types.EventType.Other:
        return dist.CustomEventDataCustomEventTypeEnum.other;
      case Types.EventType.Location:
        return dist.CustomEventDataCustomEventTypeEnum.location;
      case Types.EventType.Navigation:
        return dist.CustomEventDataCustomEventTypeEnum.navigation;
      case Types.EventType.Search:
        return dist.CustomEventDataCustomEventTypeEnum.search;
      case Types.EventType.Social:
        return dist.CustomEventDataCustomEventTypeEnum.social;
      case Types.EventType.Transaction:
        return dist.CustomEventDataCustomEventTypeEnum.transaction;
      case Types.EventType.UserContent:
        return dist.CustomEventDataCustomEventTypeEnum.userContent;
      case Types.EventType.UserPreference:
        return dist.CustomEventDataCustomEventTypeEnum.userPreference;
      case Types.EventType.Media:
        return dist.CustomEventDataCustomEventTypeEnum.media;
      case Types.CommerceEventType.ProductAddToCart:
        return dist.CommerceEventDataCustomEventTypeEnum.addToCart;
      case Types.CommerceEventType.ProductAddToWishlist:
        return dist.CommerceEventDataCustomEventTypeEnum.addToWishlist;
      case Types.CommerceEventType.ProductCheckout:
        return dist.CommerceEventDataCustomEventTypeEnum.checkout;
      case Types.CommerceEventType.ProductCheckoutOption:
        return dist.CommerceEventDataCustomEventTypeEnum.checkoutOption;
      case Types.CommerceEventType.ProductClick:
        return dist.CommerceEventDataCustomEventTypeEnum.click;
      case Types.CommerceEventType.ProductImpression:
        return dist.CommerceEventDataCustomEventTypeEnum.impression;
      case Types.CommerceEventType.ProductPurchase:
        return dist.CommerceEventDataCustomEventTypeEnum.purchase;
      case Types.CommerceEventType.ProductRefund:
        return dist.CommerceEventDataCustomEventTypeEnum.refund;
      case Types.CommerceEventType.ProductRemoveFromCart:
        return dist.CommerceEventDataCustomEventTypeEnum.removeFromCart;
      case Types.CommerceEventType.ProductRemoveFromWishlist:
        return dist.CommerceEventDataCustomEventTypeEnum.removeFromWishlist;
      case Types.CommerceEventType.ProductViewDetail:
        return dist.CommerceEventDataCustomEventTypeEnum.viewDetail;
      case Types.CommerceEventType.PromotionClick:
        return dist.CommerceEventDataCustomEventTypeEnum.promotionClick;
      case Types.CommerceEventType.PromotionView:
        return dist.CommerceEventDataCustomEventTypeEnum.promotionView;
      default:
        return dist.CustomEventDataCustomEventTypeEnum.unknown;
    }
  }
  function convertBaseEventData(sdkEvent) {
    var commonEventData = {
      timestamp_unixtime_ms: sdkEvent.Timestamp,
      session_uuid: sdkEvent.SessionId,
      session_start_unixtime_ms: sdkEvent.SessionStartDate,
      custom_attributes: sdkEvent.EventAttributes,
      location: convertSDKLocation(sdkEvent.Location),
      source_message_id: sdkEvent.SourceMessageId,
      active_time_on_site_ms: sdkEvent.ActiveTimeOnSite,
      total_time_on_site_ms: sdkEvent.TotalTimeOnSite,
      page_url: sdkEvent.PageUrl
    };
    return commonEventData;
  }
  function convertSDKLocation(sdkEventLocation) {
    if (sdkEventLocation && Object.keys(sdkEventLocation).length) {
      return {
        latitude: sdkEventLocation.lat,
        longitude: sdkEventLocation.lng
      };
    }
    return null;
  }
  function convertUserAttributeChangeEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var userAttributeChangeEvent = {
      user_attribute_name: sdkEvent.UserAttributeChanges.UserAttributeName,
      "new": sdkEvent.UserAttributeChanges.New,
      old: sdkEvent.UserAttributeChanges.Old,
      deleted: sdkEvent.UserAttributeChanges.Deleted,
      is_new_attribute: sdkEvent.UserAttributeChanges.IsNewAttribute
    };
    userAttributeChangeEvent = __assign(__assign({}, userAttributeChangeEvent), commonEventData);
    return {
      event_type: dist.EventTypeEnum.userAttributeChange,
      data: userAttributeChangeEvent
    };
  }
  function convertUserIdentityChangeEvent(sdkEvent) {
    var commonEventData = convertBaseEventData(sdkEvent);
    var userIdentityChangeEvent = {
      "new": {
        identity_type: convertUserIdentityTypeToServerIdentityType(sdkEvent.UserIdentityChanges.New.IdentityType),
        identity: sdkEvent.UserIdentityChanges.New.Identity || null,
        timestamp_unixtime_ms: sdkEvent.Timestamp,
        created_this_batch: sdkEvent.UserIdentityChanges.New.CreatedThisBatch
      },
      old: {
        identity_type: convertUserIdentityTypeToServerIdentityType(sdkEvent.UserIdentityChanges.Old.IdentityType),
        identity: sdkEvent.UserIdentityChanges.Old.Identity || null,
        timestamp_unixtime_ms: sdkEvent.Timestamp,
        created_this_batch: sdkEvent.UserIdentityChanges.Old.CreatedThisBatch
      }
    };
    userIdentityChangeEvent = Object.assign(userIdentityChangeEvent, commonEventData);
    return {
      event_type: dist.EventTypeEnum.userIdentityChange,
      data: userIdentityChangeEvent
    };
  }
  function convertUserIdentityTypeToServerIdentityType(identityType) {
    switch (identityType) {
      case SDKIdentityTypeEnum.other:
        return dist.IdentityTypeEnum.other;
      case SDKIdentityTypeEnum.customerId:
        return dist.IdentityTypeEnum.customerId;
      case SDKIdentityTypeEnum.facebook:
        return dist.IdentityTypeEnum.facebook;
      case SDKIdentityTypeEnum.twitter:
        return dist.IdentityTypeEnum.twitter;
      case SDKIdentityTypeEnum.google:
        return dist.IdentityTypeEnum.google;
      case SDKIdentityTypeEnum.microsoft:
        return dist.IdentityTypeEnum.microsoft;
      case SDKIdentityTypeEnum.yahoo:
        return dist.IdentityTypeEnum.yahoo;
      case SDKIdentityTypeEnum.email:
        return dist.IdentityTypeEnum.email;
      case SDKIdentityTypeEnum.alias:
        return dist.IdentityTypeEnum.alias;
      case SDKIdentityTypeEnum.facebookCustomAudienceId:
        return dist.IdentityTypeEnum.facebookCustomAudienceId;
      case SDKIdentityTypeEnum.otherId2:
        return dist.IdentityTypeEnum.otherId2;
      case SDKIdentityTypeEnum.otherId3:
        return dist.IdentityTypeEnum.otherId3;
      case SDKIdentityTypeEnum.otherId4:
        return dist.IdentityTypeEnum.otherId4;
      case SDKIdentityTypeEnum.otherId5:
        return dist.IdentityTypeEnum.otherId5;
      case SDKIdentityTypeEnum.otherId6:
        return dist.IdentityTypeEnum.otherId6;
      case SDKIdentityTypeEnum.otherId7:
        return dist.IdentityTypeEnum.otherId7;
      case SDKIdentityTypeEnum.otherId8:
        return dist.IdentityTypeEnum.otherId8;
      case SDKIdentityTypeEnum.otherId9:
        return dist.IdentityTypeEnum.otherId9;
      case SDKIdentityTypeEnum.otherId10:
        return dist.IdentityTypeEnum.otherId10;
      case SDKIdentityTypeEnum.mobileNumber:
        return dist.IdentityTypeEnum.mobileNumber;
      case SDKIdentityTypeEnum.phoneNumber2:
        return dist.IdentityTypeEnum.phoneNumber2;
      case SDKIdentityTypeEnum.phoneNumber3:
        return dist.IdentityTypeEnum.phoneNumber3;
    }
  }
  var StorageResult;
  (function(StorageResult2) {
    StorageResult2["Success"] = "Success";
    StorageResult2["QuotaExceeded"] = "QuotaExceeded";
    StorageResult2["Unavailable"] = "Unavailable";
  })(StorageResult || (StorageResult = {}));
  var isQuotaExceededError = function isQuotaExceededError2(e) {
    return e instanceof DOMException && // Standard quota errors, plus Firefox's legacy name/code.
    (e.code === 22 || e.code === 1014 || e.name === "QuotaExceededError" || e.name === "NS_ERROR_DOM_QUOTA_REACHED");
  };
  var BaseVault = (
    /** @class */
    (function() {
      function BaseVault2(storageKey, storageObject) {
        this._storageKey = storageKey;
        this.storageObject = storageObject;
        this.contents = this.retrieve();
      }
      BaseVault2.prototype.store = function(item) {
        var stringifiedItem;
        try {
          if (isNumber(item) || !isEmpty(item)) {
            stringifiedItem = JSON.stringify(item);
          } else {
            stringifiedItem = "";
          }
          this.storageObject.setItem(this._storageKey, stringifiedItem);
          this.contents = item;
          return StorageResult.Success;
        } catch (e) {
          return isQuotaExceededError(e) ? StorageResult.QuotaExceeded : StorageResult.Unavailable;
        }
      };
      BaseVault2.prototype.retrieve = function() {
        try {
          var item = this.storageObject.getItem(this._storageKey);
          this.contents = item ? JSON.parse(item) : null;
        } catch (e) {
          this.contents = null;
        }
        return this.contents;
      };
      BaseVault2.prototype.purge = function() {
        this.contents = null;
        try {
          this.storageObject.removeItem(this._storageKey);
        } catch (e) {
        }
      };
      return BaseVault2;
    })()
  );
  var LocalStorageVault = (
    /** @class */
    (function(_super) {
      __extends(LocalStorageVault2, _super);
      function LocalStorageVault2(storageKey) {
        return _super.call(this, storageKey, window.localStorage) || this;
      }
      return LocalStorageVault2;
    })(BaseVault)
  );
  var SessionStorageVault = (
    /** @class */
    (function(_super) {
      __extends(SessionStorageVault2, _super);
      function SessionStorageVault2(storageKey) {
        return _super.call(this, storageKey, window.sessionStorage) || this;
      }
      return SessionStorageVault2;
    })(BaseVault)
  );
  var DisabledVault = (
    /** @class */
    (function(_super) {
      __extends(DisabledVault2, _super);
      function DisabledVault2(storageKey) {
        var _this = _super.call(this, storageKey, window.localStorage) || this;
        _this.contents = null;
        _this.storageObject.removeItem(_this._storageKey);
        return _this;
      }
      DisabledVault2.prototype.store = function(_item) {
        this.contents = null;
        return StorageResult.Success;
      };
      DisabledVault2.prototype.retrieve = function() {
        return this.contents;
      };
      DisabledVault2.prototype.purge = function() {
        this.contents = null;
      };
      return DisabledVault2;
    })(BaseVault)
  );
  var AsyncUploader = (
    /** @class */
    /* @__PURE__ */ (function() {
      function AsyncUploader2(url) {
        this.url = url;
      }
      return AsyncUploader2;
    })()
  );
  var FetchUploader = (
    /** @class */
    (function(_super) {
      __extends(FetchUploader2, _super);
      function FetchUploader2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      FetchUploader2.prototype.upload = function(fetchPayload, _url) {
        return __awaiter(this, void 0, void 0, function() {
          var url;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                url = _url || this.url;
                return [4, fetch(url, fetchPayload)];
              case 1:
                return [2, _a2.sent()];
            }
          });
        });
      };
      return FetchUploader2;
    })(AsyncUploader)
  );
  var XHRUploader = (
    /** @class */
    (function(_super) {
      __extends(XHRUploader2, _super);
      function XHRUploader2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      XHRUploader2.prototype.upload = function(fetchPayload) {
        return __awaiter(this, void 0, void 0, function() {
          var response;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                return [4, this.makeRequest(this.url, fetchPayload.body, fetchPayload.method, fetchPayload.headers)];
              case 1:
                response = _a2.sent();
                return [2, response];
            }
          });
        });
      };
      XHRUploader2.prototype.makeRequest = function(url, data, method, headers) {
        if (method === void 0) {
          method = "post";
        }
        if (headers === void 0) {
          headers = {};
        }
        return __awaiter(this, void 0, void 0, function() {
          var xhr;
          return __generator(this, function(_a2) {
            xhr = new XMLHttpRequest();
            return [2, new Promise(function(resolve, reject) {
              xhr.onreadystatechange = function() {
                if (xhr.readyState !== 4) return;
                resolve(xhr);
              };
              xhr.onerror = function() {
                reject(xhr);
              };
              xhr.open(method, url);
              for (var key in headers) {
                if (headers.hasOwnProperty(key)) {
                  xhr.setRequestHeader(key, headers[key]);
                }
              }
              xhr.send(data);
            })];
          });
        });
      };
      return XHRUploader2;
    })(AsyncUploader)
  );
  function hasMPIDAndUserLoginChanged(previousUser, newUser) {
    return !previousUser || newUser.getMPID() !== previousUser.getMPID() || previousUser.isLoggedIn() !== newUser.isLoggedIn();
  }
  function hasMPIDChanged(prevUser, identityApiResult) {
    return !prevUser || prevUser.getMPID() && identityApiResult.mpid && identityApiResult.mpid !== prevUser.getMPID();
  }
  function appendUserInfo(user, event) {
    if (!event) {
      return;
    }
    if (!user) {
      event.MPID = null;
      event.ConsentState = null;
      event.UserAttributes = null;
      event.UserIdentities = null;
      return;
    }
    if (event.MPID && event.MPID === user.getMPID()) {
      return;
    }
    event.MPID = user.getMPID();
    event.ConsentState = user.getConsentState();
    event.UserAttributes = user.getAllUserAttributes();
    var userIdentities = user.getUserIdentities().userIdentities;
    var dtoUserIdentities = {};
    for (var identityKey in userIdentities) {
      var identityType = Types.IdentityType.getIdentityType(identityKey);
      if (identityType !== false) {
        dtoUserIdentities[identityType] = userIdentities[identityKey];
      }
    }
    var validUserIdentities = [];
    if (isObject(dtoUserIdentities)) {
      if (Object.keys(dtoUserIdentities).length) {
        for (var key in dtoUserIdentities) {
          var userIdentity = {};
          userIdentity.Identity = dtoUserIdentities[key];
          userIdentity.Type = parseNumber(key);
          validUserIdentities.push(userIdentity);
        }
      }
    }
    event.UserIdentities = validUserIdentities;
  }
  var BatchUploader = (
    /** @class */
    (function() {
      function BatchUploader2(mpInstance, uploadInterval) {
        var _a2;
        var _b2, _c;
        this.offlineStorageEnabled = false;
        this.lastASTEventTime = 0;
        this.AST_DEBOUNCE_MS = 1e3;
        this.uploadIntervalTimerId = null;
        this.exitHandler = null;
        this.visibilityChangeHandler = null;
        this.destroyed = false;
        this.mpInstance = mpInstance;
        this.uploadIntervalMillis = uploadInterval;
        this.batchingEnabled = uploadInterval >= BatchUploader2.MINIMUM_INTERVAL_MILLIS;
        if (this.uploadIntervalMillis < BatchUploader2.MINIMUM_INTERVAL_MILLIS) {
          this.uploadIntervalMillis = BatchUploader2.MINIMUM_INTERVAL_MILLIS;
        }
        this.eventsQueuedForProcessing = [];
        this.batchesQueuedForProcessing = [];
        this.offlineStorageEnabled = this.isOfflineStorageAvailable();
        var noFunctional = (_b2 = mpInstance._CookieConsentManager) === null || _b2 === void 0 ? void 0 : _b2.getNoFunctional();
        if (this.offlineStorageEnabled && !noFunctional) {
          this.eventVault = new SessionStorageVault("".concat(mpInstance._Store.storageName, "-events"));
          this.batchVault = new LocalStorageVault("".concat(mpInstance._Store.storageName, "-batches"));
          (_a2 = this.eventsQueuedForProcessing).push.apply(_a2, (_c = this.eventVault.retrieve()) !== null && _c !== void 0 ? _c : []);
        }
        var _d = this.mpInstance._Store, SDKConfig = _d.SDKConfig, devToken = _d.devToken;
        var baseUrl = this.mpInstance._Helpers.createServiceUrl(SDKConfig.v3SecureServiceUrl, devToken);
        this.uploadUrl = "".concat(baseUrl, "/events");
        this.uploader = window.fetch ? new FetchUploader(this.uploadUrl) : new XHRUploader(this.uploadUrl);
        this.triggerUploadInterval(true, false);
        this.addEventListeners();
      }
      BatchUploader2.prototype.destroy = function() {
        this.destroyed = true;
        if (this.uploadIntervalTimerId !== null) {
          clearTimeout(this.uploadIntervalTimerId);
          this.uploadIntervalTimerId = null;
        }
        if (this.visibilityChangeHandler) {
          document.removeEventListener("visibilitychange", this.visibilityChangeHandler);
        }
        if (this.exitHandler) {
          window.removeEventListener("beforeunload", this.exitHandler);
          window.removeEventListener("pagehide", this.exitHandler);
        }
        this.exitHandler = null;
        this.visibilityChangeHandler = null;
      };
      BatchUploader2.prototype.isOfflineStorageAvailable = function() {
        var _a2 = this.mpInstance, getFeatureFlag = _a2._Helpers.getFeatureFlag, deviceId = _a2._Store.deviceId;
        var offlineStorageFeatureFlagValue = getFeatureFlag(Constants.FeatureFlags.OfflineStorage);
        var offlineStoragePercentage = parseInt(offlineStorageFeatureFlagValue, 10);
        var rampNumber = getRampNumber(deviceId);
        return offlineStoragePercentage >= rampNumber;
      };
      BatchUploader2.prototype.shouldDebounceAndUpdateLastASTTime = function() {
        var now = Date.now();
        if (now - this.lastASTEventTime < this.AST_DEBOUNCE_MS) {
          return true;
        }
        this.lastASTEventTime = now;
        return false;
      };
      BatchUploader2.prototype.createBackgroundASTEvent = function() {
        var _a2;
        var now = Date.now();
        var _b2 = this.mpInstance, _Store = _b2._Store, Identity2 = _b2.Identity, _timeOnSiteTimer = _b2._timeOnSiteTimer, _Helpers = _b2._Helpers;
        var sessionId = _Store.sessionId, deviceId = _Store.deviceId, sessionStartDate = _Store.sessionStartDate, SDKConfig = _Store.SDKConfig;
        var generateUniqueId2 = _Helpers.generateUniqueId, getFeatureFlag = _Helpers.getFeatureFlag;
        var getCurrentUser = Identity2.getCurrentUser;
        var event = {
          AppName: SDKConfig.appName,
          AppVersion: SDKConfig.appVersion,
          Package: SDKConfig["package"],
          EventDataType: MessageType$1.AppStateTransition,
          Timestamp: now,
          SessionId: sessionId,
          DeviceId: deviceId,
          IsFirstRun: false,
          SourceMessageId: generateUniqueId2(),
          SDKVersion: Constants.sdkVersion,
          CustomFlags: {},
          EventAttributes: {},
          SessionStartDate: (sessionStartDate === null || sessionStartDate === void 0 ? void 0 : sessionStartDate.getTime()) || now,
          Debug: SDKConfig.isDevelopmentMode,
          ActiveTimeOnSite: (_timeOnSiteTimer === null || _timeOnSiteTimer === void 0 ? void 0 : _timeOnSiteTimer.getTimeInForeground()) || 0,
          TotalTimeOnSite: ((_a2 = _Store.getTotalTimeOnSite) === null || _a2 === void 0 ? void 0 : _a2.call(_Store)) || 0,
          PageUrl: getHref() || null,
          IsBackgroundAST: true
        };
        var customFlags = __assign({}, event.CustomFlags);
        var integrationAttributes = _Store.integrationAttributes;
        var integrationSpecificIds = getFeatureFlag(Constants.FeatureFlags.CaptureIntegrationSpecificIds);
        var integrationSpecificIdsV2 = getFeatureFlag(Constants.FeatureFlags.CaptureIntegrationSpecificIdsV2) || "";
        var isIntegrationCaptureEnabled = integrationSpecificIdsV2 && integrationSpecificIdsV2 !== Constants.CaptureIntegrationSpecificIdsV2Modes.None || integrationSpecificIds === true;
        if (isIntegrationCaptureEnabled) {
          this.mpInstance._IntegrationCapture.capture();
          var transformedClickIDs = this.mpInstance._IntegrationCapture.getClickIdsAsCustomFlags();
          customFlags = __assign(__assign({}, transformedClickIDs), customFlags);
          var transformedIntegrationAttributes = this.mpInstance._IntegrationCapture.getClickIdsAsIntegrationAttributes();
          integrationAttributes = __assign(__assign({}, transformedIntegrationAttributes), integrationAttributes);
        }
        event.CustomFlags = customFlags;
        event.IntegrationAttributes = integrationAttributes;
        appendUserInfo(getCurrentUser(), event);
        return event;
      };
      BatchUploader2.prototype.addEventListeners = function() {
        var _this_1 = this;
        var _this = this;
        var handleExit = function handleExit2() {
          var getFeatureFlag = _this_1.mpInstance._Helpers.getFeatureFlag;
          var AstBackgroundEvents = Constants.FeatureFlags.AstBackgroundEvents;
          if (getFeatureFlag(AstBackgroundEvents)) {
            if (_this.shouldDebounceAndUpdateLastASTTime()) {
              return;
            }
            var event_1 = _this.createBackgroundASTEvent();
            _this.queueEvent(event_1);
          }
          _this.prepareAndUpload(false, _this.isBeaconAvailable());
        };
        this.exitHandler = handleExit;
        this.visibilityChangeHandler = function() {
          if (document.visibilityState === "hidden") {
            handleExit();
          }
        };
        document.addEventListener("visibilitychange", this.visibilityChangeHandler);
        window.addEventListener("beforeunload", handleExit);
        window.addEventListener("pagehide", handleExit);
      };
      BatchUploader2.prototype.isBeaconAvailable = function() {
        if (navigator.sendBeacon) {
          return true;
        }
        return false;
      };
      BatchUploader2.prototype.triggerUploadInterval = function(triggerFuture, useBeacon) {
        var _this_1 = this;
        if (triggerFuture === void 0) {
          triggerFuture = false;
        }
        if (useBeacon === void 0) {
          useBeacon = false;
        }
        this.uploadIntervalTimerId = setTimeout(function() {
          _this_1.prepareAndUpload(triggerFuture, useBeacon);
        }, this.uploadIntervalMillis);
      };
      BatchUploader2.prototype.queueEvent = function(event) {
        if (isEmpty(event)) {
          return;
        }
        this.eventsQueuedForProcessing.push(event);
        if (this.offlineStorageEnabled && this.eventVault) {
          this.eventVault.store(this.eventsQueuedForProcessing);
        }
        if (this.mpInstance.Logger.isVerbose()) {
          var eventToLog = obfuscateDevData(event, this.mpInstance._Store.SDKConfig.isDevelopmentMode);
          this.mpInstance.Logger.verbose("Queuing event: ".concat(JSON.stringify(eventToLog)));
          this.mpInstance.Logger.verbose("Queued event count: ".concat(this.eventsQueuedForProcessing.length));
        }
        if (this.shouldTriggerImmediateUpload(event.EventDataType)) {
          this.prepareAndUpload(false, false);
        }
      };
      BatchUploader2.prototype.shouldTriggerImmediateUpload = function(eventDataType) {
        var priorityEvents = [MessageType$1.Commerce, MessageType$1.UserIdentityChange];
        return !this.batchingEnabled || priorityEvents.includes(eventDataType);
      };
      BatchUploader2.createNewBatches = function(sdkEvents, defaultUser, mpInstance) {
        if (!defaultUser || !sdkEvents || !sdkEvents.length) {
          return null;
        }
        var newUploads = [];
        var eventsByUser = /* @__PURE__ */ new Map();
        for (var _i = 0, sdkEvents_1 = sdkEvents; _i < sdkEvents_1.length; _i++) {
          var sdkEvent = sdkEvents_1[_i];
          if (!sdkEvent.MPID) {
            var mpid = defaultUser.getMPID();
            sdkEvent.MPID = mpid;
          }
          var events = eventsByUser.get(sdkEvent.MPID);
          if (!events) {
            events = [];
          }
          events.push(sdkEvent);
          eventsByUser.set(sdkEvent.MPID, events);
        }
        for (var _a2 = 0, _b2 = Array.from(eventsByUser.entries()); _a2 < _b2.length; _a2++) {
          var entry = _b2[_a2];
          var mpid = entry[0];
          var userEvents = entry[1];
          var eventsBySession = /* @__PURE__ */ new Map();
          for (var _c = 0, userEvents_1 = userEvents; _c < userEvents_1.length; _c++) {
            var sdkEvent = userEvents_1[_c];
            var events = eventsBySession.get(sdkEvent.SessionId);
            if (!events) {
              events = [];
            }
            events.push(sdkEvent);
            eventsBySession.set(sdkEvent.SessionId, events);
          }
          for (var _d = 0, _e = Array.from(eventsBySession.entries()); _d < _e.length; _d++) {
            var entry_1 = _e[_d];
            var uploadBatchObject = convertEvents(mpid, entry_1[1], mpInstance);
            var onCreateBatchCallback = mpInstance._Store.SDKConfig.onCreateBatch;
            if (onCreateBatchCallback) {
              uploadBatchObject = onCreateBatchCallback(uploadBatchObject);
              if (uploadBatchObject) {
                uploadBatchObject.modified = true;
              } else {
                mpInstance.Logger.warning("Skiping batch upload because no batch was returned from onCreateBatch callback");
              }
            }
            if (uploadBatchObject) {
              newUploads.push(uploadBatchObject);
            }
          }
        }
        return newUploads;
      };
      BatchUploader2.prototype.prepareAndUpload = function(triggerFuture, useBeacon) {
        var _a2;
        if (triggerFuture === void 0) {
          triggerFuture = false;
        }
        if (useBeacon === void 0) {
          useBeacon = false;
        }
        return __awaiter(this, void 0, void 0, function() {
          var currentUser, currentEvents, newBatches, batchesToUpload, batchesThatDidNotUpload;
          var _b2, _c, _d;
          return __generator(this, function(_e) {
            switch (_e.label) {
              case 0:
                currentUser = this.mpInstance.Identity.getCurrentUser();
                currentEvents = this.eventsQueuedForProcessing;
                this.eventsQueuedForProcessing = [];
                if (this.offlineStorageEnabled && this.eventVault) {
                  this.eventVault.store([]);
                }
                newBatches = [];
                if (!isEmpty(currentEvents)) {
                  newBatches = BatchUploader2.createNewBatches(currentEvents, currentUser, this.mpInstance);
                }
                if (this.offlineStorageEnabled && this.batchVault) {
                  (_b2 = this.batchesQueuedForProcessing).unshift.apply(_b2, (_a2 = this.batchVault.retrieve()) !== null && _a2 !== void 0 ? _a2 : []);
                  this.batchVault.purge();
                }
                if (!isEmpty(newBatches)) {
                  (_c = this.batchesQueuedForProcessing).push.apply(_c, newBatches);
                }
                batchesToUpload = this.batchesQueuedForProcessing;
                this.batchesQueuedForProcessing = [];
                return [4, this.uploadBatches(batchesToUpload, useBeacon)];
              case 1:
                batchesThatDidNotUpload = _e.sent();
                if (!isEmpty(batchesThatDidNotUpload)) {
                  (_d = this.batchesQueuedForProcessing).unshift.apply(_d, batchesThatDidNotUpload);
                }
                if (!useBeacon && this.offlineStorageEnabled && this.batchVault) {
                  this.storeBatchesQueuedForProcessing();
                }
                if (triggerFuture && !this.destroyed) {
                  this.triggerUploadInterval(triggerFuture, false);
                }
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      BatchUploader2.prototype.storeBatchesQueuedForProcessing = function() {
        var batches = this.batchesQueuedForProcessing;
        if (isEmpty(batches)) {
          this.batchVault.store([]);
          this.batchesQueuedForProcessing = [];
          return;
        }
        for (var dropped = 0; dropped < batches.length; dropped++) {
          var result = this.batchVault.store(batches.slice(dropped));
          if (result === StorageResult.Success) {
            this.logDroppedOfflineBatches(dropped);
            this.batchesQueuedForProcessing = [];
            return;
          }
          if (result === StorageResult.Unavailable) {
            this.mpInstance.Logger.warning("Offline batch storage is unavailable. Retaining batches in memory.");
            return;
          }
        }
        this.mpInstance.Logger.warning("Offline batch storage is over quota. Retaining batches in memory.");
      };
      BatchUploader2.prototype.logDroppedOfflineBatches = function(droppedBatchCount) {
        if (droppedBatchCount > 0) {
          this.mpInstance.Logger.warning("Offline batch storage is over quota. Dropped " + "".concat(droppedBatchCount, " oldest batch(es)."));
        }
      };
      BatchUploader2.prototype.uploadBatches = function(batches, useBeacon) {
        return __awaiter(this, void 0, void 0, function() {
          var uploads, uploadsToLog, i, fetchPayload, blob, response, e_1;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                uploads = batches.filter(function(batch) {
                  return !isEmpty(batch.events);
                });
                if (isEmpty(uploads)) {
                  return [2, null];
                }
                if (this.mpInstance.Logger.isVerbose()) {
                  uploadsToLog = obfuscateDevData(uploads, this.mpInstance._Store.SDKConfig.isDevelopmentMode);
                  this.mpInstance.Logger.verbose("Uploading batches: ".concat(JSON.stringify(uploadsToLog)));
                  this.mpInstance.Logger.verbose("Batch count: ".concat(uploads.length));
                }
                i = 0;
                _a2.label = 1;
              case 1:
                if (!(i < uploads.length)) return [3, 6];
                fetchPayload = {
                  method: "POST",
                  headers: {
                    Accept: BatchUploader2.CONTENT_TYPE,
                    "Content-Type": "text/plain;charset=UTF-8"
                  },
                  body: JSON.stringify(uploads[i])
                };
                if (!(useBeacon && this.isBeaconAvailable())) return [3, 2];
                blob = new Blob([fetchPayload.body], {
                  type: "text/plain;charset=UTF-8"
                });
                navigator.sendBeacon(this.uploadUrl, blob);
                return [3, 5];
              case 2:
                _a2.trys.push([2, 4, , 5]);
                return [4, this.uploader.upload(fetchPayload)];
              case 3:
                response = _a2.sent();
                if (response.status >= 200 && response.status < 300) {
                  this.mpInstance.Logger.verbose("Upload success for request ID: ".concat(uploads[i].source_request_id));
                } else if (response.status >= 500 || response.status === 429) {
                  this.mpInstance.Logger.error("HTTP error status ".concat(response.status, " received"));
                  return [2, uploads.slice(i, uploads.length)];
                } else if (response.status >= 401) {
                  this.mpInstance.Logger.error("HTTP error status ".concat(response.status, " while uploading - please verify your API key."));
                  return [2, null];
                } else {
                  console.error("HTTP error status ".concat(response.status, " while uploading events."), response);
                  throw new Error("Uncaught HTTP Error ".concat(response.status, ".  Batch upload will be re-attempted."));
                }
                return [3, 5];
              case 4:
                e_1 = _a2.sent();
                this.mpInstance.Logger.error("Error sending event to mParticle servers. ".concat(e_1));
                return [2, uploads.slice(i, uploads.length)];
              case 5:
                i++;
                return [3, 1];
              case 6:
                return [2, null];
            }
          });
        });
      };
      BatchUploader2.CONTENT_TYPE = "text/plain;charset=UTF-8";
      BatchUploader2.MINIMUM_INTERVAL_MILLIS = 500;
      return BatchUploader2;
    })()
  );
  var ErrorCodes = {
    UNKNOWN_ERROR: "UNKNOWN_ERROR",
    UNHANDLED_EXCEPTION: "UNHANDLED_EXCEPTION",
    IDENTITY_REQUEST: "IDENTITY_REQUEST",
    IDENTITY_MISMATCH: "IDENTITY_MISMATCH",
    MP_DEPRECATED_METHOD_USAGE: "MP_DEPRECATED_METHOD_USAGE"
  };
  var WSDKErrorSeverity = {
    ERROR: "ERROR",
    INFO: "INFO",
    WARNING: "WARNING"
  };
  var Modify$4 = Constants.IdentityMethods.Modify;
  var Validators = {
    // From ./utils
    // Utility Functions for backwards compatability
    isNumber,
    isFunction,
    isStringOrNumber,
    // Validator Functions
    isValidAttributeValue,
    // Validator Functions
    // Neither null nor undefined can be a valid Key
    isValidKeyValue: function isValidKeyValue(key) {
      return Boolean(key && !isObject(key) && !Array.isArray(key) && !this.isFunction(key));
    },
    removeFalsyIdentityValues: function removeFalsyIdentityValues(identityApiData, logger) {
      if (!identityApiData || !identityApiData.userIdentities) {
        return identityApiData;
      }
      var cleanedData = {};
      var cleanedUserIdentities = __assign({}, identityApiData.userIdentities);
      for (var identityType in identityApiData.userIdentities) {
        if (identityApiData.userIdentities.hasOwnProperty(identityType)) {
          var value = identityApiData.userIdentities[identityType];
          if (value !== null && !value) {
            logger.warning("Identity value for '".concat(identityType, "' is falsy (").concat(value, "). This value will be removed from the request."));
            delete cleanedUserIdentities[identityType];
          }
        }
      }
      cleanedData.userIdentities = cleanedUserIdentities;
      return cleanedData;
    },
    validateIdentities: function validateIdentities(identityApiData, method) {
      var validIdentityRequestKeys = {
        userIdentities: 1,
        onUserAlias: 1,
        copyUserAttributes: 1
      };
      if (identityApiData) {
        if (method === Modify$4) {
          if (isObject(identityApiData.userIdentities) && !Object.keys(identityApiData.userIdentities).length || !isObject(identityApiData.userIdentities)) {
            return {
              valid: false,
              error: Constants.Messages.ValidationMessages.ModifyIdentityRequestUserIdentitiesPresent
            };
          }
        }
        for (var key in identityApiData) {
          if (identityApiData.hasOwnProperty(key)) {
            if (!validIdentityRequestKeys[key]) {
              return {
                valid: false,
                error: Constants.Messages.ValidationMessages.IdentityRequesetInvalidKey
              };
            }
            if (key === "onUserAlias" && !Validators.isFunction(identityApiData[key])) {
              return {
                valid: false,
                error: Constants.Messages.ValidationMessages.OnUserAliasType
              };
            }
          }
        }
        if (Object.keys(identityApiData).length === 0) {
          return {
            valid: true
          };
        } else {
          if (identityApiData.userIdentities === void 0) {
            return {
              valid: false,
              error: Constants.Messages.ValidationMessages.UserIdentities
            };
          } else if (identityApiData.userIdentities !== null && !isObject(identityApiData.userIdentities)) {
            return {
              valid: false,
              error: Constants.Messages.ValidationMessages.UserIdentities
            };
          }
          if (isObject(identityApiData.userIdentities) && Object.keys(identityApiData.userIdentities).length) {
            for (var identityType in identityApiData.userIdentities) {
              if (identityApiData.userIdentities.hasOwnProperty(identityType)) {
                if (Types.IdentityType.getIdentityType(identityType) === false) {
                  return {
                    valid: false,
                    error: Constants.Messages.ValidationMessages.UserIdentitiesInvalidKey
                  };
                }
                if (!(typeof identityApiData.userIdentities[identityType] === "string" || identityApiData.userIdentities[identityType] === null)) {
                  return {
                    valid: false,
                    error: Constants.Messages.ValidationMessages.UserIdentitiesInvalidValues
                  };
                }
              }
            }
          }
        }
      }
      return {
        valid: true
      };
    }
  };
  var HTTPCodes$4 = Constants.HTTPCodes;
  var sendSearchRequest = function sendSearchRequest2(knownIdentities, apiKey, requestBuilder, searchUrl, callback, logger, uploader, errorReporter) {
    return __awaiter(void 0, void 0, void 0, function() {
      var safeInvoke, cleanedKnownIdentities, requestEnvelope, requestBody, fetchPayload, api, response, body, xhrLike, e_2, message, reportMessage;
      return __generator(this, function(_a2) {
        switch (_a2.label) {
          case 0:
            if (!isFunction(callback)) {
              logger.error("search called without a callback function; skipping request.");
              return [
                2
                /*return*/
              ];
            }
            safeInvoke = function safeInvoke2(result) {
              try {
                callback(result);
              } catch (e) {
                logger.error("Error invoking search callback: " + getErrorMessage(e));
              }
            };
            cleanedKnownIdentities = Validators.removeFalsyIdentityValues({
              userIdentities: knownIdentities !== null && knownIdentities !== void 0 ? knownIdentities : {}
            }, logger).userIdentities;
            if (!Object.values(cleanedKnownIdentities !== null && cleanedKnownIdentities !== void 0 ? cleanedKnownIdentities : {}).some(function(v) {
              return typeof v === "string" && v.length > 0;
            })) {
              logger.verbose("Identity search called with empty identifiers; skipping request.");
              safeInvoke({
                httpCode: HTTPCodes$4.noHttpCoverage
              });
              return [
                2
                /*return*/
              ];
            }
            if (!apiKey) {
              logger.verbose("search called without a workspace API key; skipping request.");
              safeInvoke({
                httpCode: HTTPCodes$4.noHttpCoverage
              });
              return [
                2
                /*return*/
              ];
            }
            _a2.label = 1;
          case 1:
            _a2.trys.push([1, 9, , 10]);
            requestEnvelope = requestBuilder();
            requestBody = __assign(__assign({}, requestEnvelope), {
              known_identities: __assign({}, cleanedKnownIdentities)
            });
            fetchPayload = {
              method: "post",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                "x-mp-key": apiKey
              },
              body: JSON.stringify(requestBody)
            };
            api = uploader || (window.fetch ? new FetchUploader(searchUrl) : new XHRUploader(searchUrl));
            logger.verbose("Sending search request to " + searchUrl);
            return [4, api.upload(fetchPayload, searchUrl)];
          case 2:
            response = _a2.sent();
            body = void 0;
            if (!isFunction(response.json)) return [3, 7];
            _a2.label = 3;
          case 3:
            _a2.trys.push([3, 5, , 6]);
            return [4, response.json()];
          case 4:
            body = _a2.sent();
            return [3, 6];
          case 5:
            _a2.sent();
            logger.verbose("search response had no parseable JSON body.");
            return [3, 6];
          case 6:
            return [3, 8];
          case 7:
            xhrLike = response;
            if (xhrLike === null || xhrLike === void 0 ? void 0 : xhrLike.responseText) {
              try {
                body = JSON.parse(xhrLike.responseText);
              } catch (e) {
                logger.verbose("search XHR response was not valid JSON.");
              }
            }
            _a2.label = 8;
          case 8:
            if (response.status === HTTP_OK) {
              logger.verbose("search received 200 OK.");
            } else if (response.status === HTTP_NOT_FOUND) {
              logger.verbose("search received 404 (no match).");
            } else {
              logger.verbose("search received non-success status " + response.status);
            }
            safeInvoke({
              httpCode: response.status,
              body
            });
            return [3, 10];
          case 9:
            e_2 = _a2.sent();
            message = getErrorMessage(e_2);
            reportMessage = "Error sending search request: " + message;
            logger.error(reportMessage);
            errorReporter === null || errorReporter === void 0 ? void 0 : errorReporter.report({
              message: reportMessage,
              code: ErrorCodes.IDENTITY_REQUEST,
              severity: WSDKErrorSeverity.ERROR
            });
            safeInvoke({
              httpCode: HTTPCodes$4.noHttpCoverage
            });
            return [3, 10];
          case 10:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  };
  var _a$1 = Constants.IdentityMethods, Identify$2 = _a$1.Identify, Modify$3 = _a$1.Modify, Login$2 = _a$1.Login, Logout$2 = _a$1.Logout;
  var HTTPCodes$3 = Constants.HTTPCodes, Messages$9 = Constants.Messages;
  var CACHE_HEADER = "x-mp-max-age";
  var cacheOrClearIdCache = function cacheOrClearIdCache2(method, knownIdentities, idCache, identityResponse, parsingCachedResponse) {
    if (parsingCachedResponse) {
      return;
    }
    var expireTimestamp = getExpireTimestamp(identityResponse === null || identityResponse === void 0 ? void 0 : identityResponse.cacheMaxAge);
    switch (method) {
      case Login$2:
      case Identify$2:
        cacheIdentityRequest(method, knownIdentities, expireTimestamp, idCache, identityResponse);
        break;
      case Modify$3:
      case Logout$2:
        idCache.purge();
        break;
    }
  };
  var cacheIdentityRequest = function cacheIdentityRequest2(method, identities, expireTimestamp, idCache, identityResponse) {
    var responseText = identityResponse.responseText, status = identityResponse.status;
    var cache = idCache.retrieve() || {};
    var cacheKey = concatenateIdentities(method, identities);
    var hashedKey = generateHash(cacheKey);
    var mpid = responseText.mpid, is_logged_in = responseText.is_logged_in;
    var cachedResponseBody = {
      mpid,
      is_logged_in
    };
    cache[hashedKey] = {
      responseText: JSON.stringify(cachedResponseBody),
      status,
      expireTimestamp
    };
    idCache.store(cache);
  };
  var concatenateIdentities = function concatenateIdentities2(method, userIdentities) {
    var DEVICE_APPLICATION_STAMP = "device_application_stamp";
    var cacheKey = "".concat(method, ":").concat(DEVICE_APPLICATION_STAMP, "=").concat(userIdentities.device_application_stamp, ";");
    var idLength = Object.keys(userIdentities).length;
    var concatenatedIdentities = "";
    if (idLength) {
      var userIDArray = new Array();
      for (var key in userIdentities) {
        if (key === DEVICE_APPLICATION_STAMP) {
          continue;
        } else {
          userIDArray[Types.IdentityType.getIdentityType(key)] = userIdentities[key];
        }
      }
      concatenatedIdentities = userIDArray.reduce(function(prevValue, currentValue, index) {
        var idName = Types.IdentityType.getIdentityName(index);
        return "".concat(prevValue).concat(idName, "=").concat(currentValue, ";");
      }, cacheKey);
    }
    return concatenatedIdentities;
  };
  var hasValidCachedIdentity = function hasValidCachedIdentity2(method, proposedUserIdentities, idCache) {
    var cache = idCache === null || idCache === void 0 ? void 0 : idCache.retrieve();
    if (!cache) {
      return false;
    }
    var cacheKey = concatenateIdentities(method, proposedUserIdentities);
    var hashedKey = generateHash(cacheKey);
    if (!cache.hasOwnProperty(hashedKey)) {
      return false;
    }
    var expireTimestamp = cache[hashedKey].expireTimestamp;
    if (expireTimestamp < (/* @__PURE__ */ new Date()).getTime()) {
      return false;
    } else {
      return true;
    }
  };
  var getCachedIdentity = function getCachedIdentity2(method, proposedUserIdentities, idCache) {
    var cacheKey = concatenateIdentities(method, proposedUserIdentities);
    var hashedKey = generateHash(cacheKey);
    var cache = idCache.retrieve();
    var cachedIdentity = cache ? cache[hashedKey] : null;
    return {
      responseText: parseIdentityResponse(cachedIdentity.responseText),
      expireTimestamp: cachedIdentity.expireTimestamp,
      status: cachedIdentity.status
    };
  };
  var createKnownIdentities = function createKnownIdentities2(identityApiData, deviceId) {
    var identitiesResult = {};
    if (isObject(identityApiData === null || identityApiData === void 0 ? void 0 : identityApiData.userIdentities)) {
      for (var identity in identityApiData.userIdentities) {
        identitiesResult[identity] = identityApiData.userIdentities[identity];
      }
    }
    identitiesResult.device_application_stamp = deviceId;
    return identitiesResult;
  };
  var removeExpiredIdentityCacheDates = function removeExpiredIdentityCacheDates2(idCache) {
    var cache = idCache.retrieve() || {};
    var currentTime = (/* @__PURE__ */ new Date()).getTime();
    for (var key in cache) {
      if (cache[key].expireTimestamp < currentTime) {
        delete cache[key];
      }
    }
    idCache.store(cache);
  };
  var tryCacheIdentity = function tryCacheIdentity2(knownIdentities, idCache, parseIdentityResponse2, mpid, callback, identityApiData, identityMethod) {
    var shouldReturnCachedIdentity = hasValidCachedIdentity(identityMethod, knownIdentities, idCache);
    if (shouldReturnCachedIdentity) {
      var cachedIdentity = getCachedIdentity(identityMethod, knownIdentities, idCache);
      parseIdentityResponse2(cachedIdentity, mpid, callback, identityApiData, identityMethod, knownIdentities, true);
      return true;
    }
    return false;
  };
  var getExpireTimestamp = function getExpireTimestamp2(maxAge) {
    if (maxAge === void 0) {
      maxAge = ONE_DAY_IN_SECONDS;
    }
    return (/* @__PURE__ */ new Date()).getTime() + maxAge * MILLIS_IN_ONE_SEC;
  };
  var parseIdentityResponse = function parseIdentityResponse2(responseText) {
    return responseText ? JSON.parse(responseText) : {};
  };
  var SHA256_IDENTITY_ALIASES = {
    email_sha256: "other",
    mobile_sha256: "other2"
  };
  var normalizeUserIdentityKeys = function normalizeUserIdentityKeys2(userIdentities) {
    var normalized = __assign({}, userIdentities);
    Object.keys(SHA256_IDENTITY_ALIASES).forEach(function(alias) {
      if (alias in normalized) {
        var value = normalized[alias];
        delete normalized[alias];
        normalized[SHA256_IDENTITY_ALIASES[alias]] = value;
      }
    });
    return normalized;
  };
  var identitiesEqual = function identitiesEqual2(a, b) {
    var aKeys = Object.keys(a !== null && a !== void 0 ? a : {});
    var bKeys = Object.keys(b !== null && b !== void 0 ? b : {});
    if (aKeys.length !== bKeys.length) return false;
    return aKeys.every(function(key) {
      return a[key] === b[key];
    });
  };
  var hasIdentityRequestChanged = function hasIdentityRequestChanged2(currentUser, newIdentityRequest) {
    if (!currentUser || !(newIdentityRequest === null || newIdentityRequest === void 0 ? void 0 : newIdentityRequest.userIdentities)) {
      return false;
    }
    var currentUserIdentities = currentUser.getUserIdentities().userIdentities;
    var newIdentities = normalizeUserIdentityKeys(newIdentityRequest.userIdentities);
    return !identitiesEqual(currentUserIdentities, newIdentities);
  };
  var hasExplicitIdentifier = function hasExplicitIdentifier2(store) {
    var _a2, _b2, _c;
    var userIdentities = (_b2 = (_a2 = store === null || store === void 0 ? void 0 : store.SDKConfig) === null || _a2 === void 0 ? void 0 : _a2.identifyRequest) === null || _b2 === void 0 ? void 0 : _b2.userIdentities;
    if (userIdentities && isObject(userIdentities) && !isEmpty(userIdentities) && Object.values(userIdentities).some(Boolean)) {
      return true;
    }
    return !!((_c = store === null || store === void 0 ? void 0 : store.SDKConfig) === null || _c === void 0 ? void 0 : _c.deviceId);
  };
  var buildIdentitySearchEnvelope = function buildIdentitySearchEnvelope2(environment) {
    return {
      client_sdk: {
        platform: Constants.platform,
        sdk_vendor: Constants.sdkVendor,
        sdk_version: Constants.sdkVersion
      },
      environment,
      request_id: generateUniqueId(),
      request_timestamp_ms: Date.now()
    };
  };
  var executeSearchRequest = function executeSearchRequest2(mpInstance, workspaceApiKey, knownIdentities, callback) {
    var _Helpers = mpInstance._Helpers, _Store = mpInstance._Store, Logger2 = mpInstance.Logger, _ErrorReportingDispatcher = mpInstance._ErrorReportingDispatcher;
    var _a2 = _Store.SDKConfig, identityUrl = _a2.identityUrl, isDevelopmentMode = _a2.isDevelopmentMode;
    if (!_Helpers.canLog()) {
      Logger2.verbose(Messages$9.InformationMessages.AbandonLogEvent);
      if (isFunction(callback)) {
        try {
          callback({
            httpCode: HTTPCodes$3.loggingDisabledOrMissingAPIKey
          });
        } catch (e) {
          Logger2.error("Error invoking search callback: " + getErrorMessage(e));
        }
      }
      return;
    }
    var serviceUrl = _Helpers.createServiceUrl(identityUrl);
    var searchUrl = serviceUrl + "search?cb=1";
    var environment = isDevelopmentMode ? "development" : "production";
    sendSearchRequest(knownIdentities, workspaceApiKey, function() {
      return buildIdentitySearchEnvelope(environment);
    }, searchUrl, callback, Logger2, void 0, _ErrorReportingDispatcher);
  };
  function APIClient(mpInstance, kitBlocker) {
    this.uploader = null;
    var self = this;
    this.queueEventForBatchUpload = function(event) {
      if (!this.uploader) {
        var millis = parseNumber(mpInstance._Helpers.getFeatureFlag(Constants.FeatureFlags.EventBatchingIntervalMillis));
        this.uploader = new BatchUploader(mpInstance, millis);
      }
      this.uploader.queueEvent(event);
      mpInstance._Persistence.update();
    };
    this.processQueuedEvents = function() {
      var mpid, currentUser = mpInstance.Identity.getCurrentUser();
      if (currentUser) {
        mpid = currentUser.getMPID();
      }
      if (mpInstance._Store.eventQueue.length && mpid) {
        var localQueueCopy = mpInstance._Store.eventQueue;
        mpInstance._Store.eventQueue = [];
        this.appendUserInfoToEvents(currentUser, localQueueCopy);
        localQueueCopy.forEach(function(event) {
          self.sendEventToServer(event);
        });
      }
    };
    this.appendUserInfoToEvents = function(user, events) {
      events.forEach(function(event) {
        if (!event.MPID) {
          appendUserInfo(user, event);
        }
      });
    };
    var handleNoFunctionalPreMpidEvent = function handleNoFunctionalPreMpidEvent2(event, mpid) {
      var _a2;
      var noFunctionalWithoutId = ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(mpInstance._Store);
      if (!noFunctionalWithoutId || mpid || !mpInstance._Store.configurationLoaded || mpInstance._Store.requireDelay) {
        return false;
      }
      var forwarderEvent = event;
      if (kitBlocker === null || kitBlocker === void 0 ? void 0 : kitBlocker.kitBlockingEnabled) {
        forwarderEvent = kitBlocker.createBlockedEvent(event);
      }
      if (forwarderEvent) {
        mpInstance._Forwarders.sendEventToForwarders(forwarderEvent);
        event.AlreadySentToForwarders = true;
      }
      mpInstance.Logger.verbose("noFunctional event forwarded to kits and queued for MP server upload when MPID is available.");
      mpInstance._Store.eventQueue.push(event);
      return true;
    };
    this.sendEventToServer = function(event, _options) {
      var defaultOptions = {
        shouldUploadEvent: true
      };
      var options = extend(defaultOptions, _options);
      if (mpInstance._Store.webviewBridgeEnabled) {
        mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.LogEvent, JSON.stringify(event));
        return;
      }
      var mpid, currentUser = mpInstance.Identity.getCurrentUser();
      if (currentUser) {
        mpid = currentUser.getMPID();
      }
      mpInstance._Store.requireDelay = mpInstance._Helpers.isDelayedByIntegration(mpInstance._preInit.integrationDelays, mpInstance._Store.integrationDelayTimeoutStart, Date.now());
      if (handleNoFunctionalPreMpidEvent(event, mpid)) {
        return;
      }
      if (!mpid || mpInstance._Store.requireDelay || !mpInstance._Store.configurationLoaded) {
        mpInstance.Logger.verbose("Event was added to eventQueue. eventQueue will be processed once a valid MPID is returned or there is no more integration imposed delay.");
        mpInstance._Store.eventQueue.push(event);
        return;
      }
      this.processQueuedEvents();
      if (isEmpty(event)) {
        return;
      }
      if (options.shouldUploadEvent) {
        this.queueEventForBatchUpload(event);
      }
      if (event.EventName !== String(Types.MessageType.AppStateTransition)) {
        if (kitBlocker && kitBlocker.kitBlockingEnabled) {
          event = kitBlocker.createBlockedEvent(event);
        }
        if (event && !event.AlreadySentToForwarders) {
          mpInstance._Forwarders.sendEventToForwarders(event);
        }
      }
    };
    this.sendBatchForwardingStatsToServer = function(forwardingStatsData, xhr) {
      var url;
      var data;
      try {
        url = mpInstance._Helpers.createServiceUrl(mpInstance._Store.SDKConfig.v2SecureServiceUrl, mpInstance._Store.devToken);
        data = {
          uuid: mpInstance._Helpers.generateUniqueId(),
          data: forwardingStatsData
        };
        if (xhr) {
          xhr.open("post", url + "/Forwarding");
          xhr.send(JSON.stringify(data));
        }
      } catch (e) {
        mpInstance.Logger.error("Error sending forwarding stats to mParticle servers.");
      }
    };
    this.initializeForwarderStatsUploader = function() {
      var forwardingDomain = mpInstance._Store.SDKConfig.v1SecureServiceUrl;
      var devToken = mpInstance._Store.devToken;
      var uploadUrl = "https://".concat(forwardingDomain).concat(devToken, "/Forwarding");
      var uploader = window.fetch ? new FetchUploader(uploadUrl) : new XHRUploader(uploadUrl);
      return uploader;
    };
    this.prepareForwardingStats = function(forwarder, event) {
      var forwardingStatsData;
      var queue = mpInstance._Forwarders.getForwarderStatsQueue();
      if (forwarder && forwarder.isVisible) {
        forwardingStatsData = {
          mid: forwarder.id,
          esid: forwarder.eventSubscriptionId,
          n: event.EventName,
          attrs: event.EventAttributes,
          sdk: event.SDKVersion,
          dt: event.EventDataType,
          et: event.EventCategory,
          dbg: event.Debug,
          ct: event.Timestamp,
          eec: event.ExpandedEventCount,
          dp: event.DataPlan
        };
        var _a2 = mpInstance._Forwarders, sendSingleForwardingStatsToServer = _a2.sendSingleForwardingStatsToServer, setForwarderStatsQueue = _a2.setForwarderStatsQueue;
        if (mpInstance._Helpers.getFeatureFlag(Constants.FeatureFlags.ReportBatching)) {
          queue.push(forwardingStatsData);
          setForwarderStatsQueue(queue);
        } else {
          sendSingleForwardingStatsToServer(forwardingStatsData);
        }
      }
    };
  }
  var KitFilterHelper = (
    /** @class */
    (function() {
      function KitFilterHelper2() {
      }
      KitFilterHelper2.hashEventType = function(eventType) {
        return generateHash(eventType);
      };
      KitFilterHelper2.hashEventName = function(eventName, eventType) {
        return generateHash(eventType + eventName);
      };
      KitFilterHelper2.hashEventAttributeKey = function(eventType, eventName, customAttributeName) {
        return generateHash(eventType + eventName + customAttributeName);
      };
      KitFilterHelper2.hashUserAttribute = function(userAttributeKey) {
        return generateHash(userAttributeKey);
      };
      KitFilterHelper2.hashUserIdentity = function(userIdentity) {
        return userIdentity;
      };
      KitFilterHelper2.hashConsentPurpose = function(prefix, purpose) {
        return generateHash(prefix + purpose);
      };
      KitFilterHelper2.hashAttributeConditionalForwarding = function(attribute) {
        return generateHash(attribute).toString();
      };
      KitFilterHelper2.hashConsentPurposeConditionalForwarding = function(prefix, purpose) {
        return this.hashConsentPurpose(prefix, purpose).toString();
      };
      var _a2;
      _a2 = KitFilterHelper2;
      KitFilterHelper2.filterUserAttributes = function(userAttributes, filterList) {
        return filterDictionaryWithHash(userAttributes, filterList, function(key) {
          return _a2.hashUserAttribute(key);
        });
      };
      KitFilterHelper2.filterUserIdentities = function(userIdentities, filterList) {
        return filterDictionaryWithHash(userIdentities, filterList, function(key) {
          return _a2.hashUserIdentity(IdentityType.getIdentityType(key));
        });
      };
      KitFilterHelper2.isFilteredUserAttribute = function(userAttributeKey, filterList) {
        var hashedUserAttribute = _a2.hashUserAttribute(userAttributeKey);
        return filterList && inArray(filterList, hashedUserAttribute);
      };
      return KitFilterHelper2;
    })()
  );
  var StorageNames$1 = Constants.StorageNames;
  function appendFilteredUserIdentity(filteredUserIdentities, identity, userIdentityType) {
    if (userIdentityType === Types.IdentityType.CustomerId) {
      filteredUserIdentities.unshift(identity);
    } else {
      filteredUserIdentities.push(identity);
    }
  }
  function buildFilteredUserIdentities$1(userIdentitiesObject, filterList, inArray2) {
    var filteredUserIdentities = [];
    if (!userIdentitiesObject || !Object.keys(userIdentitiesObject).length) {
      return filteredUserIdentities;
    }
    for (var userIdentityName in userIdentitiesObject) {
      if (!userIdentitiesObject.hasOwnProperty(userIdentityName)) {
        continue;
      }
      var userIdentityType = Types.IdentityType.getIdentityType(userIdentityName);
      if (inArray2(filterList, userIdentityType)) {
        continue;
      }
      appendFilteredUserIdentity(filteredUserIdentities, {
        Type: userIdentityType,
        Identity: userIdentitiesObject[userIdentityName]
      }, userIdentityType);
    }
    return filteredUserIdentities;
  }
  function Helpers(mpInstance) {
    var self = this;
    this.canLog = function() {
      if (mpInstance._Store.isEnabled && (mpInstance._Store.devToken || mpInstance._Store.webviewBridgeEnabled)) {
        return true;
      }
      return false;
    };
    this.getFeatureFlag = function(feature) {
      if (mpInstance._Store.SDKConfig.flags.hasOwnProperty(feature)) {
        return mpInstance._Store.SDKConfig.flags[feature];
      }
      return null;
    };
    this.invokeCallback = function(callback, code, body, mParticleUser, previousMpid) {
      if (!callback) {
        mpInstance.Logger.warning("There is no callback provided");
      }
      try {
        if (self.Validators.isFunction(callback)) {
          callback({
            httpCode: code,
            body,
            getUser: function getUser() {
              if (mParticleUser) {
                return mParticleUser;
              } else {
                return mpInstance.Identity.getCurrentUser();
              }
            },
            getPreviousUser: function getPreviousUser() {
              if (!previousMpid) {
                var users = mpInstance.Identity.getUsers();
                var mostRecentUser = users.shift();
                var currentUser = mParticleUser || mpInstance.Identity.getCurrentUser();
                if (mostRecentUser && currentUser && mostRecentUser.getMPID() === currentUser.getMPID()) {
                  mostRecentUser = users.shift();
                }
                return mostRecentUser || null;
              } else {
                return mpInstance.Identity.getUser(previousMpid);
              }
            }
          });
        }
      } catch (e) {
        mpInstance.Logger.error("There was an error with your callback: " + e);
      }
    };
    this.invokeAliasCallback = function(callback, code, message) {
      if (!callback) {
        mpInstance.Logger.warning("There is no callback provided");
      }
      try {
        if (self.Validators.isFunction(callback)) {
          var callbackMessage = {
            httpCode: code
          };
          if (message) {
            callbackMessage.message = message;
          }
          callback(callbackMessage);
        }
      } catch (e) {
        mpInstance.Logger.error("There was an error with your callback: " + e);
      }
    };
    this.extend = extend;
    this.createServiceUrl = function(secureServiceUrl, devToken) {
      var serviceScheme = window.mParticle && mpInstance._Store.SDKConfig.forceHttps ? "https://" : window.location.protocol + "//";
      var baseUrl;
      if (mpInstance._Store.SDKConfig.forceHttps) {
        baseUrl = "https://" + secureServiceUrl;
      } else {
        baseUrl = serviceScheme + secureServiceUrl;
      }
      if (devToken) {
        baseUrl = baseUrl + devToken;
      }
      return baseUrl;
    };
    this.createXHR = function(cb) {
      var xhr;
      try {
        xhr = new window.XMLHttpRequest();
      } catch (e) {
        mpInstance.Logger.error("Error creating XMLHttpRequest object.");
      }
      if (xhr && cb && "withCredentials" in xhr) {
        xhr.onreadystatechange = cb;
      } else if (typeof window.XDomainRequest !== "undefined") {
        mpInstance.Logger.verbose("Creating XDomainRequest object");
        try {
          xhr = new window.XDomainRequest();
          xhr.onload = cb;
        } catch (e) {
          mpInstance.Logger.error("Error creating XDomainRequest object");
        }
      }
      return xhr;
    };
    this.filterUserIdentities = function(userIdentitiesObject, filterList) {
      return buildFilteredUserIdentities$1(userIdentitiesObject, filterList, self.inArray);
    };
    this.filterUserIdentitiesForForwarders = KitFilterHelper.filterUserIdentities;
    this.filterUserAttributes = KitFilterHelper.filterUserAttributes;
    this.isEventType = function(type) {
      for (var prop in Types.EventType) {
        if (Types.EventType.hasOwnProperty(prop)) {
          if (Types.EventType[prop] === type) {
            return true;
          }
        }
      }
      return false;
    };
    this.sanitizeAttributes = function(attrs, name) {
      if (!attrs || !self.isObject(attrs)) {
        return null;
      }
      var sanitizedAttrs = {};
      for (var prop in attrs) {
        if (attrs.hasOwnProperty(prop) && self.Validators.isValidAttributeValue(attrs[prop])) {
          sanitizedAttrs[prop] = attrs[prop];
        } else {
          mpInstance.Logger.warning("For '" + name + "', the corresponding attribute value of '" + prop + "' must be a string, number, boolean, or null.");
        }
      }
      return sanitizedAttrs;
    };
    this.isDelayedByIntegration = function(delayedIntegrations, timeoutStart, now) {
      if (now - timeoutStart > mpInstance._Store.SDKConfig.integrationDelayTimeout) {
        return false;
      }
      for (var integration in delayedIntegrations) {
        if (delayedIntegrations[integration] === true) {
          return true;
        } else {
          continue;
        }
      }
      return false;
    };
    this.createMainStorageName = function(workspaceToken) {
      if (workspaceToken) {
        return StorageNames$1.currentStorageName + "_" + workspaceToken;
      } else {
        return StorageNames$1.currentStorageName;
      }
    };
    this.converted = converted;
    this.findKeyInObject = findKeyInObject;
    this.parseNumber = parseNumber;
    this.inArray = inArray;
    this.isObject = isObject;
    this.decoded = decoded;
    this.parseStringOrNumber = parseStringOrNumber;
    this.generateHash = generateHash;
    this.generateUniqueId = generateUniqueId;
    this.Validators = Validators;
  }
  var Messages$8 = Constants.Messages;
  var androidBridgeNameBase = "mParticleAndroid";
  var iosBridgeNameBase = "mParticle";
  function getAndroidBridge(name) {
    if (!Object.prototype.hasOwnProperty.call(window, name)) {
      return void 0;
    }
    return window[name];
  }
  function getInstanceNamedValue(instance, name) {
    return instance[name];
  }
  function NativeSdkHelpers(mpInstance) {
    var self = this;
    this.initializeSessionAttributes = function(apiKey) {
      var SetSessionAttribute = Constants.NativeSdkPaths.SetSessionAttribute;
      var env = JSON.stringify({
        key: "$src_env",
        value: "webview"
      });
      var key = JSON.stringify({
        key: "$src_key",
        value: apiKey
      });
      self.sendToNative(SetSessionAttribute, env);
      if (apiKey) {
        self.sendToNative(SetSessionAttribute, key);
      }
    };
    this.isBridgeV2Available = function(bridgeName) {
      var _a2, _b2;
      if (!bridgeName) {
        return false;
      }
      var androidBridgeName = androidBridgeNameBase + "_" + bridgeName + "_v2";
      var iosBridgeName = iosBridgeNameBase + "_" + bridgeName + "_v2";
      if ((_b2 = (_a2 = window.webkit) === null || _a2 === void 0 ? void 0 : _a2.messageHandlers) === null || _b2 === void 0 ? void 0 : _b2.hasOwnProperty(iosBridgeName)) {
        return true;
      }
      if (window.mParticle && window.mParticle.uiwebviewBridgeName && window.mParticle.uiwebviewBridgeName === iosBridgeName) {
        return true;
      }
      if (window.hasOwnProperty(androidBridgeName)) {
        return true;
      }
      return false;
    };
    this.isWebviewEnabled = function(requiredWebviewBridgeName, minWebviewBridgeVersion) {
      mpInstance._Store.bridgeV2Available = self.isBridgeV2Available(requiredWebviewBridgeName);
      mpInstance._Store.bridgeV1Available = self.isBridgeV1Available();
      if (minWebviewBridgeVersion === 2) {
        return mpInstance._Store.bridgeV2Available;
      }
      if (window.mParticle) {
        if (window.mParticle.uiwebviewBridgeName && window.mParticle.uiwebviewBridgeName !== iosBridgeNameBase + "_" + requiredWebviewBridgeName + "_v2") {
          return false;
        }
      }
      if (minWebviewBridgeVersion < 2) {
        return mpInstance._Store.bridgeV2Available || mpInstance._Store.bridgeV1Available;
      }
      return false;
    };
    this.isBridgeV1Available = function() {
      if (mpInstance._Store.SDKConfig.useNativeSdk || window.mParticleAndroid || mpInstance._Store.SDKConfig.isIOS) {
        return true;
      }
      return false;
    };
    this.sendToNative = function(path, value) {
      if (mpInstance._Store.bridgeV2Available && mpInstance._Store.SDKConfig.minWebviewBridgeVersion === 2) {
        self.sendViaBridgeV2(path, value, mpInstance._Store.SDKConfig.requiredWebviewBridgeName);
        return;
      }
      if (mpInstance._Store.bridgeV2Available && mpInstance._Store.SDKConfig.minWebviewBridgeVersion < 2) {
        self.sendViaBridgeV2(path, value, mpInstance._Store.SDKConfig.requiredWebviewBridgeName);
        return;
      }
      if (mpInstance._Store.bridgeV1Available && mpInstance._Store.SDKConfig.minWebviewBridgeVersion < 2) {
        self.sendViaBridgeV1(path, value);
        return;
      }
    };
    this.sendViaBridgeV1 = function(path, value) {
      if (window.mParticleAndroid && window.mParticleAndroid.hasOwnProperty(path)) {
        mpInstance.Logger.verbose(Messages$8.InformationMessages.SendAndroid + path);
        window.mParticleAndroid[path](value);
      } else if (mpInstance._Store.SDKConfig.isIOS) {
        mpInstance.Logger.verbose(Messages$8.InformationMessages.SendIOS + path);
        self.sendViaIframeToIOS(path, value);
      }
    };
    this.sendViaIframeToIOS = function(path, value) {
      var iframe = document.createElement("IFRAME");
      iframe.setAttribute("src", "mp-sdk://" + path + "/" + encodeURIComponent(value));
      document.documentElement.appendChild(iframe);
      iframe.parentNode.removeChild(iframe);
    };
    this.sendViaBridgeV2 = function(path, value, requiredWebviewBridgeName) {
      var _a2, _b2;
      if (!requiredWebviewBridgeName) {
        return;
      }
      var androidBridgeName = androidBridgeNameBase + "_" + requiredWebviewBridgeName + "_v2", androidBridge = getAndroidBridge(androidBridgeName), iosBridgeName = iosBridgeNameBase + "_" + requiredWebviewBridgeName + "_v2";
      var iOSBridgeMessageHandler, iOSBridgeNonMessageHandler;
      if ((_b2 = (_a2 = window.webkit) === null || _a2 === void 0 ? void 0 : _a2.messageHandlers) === null || _b2 === void 0 ? void 0 : _b2[iosBridgeName]) {
        iOSBridgeMessageHandler = window.webkit.messageHandlers[iosBridgeName];
      }
      if (mpInstance.uiwebviewBridgeName === iosBridgeName) {
        iOSBridgeNonMessageHandler = getInstanceNamedValue(mpInstance, iosBridgeName);
      }
      if (androidBridge && androidBridge.hasOwnProperty(path)) {
        mpInstance.Logger.verbose(Messages$8.InformationMessages.SendAndroid + path);
        androidBridge[path](value);
        return;
      } else if (iOSBridgeMessageHandler) {
        mpInstance.Logger.verbose(Messages$8.InformationMessages.SendIOS + path);
        iOSBridgeMessageHandler.postMessage(JSON.stringify({
          path,
          value: value ? JSON.parse(value) : null
        }));
      } else if (iOSBridgeNonMessageHandler) {
        mpInstance.Logger.verbose(Messages$8.InformationMessages.SendIOS + path);
        self.sendViaIframeToIOS(path, value);
      }
    };
  }
  var Messages$7 = Constants.Messages;
  var InformationMessages = Messages$7.InformationMessages;
  var DAYS_IN_MILLISECONDS = 1e3 * 60 * 60 * 24;
  var PARTNER_MODULE_IDS = {
    AdobeEventForwarder: 11,
    DoubleclickDFP: 41,
    AppNexus: 50,
    Lotame: 58,
    TradeDesk: 103,
    VerizonMedia: 155,
    Rokt: 1277
  };
  function CookieSyncManager(mpInstance) {
    var self = this;
    this.attemptCookieSync = function(mpid, mpidIsNotInCookies) {
      var _a2;
      var _b2 = mpInstance._Store, pixelConfigurations = _b2.pixelConfigurations, webviewBridgeEnabled = _b2.webviewBridgeEnabled;
      if (!mpid || webviewBridgeEnabled) {
        return;
      }
      if ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) {
        return;
      }
      var persistence = mpInstance._Persistence.getPersistence();
      if (isEmpty(persistence)) {
        return;
      }
      pixelConfigurations.forEach(function(pixelSettings) {
        var _a3, _b3, _c;
        var requiresConsent = false;
        var filteringConsentRuleValues = pixelSettings.filteringConsentRuleValues, pixelUrl = pixelSettings.pixelUrl, redirectUrl = pixelSettings.redirectUrl, moduleId = pixelSettings.moduleId, settings = pixelSettings.settings, frequencyCap = pixelSettings.frequencyCap;
        var values = (filteringConsentRuleValues || {}).values;
        if (isEmpty(pixelUrl)) {
          return;
        }
        if (!isEmpty(values)) {
          requiresConsent = true;
        }
        if (requiresConsent && mpidIsNotInCookies) {
          return;
        }
        if (moduleId === PARTNER_MODULE_IDS.Rokt && mpInstance._CookieConsentManager.getNoTargeting()) {
          return;
        }
        var isEnabledForUserConsent = mpInstance._Consent.isEnabledForUserConsent;
        if (!isEnabledForUserConsent(filteringConsentRuleValues, mpInstance.Identity.getCurrentUser())) {
          return;
        }
        var cookieSyncDates = (_b3 = (_a3 = persistence[mpid]) === null || _a3 === void 0 ? void 0 : _a3.csd) !== null && _b3 !== void 0 ? _b3 : {};
        var lastSyncDateForModule = cookieSyncDates[moduleId] || null;
        if (!isLastSyncDateExpired(frequencyCap, lastSyncDateForModule)) {
          return;
        }
        var domain = moduleId === PARTNER_MODULE_IDS.TradeDesk ? window.location.hostname : void 0;
        var enableHmTag = ((_c = settings === null || settings === void 0 ? void 0 : settings.enableHmTag) === null || _c === void 0 ? void 0 : _c.toLowerCase()) === "true";
        var isDoubleClickModule = moduleId === PARTNER_MODULE_IDS.DoubleclickDFP;
        var base64Mpid = isDoubleClickModule && enableHmTag ? toWebSafeBase64(mpid) : void 0;
        var fullUrl = createCookieSyncUrl(mpid, pixelUrl, redirectUrl, domain, base64Mpid);
        self.performCookieSync(fullUrl, moduleId.toString(), mpid, cookieSyncDates);
      });
    };
    this.performCookieSync = function(url, moduleId, mpid, cookieSyncDates) {
      var img = document.createElement("img");
      mpInstance.Logger.verbose(InformationMessages.CookieSync);
      img.onload = function() {
        cookieSyncDates[moduleId] = (/* @__PURE__ */ new Date()).getTime();
        mpInstance._Persistence.saveUserCookieSyncDatesToPersistence(mpid, cookieSyncDates);
      };
      img.src = url;
    };
  }
  var isLastSyncDateExpired = function isLastSyncDateExpired2(frequencyCap, lastSyncDate) {
    if (!lastSyncDate) {
      return true;
    }
    return (/* @__PURE__ */ new Date()).getTime() > new Date(lastSyncDate).getTime() + frequencyCap * DAYS_IN_MILLISECONDS;
  };
  function logDeprecatedMethodUsage(usage, logger, errorReporter) {
    logger.warning(usage.warningMessage);
    errorReporter === null || errorReporter === void 0 ? void 0 : errorReporter.report({
      message: usage.methodName,
      code: ErrorCodes.MP_DEPRECATED_METHOD_USAGE,
      severity: WSDKErrorSeverity.WARNING
    });
  }
  var Messages$6 = Constants.Messages;
  function SessionManager(mpInstance) {
    var self = this;
    this.initialize = function() {
      var _a2;
      if (mpInstance._Store.sessionId) {
        var _b2 = mpInstance._Store, dateLastEventSent = _b2.dateLastEventSent, SDKConfig = _b2.SDKConfig;
        var sessionTimeout = SDKConfig.sessionTimeout;
        if (hasSessionTimedOut(dateLastEventSent === null || dateLastEventSent === void 0 ? void 0 : dateLastEventSent.getTime(), sessionTimeout)) {
          self.endSession();
          self.startNewSession();
        } else {
          var currentUser = mpInstance.Identity.getCurrentUser();
          var sdkIdentityRequest = SDKConfig.identifyRequest;
          var shouldSuppressIdentify = ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(mpInstance._Store);
          if (!shouldSuppressIdentify && hasIdentityRequestChanged(currentUser, sdkIdentityRequest)) {
            mpInstance.Identity.identify(sdkIdentityRequest, SDKConfig.identityCallback);
            mpInstance._Store.identifyCalled = true;
            mpInstance._Store.SDKConfig.identityCallback = null;
          }
        }
      } else {
        self.startNewSession();
      }
    };
    this.getSession = function() {
      logDeprecatedMethodUsage({
        methodName: "SessionManager.getSession()",
        warningMessage: generateDeprecationMessage("SessionManager.getSession()", false, "SessionManager.getSessionId()")
      }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
      return this.getSessionId();
    };
    this.getSessionId = function() {
      return mpInstance._Store.sessionId;
    };
    this.startNewSession = function() {
      var _a2;
      mpInstance.Logger.verbose(Messages$6.InformationMessages.StartingNewSession);
      if (mpInstance._Helpers.canLog()) {
        mpInstance._Store.sessionId = mpInstance._Helpers.generateUniqueId().toUpperCase();
        var currentUser = mpInstance.Identity.getCurrentUser();
        var mpid = currentUser ? currentUser.getMPID() : null;
        if (mpid) {
          mpInstance._Store.currentSessionMPIDs = [mpid];
        }
        if (!mpInstance._Store.sessionStartDate) {
          var date = /* @__PURE__ */ new Date();
          mpInstance._Store.sessionStartDate = date;
          mpInstance._Store.dateLastEventSent = date;
        }
        self.setSessionTimer();
        var shouldSuppressIdentify = ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(mpInstance._Store);
        if (!mpInstance._Store.identifyCalled && !shouldSuppressIdentify) {
          mpInstance.Identity.identify(mpInstance._Store.SDKConfig.identifyRequest, mpInstance._Store.SDKConfig.identityCallback);
          mpInstance._Store.identifyCalled = true;
          mpInstance._Store.SDKConfig.identityCallback = null;
        }
        mpInstance._Events.logEvent({
          messageType: Types.MessageType.SessionStart
        });
      } else {
        mpInstance.Logger.verbose(Messages$6.InformationMessages.AbandonStartSession);
      }
    };
    this.endSession = function(override) {
      var _a2, _b2, _c, _d;
      mpInstance.Logger.verbose(Messages$6.InformationMessages.StartingEndSession);
      if (override) {
        performSessionEnd();
        return;
      }
      if (!mpInstance._Helpers.canLog()) {
        mpInstance.Logger.verbose(Messages$6.InformationMessages.AbandonEndSession);
        (_a2 = mpInstance._timeOnSiteTimer) === null || _a2 === void 0 ? void 0 : _a2.resetTimer();
        return;
      }
      var cookies = mpInstance._Persistence.getPersistence();
      if (!cookies || cookies.gs && !cookies.gs.sid) {
        mpInstance.Logger.verbose(Messages$6.InformationMessages.NoSessionToEnd);
        (_b2 = mpInstance._timeOnSiteTimer) === null || _b2 === void 0 ? void 0 : _b2.resetTimer();
        return;
      }
      if (cookies.gs.sid && mpInstance._Store.sessionId !== cookies.gs.sid) {
        mpInstance._Store.sessionId = cookies.gs.sid;
      }
      if ((_c = cookies === null || cookies === void 0 ? void 0 : cookies.gs) === null || _c === void 0 ? void 0 : _c.les) {
        var sessionTimeout = mpInstance._Store.SDKConfig.sessionTimeout;
        if (hasSessionTimedOut(cookies.gs.les, sessionTimeout)) {
          performSessionEnd();
        } else {
          self.setSessionTimer();
          (_d = mpInstance._timeOnSiteTimer) === null || _d === void 0 ? void 0 : _d.resetTimer();
        }
      }
    };
    this.setSessionTimer = function() {
      var sessionTimeoutInMilliseconds = mpInstance._Store.SDKConfig.sessionTimeout * 6e4;
      mpInstance._Store.globalTimer = window.setTimeout(function() {
        self.endSession();
      }, sessionTimeoutInMilliseconds);
    };
    this.resetSessionTimer = function() {
      if (!mpInstance._Store.webviewBridgeEnabled) {
        if (!mpInstance._Store.sessionId) {
          self.startNewSession();
        }
        self.clearSessionTimeout();
        self.setSessionTimer();
      }
      self.startNewSessionIfNeeded();
    };
    this.clearSessionTimeout = function() {
      clearTimeout(mpInstance._Store.globalTimer);
    };
    this.startNewSessionIfNeeded = function() {
      if (!mpInstance._Store.webviewBridgeEnabled) {
        var persistence = mpInstance._Persistence.getPersistence();
        if (!mpInstance._Store.sessionId && persistence) {
          if (persistence.sid) {
            mpInstance._Store.sessionId = persistence.sid;
          } else {
            self.startNewSession();
          }
        }
      }
    };
    function hasSessionTimedOut(lastEventTimestamp, sessionTimeout) {
      if (!lastEventTimestamp || !sessionTimeout || sessionTimeout <= 0) {
        return false;
      }
      var sessionTimeoutInMilliseconds = sessionTimeout * 6e4;
      var timeSinceLastEvent = Date.now() - lastEventTimestamp;
      return timeSinceLastEvent >= sessionTimeoutInMilliseconds;
    }
    function performSessionEnd() {
      var _a2;
      mpInstance._Events.logEvent({
        messageType: Types.MessageType.SessionEnd
      });
      mpInstance._Store.nullifySession();
      (_a2 = mpInstance._timeOnSiteTimer) === null || _a2 === void 0 ? void 0 : _a2.resetTimer();
    }
  }
  var Messages$5 = Constants.Messages;
  function Ecommerce(mpInstance) {
    var self = this;
    this.convertTransactionAttributesToProductAction = function(transactionAttributes, productAction) {
      if (transactionAttributes.hasOwnProperty("Id")) {
        productAction.TransactionId = transactionAttributes.Id;
      }
      if (transactionAttributes.hasOwnProperty("Affiliation")) {
        productAction.Affiliation = transactionAttributes.Affiliation;
      }
      if (transactionAttributes.hasOwnProperty("CouponCode")) {
        productAction.CouponCode = transactionAttributes.CouponCode;
      }
      if (transactionAttributes.hasOwnProperty("Revenue")) {
        productAction.TotalAmount = this.sanitizeAmount(transactionAttributes.Revenue, "Revenue");
      }
      if (transactionAttributes.hasOwnProperty("Shipping")) {
        productAction.ShippingAmount = this.sanitizeAmount(transactionAttributes.Shipping, "Shipping");
      }
      if (transactionAttributes.hasOwnProperty("Tax")) {
        productAction.TaxAmount = this.sanitizeAmount(transactionAttributes.Tax, "Tax");
      }
      if (transactionAttributes.hasOwnProperty("Step")) {
        productAction.CheckoutStep = transactionAttributes.Step;
      }
      if (transactionAttributes.hasOwnProperty("Option")) {
        productAction.CheckoutOptions = transactionAttributes.Option;
      }
    };
    this.calculateProductActionTotalAmount = function(productAction) {
      if (!productAction || productAction.TotalAmount != null) {
        return productAction;
      }
      var totalAmount = 0;
      if (Array.isArray(productAction.ProductList)) {
        productAction.ProductList.forEach(function(product) {
          totalAmount += parseNumber(product.Quantity) * parseNumber(product.Price);
        });
      }
      totalAmount += parseNumber(productAction.ShippingAmount) + parseNumber(productAction.TaxAmount);
      productAction.TotalAmount = totalAmount;
      return productAction;
    };
    this.getProductActionEventName = function(productActionType) {
      switch (productActionType) {
        case Types.ProductActionType.AddToCart:
          return "AddToCart";
        case Types.ProductActionType.AddToWishlist:
          return "AddToWishlist";
        case Types.ProductActionType.Checkout:
          return "Checkout";
        case Types.ProductActionType.CheckoutOption:
          return "CheckoutOption";
        case Types.ProductActionType.Click:
          return "Click";
        case Types.ProductActionType.Purchase:
          return "Purchase";
        case Types.ProductActionType.Refund:
          return "Refund";
        case Types.ProductActionType.RemoveFromCart:
          return "RemoveFromCart";
        case Types.ProductActionType.RemoveFromWishlist:
          return "RemoveFromWishlist";
        case Types.ProductActionType.ViewDetail:
          return "ViewDetail";
        case Types.ProductActionType.ViewCart:
          return "ViewCart";
        case Types.ProductActionType.AddShippingInfo:
          return "AddShippingInfo";
        case Types.ProductActionType.AddPaymentInfo:
          return "AddPaymentInfo";
        case Types.ProductActionType.PaymentMethodSelected:
          return "PaymentMethodSelected";
        case Types.ProductActionType.PaymentAttempted:
          return "PaymentAttempted";
        case Types.ProductActionType.PaymentSucceeded:
          return "PaymentSucceeded";
        case Types.ProductActionType.PaymentFailed:
          return "PaymentFailed";
        case Types.ProductActionType.RefundInitiated:
          return "RefundInitiated";
        case Types.ProductActionType.Unknown:
        default:
          return "Unknown";
      }
    };
    this.getPromotionActionEventName = function(promotionActionType) {
      switch (promotionActionType) {
        case Types.PromotionActionType.PromotionClick:
          return "PromotionClick";
        case Types.PromotionActionType.PromotionView:
          return "PromotionView";
        default:
          return "Unknown";
      }
    };
    this.convertProductActionToEventType = function(productActionType) {
      switch (productActionType) {
        case Types.ProductActionType.AddToCart:
          return Types.CommerceEventType.ProductAddToCart;
        case Types.ProductActionType.AddToWishlist:
          return Types.CommerceEventType.ProductAddToWishlist;
        case Types.ProductActionType.Checkout:
          return Types.CommerceEventType.ProductCheckout;
        case Types.ProductActionType.CheckoutOption:
          return Types.CommerceEventType.ProductCheckoutOption;
        case Types.ProductActionType.Click:
          return Types.CommerceEventType.ProductClick;
        case Types.ProductActionType.Purchase:
          return Types.CommerceEventType.ProductPurchase;
        case Types.ProductActionType.Refund:
          return Types.CommerceEventType.ProductRefund;
        case Types.ProductActionType.RemoveFromCart:
          return Types.CommerceEventType.ProductRemoveFromCart;
        case Types.ProductActionType.RemoveFromWishlist:
          return Types.CommerceEventType.ProductRemoveFromWishlist;
        // https://go.mparticle.com/work/SQDSDKS-4801
        case Types.ProductActionType.Unknown:
          return Types.EventType.Unknown;
        case Types.ProductActionType.ViewDetail:
          return Types.CommerceEventType.ProductViewDetail;
        // Rokt Brain commerce-adjacent types map to Unknown on server
        case Types.ProductActionType.ViewCart:
        case Types.ProductActionType.AddShippingInfo:
        case Types.ProductActionType.AddPaymentInfo:
        case Types.ProductActionType.PaymentMethodSelected:
        case Types.ProductActionType.PaymentAttempted:
        case Types.ProductActionType.PaymentSucceeded:
        case Types.ProductActionType.PaymentFailed:
        case Types.ProductActionType.RefundInitiated:
          return Types.EventType.Unknown;
        default:
          mpInstance.Logger.error("Could not convert product action type " + productActionType + " to event type");
          return null;
      }
    };
    this.convertPromotionActionToEventType = function(promotionActionType) {
      switch (promotionActionType) {
        case Types.PromotionActionType.PromotionClick:
          return Types.CommerceEventType.PromotionClick;
        case Types.PromotionActionType.PromotionView:
          return Types.CommerceEventType.PromotionView;
        default:
          mpInstance.Logger.error("Could not convert promotion action type " + promotionActionType + " to event type");
          return null;
      }
    };
    this.generateExpandedEcommerceName = function(eventName, plusOne) {
      return "eCommerce - " + eventName + " - " + (plusOne ? "Total" : "Item");
    };
    this.extractProductAttributes = function(attributes, product) {
      if (product.CouponCode) {
        attributes["Coupon Code"] = product.CouponCode;
      }
      if (product.Brand) {
        attributes["Brand"] = product.Brand;
      }
      if (product.Category) {
        attributes["Category"] = product.Category;
      }
      if (product.Name) {
        attributes["Name"] = product.Name;
      }
      if (product.Sku) {
        attributes["Id"] = product.Sku;
      }
      if (product.Price) {
        attributes["Item Price"] = product.Price;
      }
      if (product.Quantity) {
        attributes["Quantity"] = product.Quantity;
      }
      if (product.Position) {
        attributes["Position"] = product.Position;
      }
      if (product.Variant) {
        attributes["Variant"] = product.Variant;
      }
      attributes["Total Product Amount"] = product.TotalAmount || 0;
    };
    this.extractTransactionId = function(attributes, productAction) {
      if (productAction.TransactionId) {
        attributes["Transaction Id"] = productAction.TransactionId;
      }
    };
    this.extractActionAttributes = function(attributes, productAction) {
      self.extractTransactionId(attributes, productAction);
      if (productAction.Affiliation) {
        attributes["Affiliation"] = productAction.Affiliation;
      }
      if (productAction.CouponCode) {
        attributes["Coupon Code"] = productAction.CouponCode;
      }
      if (productAction.TotalAmount) {
        attributes["Total Amount"] = productAction.TotalAmount;
      }
      if (productAction.ShippingAmount) {
        attributes["Shipping Amount"] = productAction.ShippingAmount;
      }
      if (productAction.TaxAmount) {
        attributes["Tax Amount"] = productAction.TaxAmount;
      }
      if (productAction.CheckoutOptions) {
        attributes["Checkout Options"] = productAction.CheckoutOptions;
      }
      if (productAction.CheckoutStep) {
        attributes["Checkout Step"] = productAction.CheckoutStep;
      }
    };
    this.extractPromotionAttributes = function(attributes, promotion) {
      if (promotion.Id) {
        attributes["Id"] = promotion.Id;
      }
      if (promotion.Creative) {
        attributes["Creative"] = promotion.Creative;
      }
      if (promotion.Name) {
        attributes["Name"] = promotion.Name;
      }
      if (promotion.Position) {
        attributes["Position"] = promotion.Position;
      }
    };
    this.buildProductList = function(event, product) {
      if (product) {
        if (Array.isArray(product)) {
          return product;
        }
        return [product];
      }
      return event.ShoppingCart.ProductList;
    };
    this.createProduct = function(name, sku, price, quantity, variant, category, brand, position, couponCode, attributes) {
      attributes = mpInstance._Helpers.sanitizeAttributes(attributes, name);
      if (typeof name !== "string") {
        mpInstance.Logger.error("Name is required when creating a product");
        return null;
      }
      if (!mpInstance._Helpers.Validators.isStringOrNumber(sku)) {
        mpInstance.Logger.error("SKU is required when creating a product, and must be a string or a number");
        return null;
      }
      if (!mpInstance._Helpers.Validators.isStringOrNumber(price)) {
        mpInstance.Logger.error("Price is required when creating a product, and must be a string or a number");
        return null;
      } else {
        price = mpInstance._Helpers.parseNumber(price);
      }
      if (position && !mpInstance._Helpers.Validators.isNumber(position)) {
        mpInstance.Logger.error("Position must be a number, it will be set to null.");
        position = null;
      }
      if (!mpInstance._Helpers.Validators.isStringOrNumber(quantity)) {
        quantity = 1;
      } else {
        quantity = mpInstance._Helpers.parseNumber(quantity);
      }
      return {
        Name: name,
        Sku: sku,
        Price: price,
        Quantity: quantity,
        Brand: brand,
        Variant: variant,
        Category: category,
        Position: position,
        CouponCode: couponCode,
        TotalAmount: quantity * price,
        Attributes: attributes
      };
    };
    this.createPromotion = function(id, creative, name, position) {
      if (!mpInstance._Helpers.Validators.isStringOrNumber(id)) {
        mpInstance.Logger.error(Messages$5.ErrorMessages.PromotionIdRequired);
        return null;
      }
      return {
        Id: id,
        Creative: creative,
        Name: name,
        Position: position
      };
    };
    this.createImpression = function(name, product) {
      if (typeof name !== "string") {
        mpInstance.Logger.error("Name is required when creating an impression.");
        return null;
      }
      if (!product) {
        mpInstance.Logger.error("Product is required when creating an impression.");
        return null;
      }
      return {
        Name: name,
        Product: product
      };
    };
    this.createTransactionAttributes = function(id, affiliation, couponCode, revenue, shipping, tax) {
      if (!mpInstance._Helpers.Validators.isStringOrNumber(id)) {
        mpInstance.Logger.error(Messages$5.ErrorMessages.TransactionIdRequired);
        return null;
      }
      return {
        Id: id,
        Affiliation: affiliation,
        CouponCode: couponCode,
        Revenue: revenue,
        Shipping: shipping,
        Tax: tax
      };
    };
    this.expandProductImpression = function(commerceEvent) {
      var appEvents = [];
      if (!commerceEvent.ProductImpressions) {
        return appEvents;
      }
      commerceEvent.ProductImpressions.forEach(function(productImpression) {
        if (productImpression.ProductList) {
          productImpression.ProductList.forEach(function(product) {
            var attributes = extend(false, {}, commerceEvent.EventAttributes);
            if (product.Attributes) {
              for (var attribute in product.Attributes) {
                attributes[attribute] = product.Attributes[attribute];
              }
            }
            self.extractProductAttributes(attributes, product);
            if (productImpression.ProductImpressionList) {
              attributes["Product Impression List"] = productImpression.ProductImpressionList;
            }
            var appEvent = mpInstance._ServerModel.createEventObject({
              messageType: Types.MessageType.PageEvent,
              name: self.generateExpandedEcommerceName("Impression"),
              data: attributes,
              eventType: Types.EventType.Transaction
            });
            appEvents.push(appEvent);
          });
        }
      });
      return appEvents;
    };
    this.expandCommerceEvent = function(event) {
      if (!event) {
        return null;
      }
      return self.expandProductAction(event).concat(self.expandPromotionAction(event)).concat(self.expandProductImpression(event));
    };
    this.expandPromotionAction = function(commerceEvent) {
      var appEvents = [];
      if (!commerceEvent.PromotionAction) {
        return appEvents;
      }
      var promotions = commerceEvent.PromotionAction.PromotionList;
      promotions.forEach(function(promotion) {
        var attributes = extend(false, {}, commerceEvent.EventAttributes);
        self.extractPromotionAttributes(attributes, promotion);
        var appEvent = mpInstance._ServerModel.createEventObject({
          messageType: Types.MessageType.PageEvent,
          name: self.generateExpandedEcommerceName(Types.PromotionActionType.getExpansionName(commerceEvent.PromotionAction.PromotionActionType)),
          data: attributes,
          eventType: Types.EventType.Transaction
        });
        appEvents.push(appEvent);
      });
      return appEvents;
    };
    this.expandProductAction = function(commerceEvent) {
      var appEvents = [];
      if (!commerceEvent.ProductAction) {
        return appEvents;
      }
      var shouldExtractActionAttributes = false;
      if (commerceEvent.ProductAction.ProductActionType === Types.ProductActionType.Purchase || commerceEvent.ProductAction.ProductActionType === Types.ProductActionType.Refund) {
        var attributes = extend(false, {}, commerceEvent.EventAttributes);
        attributes["Product Count"] = commerceEvent.ProductAction.ProductList ? commerceEvent.ProductAction.ProductList.length : 0;
        self.extractActionAttributes(attributes, commerceEvent.ProductAction);
        if (commerceEvent.CurrencyCode) {
          attributes["Currency Code"] = commerceEvent.CurrencyCode;
        }
        var plusOneEvent = mpInstance._ServerModel.createEventObject({
          messageType: Types.MessageType.PageEvent,
          name: self.generateExpandedEcommerceName(Types.ProductActionType.getExpansionName(commerceEvent.ProductAction.ProductActionType), true),
          data: attributes,
          eventType: Types.EventType.Transaction
        });
        appEvents.push(plusOneEvent);
      } else {
        shouldExtractActionAttributes = true;
      }
      var products = commerceEvent.ProductAction.ProductList;
      if (!products) {
        return appEvents;
      }
      products.forEach(function(product) {
        var attributes2 = extend(false, commerceEvent.EventAttributes, product.Attributes);
        if (shouldExtractActionAttributes) {
          self.extractActionAttributes(attributes2, commerceEvent.ProductAction);
        } else {
          self.extractTransactionId(attributes2, commerceEvent.ProductAction);
        }
        self.extractProductAttributes(attributes2, product);
        var productEvent = mpInstance._ServerModel.createEventObject({
          messageType: Types.MessageType.PageEvent,
          name: self.generateExpandedEcommerceName(Types.ProductActionType.getExpansionName(commerceEvent.ProductAction.ProductActionType)),
          data: attributes2,
          eventType: Types.EventType.Transaction
        });
        appEvents.push(productEvent);
      });
      return appEvents;
    };
    this.createCommerceEventObject = function(customFlags, options) {
      var baseEvent;
      var extend2 = mpInstance._Helpers.extend;
      mpInstance.Logger.verbose(Messages$5.InformationMessages.StartingLogCommerceEvent);
      if (mpInstance._Helpers.canLog()) {
        baseEvent = mpInstance._ServerModel.createEventObject({
          messageType: Types.MessageType.Commerce,
          sourceMessageId: options === null || options === void 0 ? void 0 : options.sourceMessageId
        });
        baseEvent.EventName = "eCommerce - ";
        baseEvent.CurrencyCode = mpInstance._Store.currencyCode;
        baseEvent.ShoppingCart = [];
        baseEvent.CustomFlags = extend2(baseEvent.CustomFlags, customFlags);
        return baseEvent;
      } else {
        mpInstance.Logger.verbose(Messages$5.InformationMessages.AbandonLogEvent);
      }
      return null;
    };
    this.sanitizeAmount = function(amount, category) {
      if (!mpInstance._Helpers.Validators.isStringOrNumber(amount)) {
        var message = [category, "must be of type number. A", _typeof(amount), "was passed. Converting to 0"].join(" ");
        mpInstance.Logger.warning(message);
        return 0;
      }
      return mpInstance._Helpers.parseNumber(amount);
    };
  }
  var ForegroundTimeTracker = (
    /** @class */
    (function() {
      function ForegroundTimeTracker2(timerKey, noFunctional) {
        if (noFunctional === void 0) {
          noFunctional = false;
        }
        this.noFunctional = noFunctional;
        this.isTrackerActive = false;
        this.localStorageName = "";
        this.startTime = 0;
        this.totalTime = 0;
        this.localStorageName = "mprtcl-tos-".concat(timerKey);
        this.timerVault = new LocalStorageVault(this.localStorageName);
        if (!this.noFunctional) {
          this.loadTimeFromStorage();
        }
        this.addHandlers();
        if (document.hidden === false) {
          this.startTracking();
        }
      }
      ForegroundTimeTracker2.prototype.addHandlers = function() {
        var _this = this;
        document.addEventListener("visibilitychange", function() {
          return _this.handleVisibilityChange();
        });
        window.addEventListener("blur", function() {
          return _this.handleWindowBlur();
        });
        window.addEventListener("focus", function() {
          return _this.handleWindowFocus();
        });
        window.addEventListener("storage", function(event) {
          return _this.syncAcrossTabs(event);
        });
        window.addEventListener("beforeunload", function() {
          return _this.updateTimeInPersistence();
        });
      };
      ForegroundTimeTracker2.prototype.handleVisibilityChange = function() {
        if (document.hidden) {
          this.stopTracking();
        } else {
          this.startTracking();
        }
      };
      ForegroundTimeTracker2.prototype.handleWindowBlur = function() {
        if (this.isTrackerActive) {
          this.stopTracking();
        }
      };
      ForegroundTimeTracker2.prototype.handleWindowFocus = function() {
        if (!this.isTrackerActive) {
          this.startTracking();
        }
      };
      ForegroundTimeTracker2.prototype.syncAcrossTabs = function(event) {
        if (event.key === this.localStorageName && event.newValue !== null) {
          var newTime = parseFloat(event.newValue) || 0;
          this.totalTime = newTime;
        }
      };
      ForegroundTimeTracker2.prototype.updateTimeInPersistence = function() {
        if (this.isTrackerActive && !this.noFunctional) {
          this.timerVault.store(Math.round(this.totalTime));
        }
      };
      ForegroundTimeTracker2.prototype.loadTimeFromStorage = function() {
        var storedTime = this.timerVault.retrieve();
        if (isNumber(storedTime) && storedTime !== null) {
          this.totalTime = storedTime;
        }
      };
      ForegroundTimeTracker2.prototype.startTracking = function() {
        if (!document.hidden) {
          this.startTime = Math.floor(performance.now());
          this.isTrackerActive = true;
        }
      };
      ForegroundTimeTracker2.prototype.stopTracking = function() {
        if (this.isTrackerActive) {
          this.setTotalTime();
          this.updateTimeInPersistence();
          this.isTrackerActive = false;
        }
      };
      ForegroundTimeTracker2.prototype.setTotalTime = function() {
        if (this.isTrackerActive) {
          var now = Math.floor(performance.now());
          this.totalTime += now - this.startTime;
          this.startTime = now;
        }
      };
      ForegroundTimeTracker2.prototype.getTimeInForeground = function() {
        this.setTotalTime();
        this.updateTimeInPersistence();
        return this.totalTime;
      };
      ForegroundTimeTracker2.prototype.resetTimer = function() {
        this.totalTime = 0;
        this.updateTimeInPersistence();
      };
      return ForegroundTimeTracker2;
    })()
  );
  function normalizeRoktLauncherOptions(launcherOptions) {
    var normalizedOptions = launcherOptions ? __assign({}, launcherOptions) : {};
    var hasNoDeviceId = normalizedOptions.noDeviceId === true || normalizedOptions.noDeviceID === true;
    if (hasNoDeviceId) {
      normalizedOptions.noDeviceId = true;
      normalizedOptions.noFunctional = true;
      normalizedOptions.noTargeting = true;
    }
    return normalizedOptions;
  }
  function createSDKConfig(config) {
    var sdkConfig = {};
    for (var prop in Constants.DefaultConfig) {
      if (Constants.DefaultConfig.hasOwnProperty(prop)) {
        sdkConfig[prop] = Constants.DefaultConfig[prop];
      }
    }
    if (config) {
      for (var prop in config) {
        if (config.hasOwnProperty(prop)) {
          sdkConfig[prop] = config[prop];
        }
      }
    }
    for (var prop in Constants.DefaultBaseUrls) {
      sdkConfig[prop] = Constants.DefaultBaseUrls[prop];
    }
    sdkConfig.flags = sdkConfig.flags || {};
    return sdkConfig;
  }
  function Store(config, mpInstance, apiKey) {
    var _this = this;
    var createMainStorageName = mpInstance._Helpers.createMainStorageName;
    var isWebviewEnabled = mpInstance._NativeSdkHelpers.isWebviewEnabled;
    var defaultStore = {
      isEnabled: true,
      sessionAttributes: {},
      localSessionAttributes: {},
      currentSessionMPIDs: [],
      consentState: null,
      sessionId: null,
      isFirstRun: null,
      clientId: null,
      deviceId: null,
      devToken: null,
      serverSettings: {},
      dateLastEventSent: null,
      sessionStartDate: null,
      currentPosition: null,
      isTracking: false,
      watchPositionId: null,
      cartProducts: [],
      eventQueue: [],
      currencyCode: null,
      globalTimer: null,
      context: null,
      configurationLoaded: false,
      identityCallInFlight: false,
      identityCallFailed: false,
      identifyRequestCount: 0,
      SDKConfig: {},
      nonCurrentUserMPIDs: {},
      identifyCalled: false,
      isLoggedIn: false,
      cookieSyncDates: {},
      integrationAttributes: {},
      requireDelay: true,
      isLocalStorageAvailable: null,
      storageName: null,
      activeForwarders: [],
      kits: {},
      sideloadedKits: [],
      configuredForwarders: [],
      pixelConfigurations: [],
      wrapperSDKInfo: {
        name: "none",
        version: null,
        isInfoSet: false
      },
      roktAccountId: null,
      integrationName: null,
      // Placeholder for in-memory persistence model
      persistenceData: {
        gs: {}
      }
    };
    for (var key in defaultStore) {
      this[key] = defaultStore[key];
    }
    this.devToken = apiKey || null;
    this.integrationDelayTimeoutStart = Date.now();
    this.SDKConfig = createSDKConfig(config);
    if (config) {
      if (!config.hasOwnProperty("flags")) {
        this.SDKConfig.flags = {};
      }
      this.SDKConfig.flags = processFlags(config);
      if (config.deviceId) {
        this.deviceId = config.deviceId;
      }
      if (config.hasOwnProperty("isDevelopmentMode")) {
        this.SDKConfig.isDevelopmentMode = returnConvertedBoolean(config.isDevelopmentMode);
      } else {
        this.SDKConfig.isDevelopmentMode = false;
      }
      var baseUrls = processBaseUrls(config, this.SDKConfig.flags, apiKey);
      for (var baseUrlKeys in baseUrls) {
        this.SDKConfig[baseUrlKeys] = baseUrls[baseUrlKeys];
      }
      this.SDKConfig.useNativeSdk = !!config.useNativeSdk;
      this.SDKConfig.kits = config.kits || {};
      this.SDKConfig.sideloadedKits = config.sideloadedKits || [];
      if (config.hasOwnProperty("isIOS")) {
        this.SDKConfig.isIOS = config.isIOS;
      } else {
        this.SDKConfig.isIOS = window.mParticle && window.mParticle.isIOS ? window.mParticle.isIOS : false;
      }
      if (config.hasOwnProperty("useCookieStorage")) {
        this.SDKConfig.useCookieStorage = config.useCookieStorage;
      } else {
        this.SDKConfig.useCookieStorage = false;
      }
      if (config.hasOwnProperty("maxProducts")) {
        this.SDKConfig.maxProducts = config.maxProducts;
      } else {
        this.SDKConfig.maxProducts = Constants.DefaultConfig.maxProducts;
      }
      if (config.hasOwnProperty("maxCookieSize")) {
        this.SDKConfig.maxCookieSize = config.maxCookieSize;
      } else {
        this.SDKConfig.maxCookieSize = Constants.DefaultConfig.maxCookieSize;
      }
      if (config.hasOwnProperty("appName")) {
        this.SDKConfig.appName = config.appName;
      }
      if (config.hasOwnProperty("package")) {
        this.SDKConfig["package"] = config["package"];
      }
      if (config.hasOwnProperty("integrationDelayTimeout")) {
        this.SDKConfig.integrationDelayTimeout = config.integrationDelayTimeout;
      } else {
        this.SDKConfig.integrationDelayTimeout = Constants.DefaultConfig.integrationDelayTimeout;
      }
      if (config.hasOwnProperty("identifyRequest")) {
        this.SDKConfig.identifyRequest = config.identifyRequest;
      }
      if (config.hasOwnProperty("identityCallback")) {
        var callback = config.identityCallback;
        if (mpInstance._Helpers.Validators.isFunction(callback)) {
          this.SDKConfig.identityCallback = config.identityCallback;
        } else {
          mpInstance.Logger.warning("The optional callback must be a function. You tried entering a(n) " + _typeof(callback) + " . Callback not set. Please set your callback again.");
        }
      }
      if (config.hasOwnProperty("appVersion")) {
        this.SDKConfig.appVersion = config.appVersion;
      }
      if (config.hasOwnProperty("appName")) {
        this.SDKConfig.appName = config.appName;
      }
      if (config.hasOwnProperty("sessionTimeout")) {
        this.SDKConfig.sessionTimeout = config.sessionTimeout;
      }
      if (config.hasOwnProperty("dataPlan")) {
        this.SDKConfig.dataPlan = {
          PlanVersion: null,
          PlanId: null
        };
        var dataPlan = config.dataPlan;
        if (dataPlan.planId) {
          if (isDataPlanSlug(dataPlan.planId)) {
            this.SDKConfig.dataPlan.PlanId = dataPlan.planId;
          } else {
            mpInstance.Logger.error("Your data plan id must be a string and match the data plan slug format (i.e. under_case_slug)");
          }
        }
        if (dataPlan.planVersion) {
          if (isNumber(dataPlan.planVersion)) {
            this.SDKConfig.dataPlan.PlanVersion = dataPlan.planVersion;
          } else {
            mpInstance.Logger.error("Your data plan version must be a number");
          }
        }
      } else {
        this.SDKConfig.dataPlan = {};
      }
      if (config.hasOwnProperty("forceHttps")) {
        this.SDKConfig.forceHttps = config.forceHttps;
      } else {
        this.SDKConfig.forceHttps = true;
      }
      this.SDKConfig.customFlags = config.customFlags || {};
      if (config.hasOwnProperty("minWebviewBridgeVersion")) {
        this.SDKConfig.minWebviewBridgeVersion = config.minWebviewBridgeVersion;
      } else {
        this.SDKConfig.minWebviewBridgeVersion = 1;
      }
      if (config.hasOwnProperty("aliasMaxWindow")) {
        this.SDKConfig.aliasMaxWindow = config.aliasMaxWindow;
      } else {
        this.SDKConfig.aliasMaxWindow = Constants.DefaultConfig.aliasMaxWindow;
      }
      if (config.hasOwnProperty("dataPlanOptions")) {
        var dataPlanOptions = config.dataPlanOptions;
        if (!dataPlanOptions.hasOwnProperty("dataPlanVersion") || !dataPlanOptions.hasOwnProperty("blockUserAttributes") || !dataPlanOptions.hasOwnProperty("blockEventAttributes") || !dataPlanOptions.hasOwnProperty("blockEvents") || !dataPlanOptions.hasOwnProperty("blockUserIdentities")) {
          mpInstance.Logger.error('Ensure your config.dataPlanOptions object has the following keys: a "dataPlanVersion" object, and "blockUserAttributes", "blockEventAttributes", "blockEvents", "blockUserIdentities" booleans');
        }
      }
      if (config.hasOwnProperty("onCreateBatch")) {
        if (typeof config.onCreateBatch === "function") {
          this.SDKConfig.onCreateBatch = config.onCreateBatch;
        } else {
          mpInstance.Logger.error("config.onCreateBatch must be a function");
          this.SDKConfig.onCreateBatch = void 0;
        }
      }
    }
    this._getFromPersistence = function(mpid, key2) {
      if (!mpid) {
        return null;
      }
      _this.syncPersistenceData();
      if (_this.persistenceData && _this.persistenceData[mpid] && _this.persistenceData[mpid][key2]) {
        return _this.persistenceData[mpid][key2];
      } else {
        return null;
      }
    };
    this._setPersistence = function(mpid, key2, value) {
      var _a2;
      if (!mpid) {
        return;
      }
      _this.syncPersistenceData();
      if (_this.persistenceData) {
        if (_this.persistenceData[mpid]) {
          _this.persistenceData[mpid][key2] = value;
        } else {
          _this.persistenceData[mpid] = (_a2 = {}, _a2[key2] = value, _a2);
        }
        if (isObject(_this.persistenceData[mpid][key2]) && isEmpty(_this.persistenceData[mpid][key2])) {
          delete _this.persistenceData[mpid][key2];
        }
        mpInstance._Persistence.savePersistence(_this.persistenceData);
      }
    };
    this.hasInvalidIdentifyRequest = function() {
      var identifyRequest = _this.SDKConfig.identifyRequest;
      return isObject(identifyRequest) && isObject(identifyRequest.userIdentities) && isEmpty(identifyRequest.userIdentities) || !identifyRequest;
    };
    this.getConsentState = function(mpid) {
      var fromMinifiedJsonObject = mpInstance._Consent.ConsentSerialization.fromMinifiedJsonObject;
      var serializedConsentState = _this._getFromPersistence(mpid, "con");
      if (!isEmpty(serializedConsentState)) {
        return fromMinifiedJsonObject(serializedConsentState);
      }
      return null;
    };
    this.setConsentState = function(mpid, consentState) {
      var toMinifiedJsonObject = mpInstance._Consent.ConsentSerialization.toMinifiedJsonObject;
      if (consentState || consentState === null) {
        _this._setPersistence(mpid, "con", toMinifiedJsonObject(consentState));
      }
    };
    this.getDeviceId = function() {
      return _this.deviceId;
    };
    this.setDeviceId = function(deviceId) {
      _this.deviceId = deviceId;
      _this.persistenceData.gs.das = deviceId;
      mpInstance._Persistence.update();
    };
    this.getFirstSeenTime = function(mpid) {
      return _this._getFromPersistence(mpid, "fst");
    };
    this.setFirstSeenTime = function(mpid, _time) {
      if (!mpid) {
        return;
      }
      var time = _time || (/* @__PURE__ */ new Date()).getTime();
      _this._setPersistence(mpid, "fst", time);
    };
    this.getLastSeenTime = function(mpid) {
      if (!mpid) {
        return null;
      }
      var currentUser = mpInstance.Identity.getCurrentUser();
      if (mpid === (currentUser === null || currentUser === void 0 ? void 0 : currentUser.getMPID())) {
        return (/* @__PURE__ */ new Date()).getTime();
      }
      return _this._getFromPersistence(mpid, "lst");
    };
    this.setLastSeenTime = function(mpid, _time) {
      if (!mpid) {
        return;
      }
      var time = _time || (/* @__PURE__ */ new Date()).getTime();
      _this._setPersistence(mpid, "lst", time);
    };
    this.getLocalSessionAttributes = function() {
      return _this.localSessionAttributes || {};
    };
    this.setLocalSessionAttribute = function(key2, value) {
      var _a2;
      _this.localSessionAttributes[key2] = value;
      _this.persistenceData.gs.lsa = __assign(__assign({}, _this.persistenceData.gs.lsa || {}), (_a2 = {}, _a2[key2] = value, _a2));
      mpInstance._Persistence.savePersistence(_this.persistenceData);
    };
    this.syncPersistenceData = function() {
      var persistenceData = mpInstance._Persistence.getPersistence();
      _this.persistenceData = extend({}, _this.persistenceData, persistenceData);
    };
    this.getUserAttributes = function(mpid) {
      return _this._getFromPersistence(mpid, "ua") || {};
    };
    this.setUserAttributes = function(mpid, userAttributes) {
      return _this._setPersistence(mpid, "ua", userAttributes);
    };
    this.getUserIdentities = function(mpid) {
      return _this._getFromPersistence(mpid, "ui") || {};
    };
    this.setUserIdentities = function(mpid, userIdentities) {
      _this._setPersistence(mpid, "ui", userIdentities);
    };
    this.getRoktAccountId = function() {
      return _this.roktAccountId;
    };
    this.setRoktAccountId = function(accountId) {
      _this.roktAccountId = accountId;
    };
    this.getIntegrationName = function() {
      return _this.integrationName;
    };
    this.setIntegrationName = function(integrationName) {
      _this.integrationName = integrationName;
    };
    this.getTimeOnSite = function() {
      var _a2;
      return (_a2 = mpInstance._timeOnSiteTimer) === null || _a2 === void 0 ? void 0 : _a2.getTimeInForeground();
    };
    this.getTotalTimeOnSite = function() {
      return _this.sessionStartDate ? Date.now() - _this.sessionStartDate.getTime() : void 0;
    };
    this.addMpidToSessionHistory = function(mpid, previousMPID) {
      var indexOfMPID = _this.currentSessionMPIDs.indexOf(mpid);
      if (mpid && previousMPID !== mpid && indexOfMPID < 0) {
        _this.currentSessionMPIDs.push(mpid);
        return;
      }
      if (indexOfMPID >= 0) {
        _this.currentSessionMPIDs = moveElementToEnd(_this.currentSessionMPIDs, indexOfMPID);
      }
    };
    this.nullifySession = function() {
      _this.sessionId = null;
      _this.dateLastEventSent = null;
      _this.sessionStartDate = null;
      _this.sessionAttributes = {};
      _this.localSessionAttributes = {};
      mpInstance._Persistence.update();
    };
    this.processConfig = function(config2) {
      var workspaceToken = config2.workspaceToken, requiredWebviewBridgeName = config2.requiredWebviewBridgeName;
      if (config2.flags) {
        _this.SDKConfig.flags = processFlags(config2);
      }
      var baseUrls2 = processBaseUrls(config2, _this.SDKConfig.flags, apiKey);
      for (var baseUrlKeys2 in baseUrls2) {
        _this.SDKConfig[baseUrlKeys2] = baseUrls2[baseUrlKeys2];
      }
      if (workspaceToken) {
        _this.SDKConfig.workspaceToken = workspaceToken;
        var noFunctional = normalizeRoktLauncherOptions(config2 === null || config2 === void 0 ? void 0 : config2.launcherOptions).noFunctional;
        mpInstance._timeOnSiteTimer = new ForegroundTimeTracker(workspaceToken, noFunctional);
      } else {
        mpInstance.Logger.warning("You should have a workspaceToken on your config object for security purposes.");
      }
      _this.storageName = createMainStorageName(workspaceToken);
      _this.SDKConfig.requiredWebviewBridgeName = requiredWebviewBridgeName || workspaceToken;
      _this.webviewBridgeEnabled = isWebviewEnabled(_this.SDKConfig.requiredWebviewBridgeName, _this.SDKConfig.minWebviewBridgeVersion);
      _this.configurationLoaded = true;
    };
  }
  function processFlags(config) {
    var flags = {};
    var _a2 = Constants.FeatureFlags, ReportBatching2 = _a2.ReportBatching, EventBatchingIntervalMillis = _a2.EventBatchingIntervalMillis, OfflineStorage = _a2.OfflineStorage, DirectUrlRouting = _a2.DirectUrlRouting, CacheIdentity2 = _a2.CacheIdentity, AudienceAPI = _a2.AudienceAPI, CaptureIntegrationSpecificIds2 = _a2.CaptureIntegrationSpecificIds, CaptureIntegrationSpecificIdsV22 = _a2.CaptureIntegrationSpecificIdsV2, AstBackgroundEvents = _a2.AstBackgroundEvents, AutoLogPageView = _a2.AutoLogPageView;
    if (!config.flags) {
      return {};
    }
    flags[ReportBatching2] = config.flags[ReportBatching2] || false;
    flags[EventBatchingIntervalMillis] = parseNumber(config.flags[EventBatchingIntervalMillis]) || Constants.DefaultConfig.uploadInterval;
    flags[OfflineStorage] = config.flags[OfflineStorage] || "0";
    flags[DirectUrlRouting] = config.flags[DirectUrlRouting] === "True";
    flags[CacheIdentity2] = config.flags[CacheIdentity2] === "True";
    flags[AudienceAPI] = config.flags[AudienceAPI] === "True";
    flags[CaptureIntegrationSpecificIds2] = config.flags[CaptureIntegrationSpecificIds2] === "True";
    flags[CaptureIntegrationSpecificIdsV22] = config.flags[CaptureIntegrationSpecificIdsV22] || "none";
    flags[AstBackgroundEvents] = config.flags[AstBackgroundEvents] === "True";
    flags[AutoLogPageView] = config.flags[AutoLogPageView] === "True";
    return flags;
  }
  function processBaseUrls(config, flags, apiKey) {
    if (!apiKey) {
      return {};
    }
    if (!isEmpty(config.domain)) {
      return processCustomBaseUrls(config);
    }
    if (flags.directURLRouting) {
      return processDirectBaseUrls(config, apiKey);
    } else {
      return processCustomBaseUrls(config);
    }
  }
  function processCustomBaseUrls(config) {
    var defaultBaseUrls = Constants.DefaultBaseUrls;
    var CNAMEUrlPaths = Constants.CNAMEUrlPaths;
    var newBaseUrls = {};
    if (!isEmpty(config.domain)) {
      for (var pathKey in CNAMEUrlPaths) {
        newBaseUrls[pathKey] = "".concat(config.domain).concat(CNAMEUrlPaths[pathKey]);
      }
      return newBaseUrls;
    }
    for (var baseUrlKey in defaultBaseUrls) {
      newBaseUrls[baseUrlKey] = config[baseUrlKey] || defaultBaseUrls[baseUrlKey];
    }
    return newBaseUrls;
  }
  function processDirectBaseUrls(config, apiKey) {
    var defaultBaseUrls = Constants.DefaultBaseUrls;
    var directBaseUrls = {};
    var DEFAULT_SILO = "us1";
    var splitKey = apiKey.split("-");
    var routingPrefix = splitKey.length <= 1 ? DEFAULT_SILO : splitKey[0];
    for (var baseUrlKey in defaultBaseUrls) {
      if (baseUrlKey === "configUrl") {
        directBaseUrls[baseUrlKey] = config[baseUrlKey] || defaultBaseUrls[baseUrlKey];
        continue;
      }
      if (config.hasOwnProperty(baseUrlKey)) {
        directBaseUrls[baseUrlKey] = config[baseUrlKey];
      } else {
        var urlparts = defaultBaseUrls[baseUrlKey].split(".");
        directBaseUrls[baseUrlKey] = __spreadArray([urlparts[0], routingPrefix], urlparts.slice(1), true).join(".");
      }
    }
    return directBaseUrls;
  }
  var Logger = (
    /** @class */
    (function() {
      function Logger2(config) {
        var _a2, _b2;
        this.logLevel = (_a2 = config.logLevel) !== null && _a2 !== void 0 ? _a2 : LogLevelType.Warning;
        this.logger = (_b2 = config.logger) !== null && _b2 !== void 0 ? _b2 : new ConsoleLogger();
      }
      Logger2.prototype.verbose = function(msg) {
        if (this.logLevel === LogLevelType.None) return;
        if (this.logger.verbose && this.logLevel === LogLevelType.Verbose) {
          this.logger.verbose(msg);
        }
      };
      Logger2.prototype.warning = function(msg) {
        if (this.logLevel === LogLevelType.None) return;
        if (this.logger.warning && (this.logLevel === LogLevelType.Verbose || this.logLevel === LogLevelType.Warning)) {
          this.logger.warning(msg);
        }
      };
      Logger2.prototype.error = function(msg) {
        if (this.logLevel === LogLevelType.None) return;
        if (this.logger.error) {
          this.logger.error(msg);
        }
      };
      Logger2.prototype.isVerbose = function() {
        return this.logLevel === LogLevelType.Verbose;
      };
      Logger2.prototype.setLogLevel = function(newLogLevel) {
        this.logLevel = newLogLevel;
      };
      return Logger2;
    })()
  );
  var ConsoleLogger = (
    /** @class */
    (function() {
      function ConsoleLogger2() {
      }
      ConsoleLogger2.prototype.verbose = function(msg) {
        if (console && console.info) {
          console.info(msg);
        }
      };
      ConsoleLogger2.prototype.error = function(msg) {
        if (console && console.error) {
          console.error(msg);
        }
      };
      ConsoleLogger2.prototype.warning = function(msg) {
        if (console && console.warn) {
          console.warn(msg);
        }
      };
      return ConsoleLogger2;
    })()
  );
  var Base64 = Polyfill.Base64, Messages$4 = Constants.Messages, Base64CookieKeys = Constants.Base64CookieKeys, SDKv2NonMPIDCookieKeys = Constants.SDKv2NonMPIDCookieKeys, StorageNames = Constants.StorageNames;
  function getMParticleManager() {
    return window.mParticle;
  }
  function _Persistence(mpInstance) {
    var self = this;
    this.useLocalStorage = function() {
      return !mpInstance._Store.SDKConfig.useCookieStorage && mpInstance._Store.isLocalStorageAvailable;
    };
    function setFirstRunFromExistingData(localStorageData, cookies) {
      if (!localStorageData && !cookies) {
        mpInstance._Store.isFirstRun = true;
        mpInstance._Store.mpid = 0;
        return;
      }
      mpInstance._Store.isFirstRun = false;
    }
    function mergeStorageSources(localStorageData, cookies) {
      if (localStorageData && cookies) {
        return extend(false, localStorageData, cookies);
      }
      return localStorageData || cookies;
    }
    function migrateLocalStorageToCookies(storage, localStorageData, cookies) {
      var allData;
      if (localStorageData) {
        allData = mergeStorageSources(localStorageData, cookies);
        storage.removeItem(mpInstance._Store.storageName);
      } else if (cookies) {
        allData = cookies;
      }
      self.storeDataInMemory(allData);
      return allData;
    }
    function migrateCookiesToLocalStorage(localStorageData, cookies) {
      if (!cookies) {
        self.storeDataInMemory(localStorageData);
        return;
      }
      var allData = mergeStorageSources(localStorageData, cookies);
      self.storeDataInMemory(allData);
      self.expireCookies(mpInstance._Store.storageName);
      return allData;
    }
    function loadPersistenceIntoMemory(localStorageData, cookies) {
      if (!mpInstance._Store.isLocalStorageAvailable) {
        self.storeDataInMemory(cookies);
        return;
      }
      if (mpInstance._Store.SDKConfig.useCookieStorage) {
        return migrateLocalStorageToCookies(window.localStorage, localStorageData, cookies);
      }
      return migrateCookiesToLocalStorage(localStorageData, cookies);
    }
    function copyNonCurrentUserMpids(allData) {
      for (var key in allData) {
        if (allData.hasOwnProperty(key) && !SDKv2NonMPIDCookieKeys[key]) {
          mpInstance._Store.nonCurrentUserMPIDs[key] = allData[key];
        }
      }
    }
    function clearCorruptStorage() {
      if (self.useLocalStorage() && mpInstance._Store.isLocalStorageAvailable) {
        localStorage.removeItem(mpInstance._Store.storageName);
        return;
      }
      self.expireCookies(mpInstance._Store.storageName);
    }
    this.initializeStorage = function() {
      try {
        var localStorageData = self.getLocalStorage();
        var cookies = self.getCookie();
        setFirstRunFromExistingData(localStorageData, cookies);
        if (!mpInstance._Store.isLocalStorageAvailable) {
          mpInstance._Store.SDKConfig.useCookieStorage = true;
        }
        var allData = loadPersistenceIntoMemory(localStorageData, cookies);
        copyNonCurrentUserMpids(allData);
        self.update();
      } catch (e) {
        clearCorruptStorage();
        mpInstance.Logger.error("Error initializing storage: " + e);
      }
    };
    this.update = function() {
      if (!mpInstance._Store.webviewBridgeEnabled) {
        if (mpInstance._Store.SDKConfig.useCookieStorage) {
          self.setCookie();
        }
        self.setLocalStorage();
      }
    };
    function applyEmptyPersistenceDefaults() {
      mpInstance.Logger.verbose(Messages$4.InformationMessages.CookieNotFound);
      mpInstance._Store.clientId = mpInstance._Store.clientId || mpInstance._Helpers.generateUniqueId();
      mpInstance._Store.deviceId = mpInstance._Store.deviceId || mpInstance._Helpers.generateUniqueId();
    }
    function hydrateStoreFromPersistence(obj, currentMPID) {
      if (currentMPID) {
        mpInstance._Store.mpid = currentMPID;
      } else {
        mpInstance._Store.mpid = obj.cu || 0;
      }
      obj.gs = obj.gs || {};
      mpInstance._Store.sessionId = obj.gs.sid || mpInstance._Store.sessionId;
      mpInstance._Store.isEnabled = typeof obj.gs.ie !== "undefined" ? obj.gs.ie : mpInstance._Store.isEnabled;
      mpInstance._Store.sessionAttributes = obj.gs.sa || mpInstance._Store.sessionAttributes;
      mpInstance._Store.localSessionAttributes = obj.gs.lsa || mpInstance._Store.localSessionAttributes;
      mpInstance._Store.serverSettings = obj.gs.ss || mpInstance._Store.serverSettings;
      mpInstance._Store.devToken = mpInstance._Store.devToken || obj.gs.dt;
      mpInstance._Store.SDKConfig.appVersion = mpInstance._Store.SDKConfig.appVersion || obj.gs.av;
      mpInstance._Store.clientId = obj.gs.cgid || mpInstance._Store.clientId || mpInstance._Helpers.generateUniqueId();
      mpInstance._Store.deviceId = mpInstance._Store.deviceId || obj.gs.das || mpInstance._Helpers.generateUniqueId();
      mpInstance._Store.integrationAttributes = obj.gs.ia || {};
      mpInstance._Store.context = obj.gs.c || mpInstance._Store.context;
      mpInstance._Store.currentSessionMPIDs = obj.gs.csm || mpInstance._Store.currentSessionMPIDs;
      mpInstance._Store.isLoggedIn = obj.l === true;
      if (obj.gs.les) {
        mpInstance._Store.dateLastEventSent = new Date(obj.gs.les);
      }
      mpInstance._Store.sessionStartDate = obj.gs.ssd ? new Date(obj.gs.ssd) : /* @__PURE__ */ new Date();
      if (currentMPID) {
        obj = obj[currentMPID];
      } else {
        obj = obj[obj.cu];
      }
    }
    this.storeDataInMemory = function(obj, currentMPID) {
      try {
        if (!obj) {
          applyEmptyPersistenceDefaults();
          return;
        }
        hydrateStoreFromPersistence(obj, currentMPID);
      } catch (e) {
        mpInstance.Logger.error(Messages$4.ErrorMessages.CookieParseError);
      }
    };
    this.determineLocalStorageAvailability = function(storage) {
      var mParticleManager2 = getMParticleManager();
      if (mParticleManager2 === null || mParticleManager2 === void 0 ? void 0 : mParticleManager2._forceNoLocalStorage) {
        return false;
      }
      try {
        storage.setItem("mparticle", "test");
        var result = storage.getItem("mparticle") === "test";
        storage.removeItem("mparticle");
        return Boolean(result && storage);
      } catch (e) {
        return false;
      }
    };
    this.setLocalStorage = function() {
      var _a2;
      if (!mpInstance._Store.isLocalStorageAvailable) {
        return;
      }
      if ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) {
        return;
      }
      var key = mpInstance._Store.storageName, localStorageData = self.getLocalStorage() || {}, currentUser = mpInstance.Identity.getCurrentUser(), mpid = currentUser ? currentUser.getMPID() : null;
      if (!mpInstance._Store.SDKConfig.useCookieStorage) {
        localStorageData.gs = localStorageData.gs || {};
        localStorageData.l = mpInstance._Store.isLoggedIn ? 1 : 0;
        if (mpInstance._Store.sessionId) {
          localStorageData.gs.csm = mpInstance._Store.currentSessionMPIDs;
        }
        localStorageData.gs.ie = mpInstance._Store.isEnabled;
        if (mpid) {
          localStorageData.cu = mpid;
        }
        if (Object.keys(mpInstance._Store.nonCurrentUserMPIDs).length) {
          localStorageData = extend({}, localStorageData, mpInstance._Store.nonCurrentUserMPIDs);
          mpInstance._Store.nonCurrentUserMPIDs = {};
        }
        localStorageData = setGlobalStorageAttributes(localStorageData);
        try {
          window.localStorage.setItem(encodeURIComponent(key), self.encodePersistence(JSON.stringify(localStorageData)));
        } catch (e) {
          mpInstance.Logger.error("Error with setting localStorage item.");
        }
      }
    };
    function setGlobalStorageAttributes(data) {
      var store = mpInstance._Store;
      data.gs.sid = store.sessionId;
      data.gs.ie = store.isEnabled;
      data.gs.sa = store.sessionAttributes;
      data.gs.lsa = store.localSessionAttributes;
      data.gs.ss = store.serverSettings;
      data.gs.dt = store.devToken;
      data.gs.les = store.dateLastEventSent ? store.dateLastEventSent.getTime() : null;
      data.gs.av = store.SDKConfig.appVersion;
      data.gs.cgid = store.clientId;
      data.gs.das = store.deviceId;
      data.gs.c = store.context;
      data.gs.ssd = store.sessionStartDate ? store.sessionStartDate.getTime() : 0;
      data.gs.ia = store.integrationAttributes;
      return data;
    }
    this.getLocalStorage = function() {
      if (!mpInstance._Store.isLocalStorageAvailable) {
        return null;
      }
      var key = mpInstance._Store.storageName;
      var decodedPersistence = self.decodePersistence(window.localStorage.getItem(key));
      if (!decodedPersistence) {
        return null;
      }
      var parsedPersistence = JSON.parse(decodedPersistence);
      var obj = {};
      for (var key_1 in parsedPersistence) {
        if (parsedPersistence.hasOwnProperty(key_1)) {
          obj[key_1] = parsedPersistence[key_1];
        }
      }
      if (Object.keys(obj).length) {
        return obj;
      }
      return null;
    };
    this.expireCookies = function(cookieName) {
      var date = /* @__PURE__ */ new Date(), expires, domain, cookieDomain;
      cookieDomain = self.getCookieDomain();
      if (cookieDomain === "") {
        domain = "";
      } else {
        domain = ";domain=" + cookieDomain;
      }
      date.setTime(date.getTime() - 24 * 60 * 60 * 1e3);
      expires = "; expires=" + date.toUTCString();
      document.cookie = cookieName + "=" + expires + "; path=/" + domain;
    };
    this.getCookie = function() {
      var cookies, key = mpInstance._Store.storageName, i, l, parts, name, cookie, result = key ? void 0 : {};
      mpInstance.Logger.verbose(Messages$4.InformationMessages.CookieSearch);
      try {
        cookies = window.document.cookie.split("; ");
      } catch (e) {
        mpInstance.Logger.verbose("Unable to parse undefined cookie");
        return null;
      }
      for (i = 0, l = cookies.length; i < l; i++) {
        try {
          parts = cookies[i].split("=");
          name = parts.shift();
          cookie = parts.join("=");
        } catch (e) {
          mpInstance.Logger.verbose("Unable to parse cookie: " + name + ". Skipping.");
        }
        if (key && key === name) {
          result = mpInstance._Helpers.converted(cookie);
          break;
        }
        if (!key) {
          result[name] = mpInstance._Helpers.converted(cookie);
        }
      }
      if (result) {
        mpInstance.Logger.verbose(Messages$4.InformationMessages.CookieFound);
        return JSON.parse(self.decodePersistence(result));
      } else {
        return null;
      }
    };
    this.setCookie = function() {
      var _a2;
      if ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) {
        return;
      }
      var mpid, currentUser = mpInstance.Identity.getCurrentUser();
      if (currentUser) {
        mpid = currentUser.getMPID();
      }
      var date = /* @__PURE__ */ new Date(), key = mpInstance._Store.storageName, cookies = self.getCookie() || {}, expires = new Date(date.getTime() + mpInstance._Store.SDKConfig.cookieExpiration * 24 * 60 * 60 * 1e3).toUTCString(), cookieDomain, domain, encodedCookiesWithExpirationAndPath;
      cookieDomain = self.getCookieDomain();
      if (cookieDomain === "") {
        domain = "";
      } else {
        domain = ";domain=" + cookieDomain;
      }
      cookies.gs = cookies.gs || {};
      if (mpInstance._Store.sessionId) {
        cookies.gs.csm = mpInstance._Store.currentSessionMPIDs;
      }
      if (mpid) {
        cookies.cu = mpid;
      }
      cookies.l = mpInstance._Store.isLoggedIn ? 1 : 0;
      cookies = setGlobalStorageAttributes(cookies);
      if (Object.keys(mpInstance._Store.nonCurrentUserMPIDs).length) {
        cookies = extend({}, cookies, mpInstance._Store.nonCurrentUserMPIDs);
        mpInstance._Store.nonCurrentUserMPIDs = {};
      }
      encodedCookiesWithExpirationAndPath = self.reduceAndEncodePersistence(cookies, expires, domain, mpInstance._Store.SDKConfig.maxCookieSize);
      mpInstance.Logger.verbose(Messages$4.InformationMessages.CookieSet);
      window.document.cookie = encodeURIComponent(key) + "=" + encodedCookiesWithExpirationAndPath;
    };
    function isEncodedCookieTooLarge(encoded, maxCookieSize) {
      return encoded.length > maxCookieSize;
    }
    function removeUnsessionedMpidsWhenOversized(persistence, expires, domain, maxCookieSize) {
      var encodedCookiesWithExpirationAndPath;
      for (var key in persistence) {
        if (!persistence.hasOwnProperty(key)) {
          continue;
        }
        encodedCookiesWithExpirationAndPath = createFullEncodedCookie(persistence, expires, domain);
        if (!isEncodedCookieTooLarge(encodedCookiesWithExpirationAndPath, maxCookieSize)) {
          continue;
        }
        if (SDKv2NonMPIDCookieKeys[key] || key === persistence.cu) {
          continue;
        }
        delete persistence[key];
      }
      return encodedCookiesWithExpirationAndPath;
    }
    function collectRemovableMpids(persistence) {
      var MPIDsOnCookie = {};
      for (var potentialMPID in persistence) {
        if (!persistence.hasOwnProperty(potentialMPID)) {
          continue;
        }
        if (SDKv2NonMPIDCookieKeys[potentialMPID] || potentialMPID === persistence.cu) {
          continue;
        }
        MPIDsOnCookie[potentialMPID] = 1;
      }
      return MPIDsOnCookie;
    }
    function removeMpidsNotInCurrentSession(persistence, MPIDsOnCookie, currentSessionMPIDs, expires, domain, maxCookieSize) {
      var encodedCookiesWithExpirationAndPath;
      for (var mpid in MPIDsOnCookie) {
        encodedCookiesWithExpirationAndPath = createFullEncodedCookie(persistence, expires, domain);
        if (!isEncodedCookieTooLarge(encodedCookiesWithExpirationAndPath, maxCookieSize)) {
          continue;
        }
        if (!MPIDsOnCookie.hasOwnProperty(mpid)) {
          continue;
        }
        if (currentSessionMPIDs.indexOf(mpid) === -1) {
          delete persistence[mpid];
        }
      }
      return encodedCookiesWithExpirationAndPath;
    }
    function logAndRemoveOversizedMpid(persistence, MPIDtoRemove, maxCookieSize) {
      if (persistence[MPIDtoRemove]) {
        mpInstance.Logger.verbose("Size of new encoded cookie is larger than maxCookieSize setting of " + maxCookieSize + ". Removing from cookie the earliest logged in MPID containing: " + JSON.stringify(persistence[MPIDtoRemove], null, 2));
        delete persistence[MPIDtoRemove];
        return;
      }
      mpInstance.Logger.error("Unable to save MPID data to cookies because the resulting encoded cookie is larger than the maxCookieSize setting of " + maxCookieSize + ". We recommend using a maxCookieSize of 1500.");
    }
    function removeCurrentSessionMpidsByAge(persistence, currentSessionMPIDs, expires, domain, maxCookieSize) {
      var encodedCookiesWithExpirationAndPath;
      for (var i = 0; i < currentSessionMPIDs.length; i++) {
        encodedCookiesWithExpirationAndPath = createFullEncodedCookie(persistence, expires, domain);
        if (!isEncodedCookieTooLarge(encodedCookiesWithExpirationAndPath, maxCookieSize)) {
          break;
        }
        logAndRemoveOversizedMpid(persistence, currentSessionMPIDs[i], maxCookieSize);
      }
      return encodedCookiesWithExpirationAndPath;
    }
    this.reduceAndEncodePersistence = function(persistence, expires, domain, maxCookieSize) {
      var currentSessionMPIDs = persistence.gs.csm ? persistence.gs.csm : [];
      if (!currentSessionMPIDs.length) {
        return removeUnsessionedMpidsWhenOversized(persistence, expires, domain, maxCookieSize);
      }
      var MPIDsOnCookie = collectRemovableMpids(persistence);
      if (Object.keys(MPIDsOnCookie).length) {
        removeMpidsNotInCurrentSession(persistence, MPIDsOnCookie, currentSessionMPIDs, expires, domain, maxCookieSize);
      }
      return removeCurrentSessionMpidsByAge(persistence, currentSessionMPIDs, expires, domain, maxCookieSize);
    };
    function createFullEncodedCookie(persistence, expires, domain) {
      return self.encodePersistence(JSON.stringify(persistence)) + ";expires=" + expires + ";path=/" + domain;
    }
    function cookieUiMatchesRequestedIdentity(cookieUIs, requestedIdentityType, requestedValue) {
      for (var cookieUIType in cookieUIs) {
        if (requestedIdentityType === cookieUIType && requestedValue === cookieUIs[cookieUIType]) {
          return true;
        }
      }
      return false;
    }
    function findMpidForRequestedIdentity(persistence, requestedIdentityType, requestedValue) {
      var matchedUser;
      for (var key in persistence) {
        if (!persistence[key].mpid) {
          continue;
        }
        if (cookieUiMatchesRequestedIdentity(persistence[key].ui, requestedIdentityType, requestedValue)) {
          matchedUser = key;
        }
      }
      return matchedUser;
    }
    function findMpidMatchingIdentities(persistence, identityApiData) {
      var matchedUser;
      for (var requestedIdentityType in identityApiData.userIdentities) {
        if (!persistence || !Object.keys(persistence).length) {
          continue;
        }
        var match = findMpidForRequestedIdentity(persistence, requestedIdentityType, identityApiData.userIdentities[requestedIdentityType]);
        if (match) {
          matchedUser = match;
        }
      }
      return matchedUser;
    }
    this.findPrevCookiesBasedOnUI = function(identityApiData) {
      var persistence = mpInstance._Persistence.getPersistence();
      if (!identityApiData) {
        return;
      }
      var matchedUser = findMpidMatchingIdentities(persistence, identityApiData);
      if (matchedUser) {
        self.storeDataInMemory(persistence, matchedUser);
      }
    };
    function isNonEmptyArrayOrObject(value) {
      if (Array.isArray(value)) {
        return value.length > 0;
      }
      if (!mpInstance._Helpers.isObject(value)) {
        return false;
      }
      return Object.keys(value).length > 0;
    }
    function encodeGsBase64Field(gs, key) {
      if (!gs[key] || !isNonEmptyArrayOrObject(gs[key])) {
        delete gs[key];
        return;
      }
      gs[key] = Base64.encode(JSON.stringify(gs[key]));
    }
    function encodeGlobalSettings(gs) {
      for (var key in gs) {
        if (!gs.hasOwnProperty(key)) {
          continue;
        }
        if (Base64CookieKeys[key]) {
          encodeGsBase64Field(gs, key);
          continue;
        }
        if (key === "ie") {
          gs[key] = gs[key] ? 1 : 0;
          continue;
        }
        if (!gs[key]) {
          delete gs[key];
        }
      }
    }
    function encodeMpidBase64Field(container, key) {
      var value = container[key];
      if (mpInstance._Helpers.isObject(value) && Object.keys(value).length) {
        container[key] = Base64.encode(JSON.stringify(value));
        return;
      }
      delete container[key];
    }
    function encodeMpidRecord(record) {
      for (var key in record) {
        if (!record.hasOwnProperty(key)) {
          continue;
        }
        if (Base64CookieKeys[key]) {
          encodeMpidBase64Field(record, key);
        }
      }
    }
    function encodeMpidRecords(persistence) {
      for (var mpid in persistence) {
        if (!persistence.hasOwnProperty(mpid)) {
          continue;
        }
        if (SDKv2NonMPIDCookieKeys[mpid]) {
          continue;
        }
        encodeMpidRecord(persistence[mpid]);
      }
    }
    this.encodePersistence = function(persistenceString) {
      var persistence = JSON.parse(persistenceString);
      encodeGlobalSettings(persistence.gs);
      encodeMpidRecords(persistence);
      return createCookieString(JSON.stringify(persistence));
    };
    function decodeGlobalSettings(gs) {
      for (var key in gs) {
        if (!gs.hasOwnProperty(key)) {
          continue;
        }
        if (Base64CookieKeys[key]) {
          gs[key] = JSON.parse(Base64.decode(gs[key]));
          continue;
        }
        if (key === "ie") {
          gs[key] = Boolean(gs[key]);
        }
      }
    }
    function decodeMpidRecord(record) {
      for (var key in record) {
        if (!record.hasOwnProperty(key)) {
          continue;
        }
        if (!Base64CookieKeys[key]) {
          continue;
        }
        if (record[key].length) {
          record[key] = JSON.parse(Base64.decode(record[key]));
        }
      }
    }
    function decodeMpidRecords(persistence) {
      for (var mpid in persistence) {
        if (!persistence.hasOwnProperty(mpid)) {
          continue;
        }
        if (!SDKv2NonMPIDCookieKeys[mpid]) {
          decodeMpidRecord(persistence[mpid]);
          continue;
        }
        if (mpid === "l") {
          persistence[mpid] = Boolean(persistence[mpid]);
        }
      }
    }
    this.decodePersistence = function(persistenceString) {
      try {
        if (!persistenceString) {
          return;
        }
        var persistence = JSON.parse(revertCookieString(persistenceString));
        if (mpInstance._Helpers.isObject(persistence) && Object.keys(persistence).length) {
          decodeGlobalSettings(persistence.gs);
          decodeMpidRecords(persistence);
        }
        return JSON.stringify(persistence);
      } catch (e) {
        mpInstance.Logger.error("Problem with decoding cookie");
      }
    };
    this.getCookieDomain = function() {
      if (mpInstance._Store.SDKConfig.cookieDomain) {
        return mpInstance._Store.SDKConfig.cookieDomain;
      } else {
        var rootDomain = self.getDomain(document, location.hostname);
        if (rootDomain === "") {
          return "";
        } else {
          return "." + rootDomain;
        }
      }
    };
    this.getDomain = function(doc, locationHostname) {
      var i, testParts, mpTest = "mptest=cookie", hostname = locationHostname.split(".");
      for (i = hostname.length - 1; i >= 0; i--) {
        testParts = hostname.slice(i).join(".");
        doc.cookie = mpTest + ";domain=." + testParts + ";";
        if (doc.cookie.indexOf(mpTest) > -1) {
          doc.cookie = mpTest.split("=")[0] + "=;domain=." + testParts + ";expires=Thu, 01 Jan 1970 00:00:01 GMT;";
          return testParts;
        }
      }
      return "";
    };
    this.saveUserCookieSyncDatesToPersistence = function(mpid, csd) {
      if (csd) {
        var persistence = self.getPersistence();
        if (persistence) {
          if (persistence[mpid]) {
            persistence[mpid].csd = csd;
          } else {
            persistence[mpid] = {
              csd
            };
          }
        }
        self.savePersistence(persistence);
      }
    };
    this.swapCurrentUser = function(previousMPID, currentMPID, currentSessionMPIDs) {
      if (previousMPID && currentMPID && previousMPID !== currentMPID) {
        var persistence = self.getPersistence();
        if (persistence) {
          persistence.cu = currentMPID;
          persistence.gs.csm = currentSessionMPIDs;
          self.savePersistence(persistence);
        }
      }
    };
    this.savePersistence = function(persistence) {
      var _a2;
      if ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) {
        return;
      }
      var encodedPersistence = self.encodePersistence(JSON.stringify(persistence)), date = /* @__PURE__ */ new Date(), key = mpInstance._Store.storageName, expires = new Date(date.getTime() + mpInstance._Store.SDKConfig.cookieExpiration * 24 * 60 * 60 * 1e3).toUTCString(), cookieDomain = self.getCookieDomain(), domain;
      if (cookieDomain === "") {
        domain = "";
      } else {
        domain = ";domain=" + cookieDomain;
      }
      if (mpInstance._Store.SDKConfig.useCookieStorage) {
        var encodedCookiesWithExpirationAndPath = self.reduceAndEncodePersistence(persistence, expires, domain, mpInstance._Store.SDKConfig.maxCookieSize);
        window.document.cookie = encodeURIComponent(key) + "=" + encodedCookiesWithExpirationAndPath;
      } else {
        if (mpInstance._Store.isLocalStorageAvailable) {
          try {
            localStorage.setItem(mpInstance._Store.storageName, encodedPersistence);
          } catch (e) {
            mpInstance.Logger.error("Error saving persistence to localStorage.");
          }
        }
      }
    };
    this.getPersistence = function() {
      var persistence = this.useLocalStorage() ? this.getLocalStorage() : this.getCookie();
      return persistence;
    };
    this.getFirstSeenTime = function(mpid) {
      if (!mpid) {
        return null;
      }
      var persistence = self.getPersistence();
      if (persistence && persistence[mpid] && persistence[mpid].fst) {
        return persistence[mpid].fst;
      } else {
        return null;
      }
    };
    this.setFirstSeenTime = function(mpid, time) {
      if (!mpid) {
        return;
      }
      if (!time) {
        time = (/* @__PURE__ */ new Date()).getTime();
      }
      var persistence = self.getPersistence();
      if (persistence) {
        if (!persistence[mpid]) {
          persistence[mpid] = {};
        }
        if (!persistence[mpid].fst) {
          persistence[mpid].fst = time;
          self.savePersistence(persistence);
        }
      }
    };
    this.getLastSeenTime = function(mpid) {
      if (!mpid) {
        return null;
      }
      if (mpid === mpInstance.Identity.getCurrentUser().getMPID()) {
        return (/* @__PURE__ */ new Date()).getTime();
      } else {
        var persistence = self.getPersistence();
        if (persistence && persistence[mpid] && persistence[mpid].lst) {
          return persistence[mpid].lst;
        }
        return null;
      }
    };
    this.setLastSeenTime = function(mpid, time) {
      if (!mpid) {
        return;
      }
      if (!time) {
        time = (/* @__PURE__ */ new Date()).getTime();
      }
      var persistence = self.getPersistence();
      if (persistence && persistence[mpid]) {
        persistence[mpid].lst = time;
        self.savePersistence(persistence);
      }
    };
    this.getDeviceId = function() {
      return mpInstance._Store.deviceId;
    };
    this.setDeviceId = function(guid) {
      mpInstance._Store.deviceId = guid;
      self.update();
    };
    this.resetPersistence = function() {
      localStorage.clear();
      self.expireCookies(StorageNames.cookieName);
      self.expireCookies(StorageNames.cookieNameV2);
      self.expireCookies(StorageNames.cookieNameV3);
      self.expireCookies(StorageNames.cookieNameV4);
      self.expireCookies(mpInstance._Store.storageName);
      var mParticleManager2 = getMParticleManager();
      if (mParticleManager2 === null || mParticleManager2 === void 0 ? void 0 : mParticleManager2._isTestEnv) {
        var testWorkspaceToken = "abcdef";
        localStorage.removeItem(mpInstance._Helpers.createMainStorageName(testWorkspaceToken));
        self.expireCookies(mpInstance._Helpers.createMainStorageName(testWorkspaceToken));
      }
    };
    this.forwardingStatsBatches = {
      uploadsTable: {},
      forwardingStatsEventQueue: []
    };
  }
  var HISTORY_METHODS = ["pushState", "replaceState"];
  var WRAPPED_MARKER = "__mpApvWrapped__";
  var WIN_APV_KEY = "__mpApv__";
  var ALLOWED_QUERY_PARAMS = [
    // Campaign attribution
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "utm_id",
    // Ad-network click ids
    "gclid",
    "gbraid",
    "wbraid",
    "fbclid",
    "msclkid",
    "ttclid",
    "twclid",
    "li_fat_id",
    "dclid",
    // OAuth / OIDC — see the SECURITY note above
    "client_id",
    "redirect_uri",
    "response_type",
    "scope",
    "state",
    "code",
    "nonce",
    // Pagination and search
    "page",
    "limit",
    "offset",
    "cursor",
    "per_page",
    "q",
    "search",
    // Referral
    "ref",
    "referrer"
  ];
  var allowedQueryParams = function allowedQueryParams2(href) {
    return queryStringParser(href, ALLOWED_QUERY_PARAMS);
  };
  var capturedNames = function capturedNames2(params) {
    return ALLOWED_QUERY_PARAMS.filter(function(name) {
      return name in params;
    });
  };
  var pageKey = function pageKey2(page) {
    var query = capturedNames(page.params).map(function(name) {
      return "".concat(name, "=").concat(encodeURIComponent(page.params[name]));
    }).join("&");
    return query ? "".concat(page.path, "?").concat(query) : page.path;
  };
  var isNewPage = function isNewPage2(lastKey, candidateKey) {
    return candidateKey !== lastKey;
  };
  var supportsHistoryTracking = function supportsHistoryTracking2(win) {
    return !!win && win.history !== void 0 && typeof win.history.pushState === "function" && typeof win.addEventListener === "function";
  };
  var buildPageViewEvent = function buildPageViewEvent2(_a2) {
    var params = _a2.params, hostname = _a2.hostname, title = _a2.title, path = _a2.path;
    return {
      messageType: MessageType$1.PageView,
      name: "PageView",
      // Params spread first, then the core fields by name, so a core field always
      // wins. No allowlist entry collides with hostname/title/path today; naming
      // them here is what keeps a later addition from silently overwriting one.
      data: __assign(__assign({}, params), {
        hostname,
        title,
        path
      }),
      eventType: EventType.Unknown
    };
  };
  var apvWindow = function apvWindow2() {
    return typeof window === "undefined" ? null : window;
  };
  var freshState = function freshState2() {
    return {
      initialPageViewFired: false
    };
  };
  var readState = function readState2() {
    var win = apvWindow();
    return win ? win[WIN_APV_KEY] : void 0;
  };
  var writeState = function writeState2() {
    var win = apvWindow();
    if (!win) {
      return null;
    }
    if (!win[WIN_APV_KEY]) {
      win[WIN_APV_KEY] = freshState();
    }
    return win[WIN_APV_KEY];
  };
  var getActiveTracker = function getActiveTracker2() {
    var state = readState();
    return state ? state.tracker : void 0;
  };
  var hasInitialPageViewFired = function hasInitialPageViewFired2() {
    var state = readState();
    return !!(state && state.initialPageViewFired);
  };
  var markInitialPageViewFired = function markInitialPageViewFired2() {
    var state = writeState();
    if (state) {
      state.initialPageViewFired = true;
    }
  };
  var resetPageViewTracking = function resetPageViewTracking2() {
    var win = apvWindow();
    if (!win) {
      return;
    }
    var active = getActiveTracker();
    if (active) {
      active.teardown();
    }
    win[WIN_APV_KEY] = freshState();
  };
  var setActiveTracker = function setActiveTracker2(tracker) {
    var state = writeState();
    if (state) {
      state.tracker = tracker;
    }
  };
  var clearActiveTracker = function clearActiveTracker2(tracker) {
    var state = readState();
    if (state && state.tracker === tracker) {
      state.tracker = void 0;
    }
  };
  var currentPage = function currentPage2() {
    return {
      path: window.location.pathname,
      params: allowedQueryParams(getHref())
    };
  };
  var describePage = function describePage2(page) {
    if (!page) {
      return "";
    }
    var names = capturedNames(page.params);
    return names.length ? "".concat(page.path, " (params: ").concat(names.join(), ")") : page.path;
  };
  var patchHistory = function patchHistory2(onNavigate, log) {
    if (window.history.pushState[WRAPPED_MARKER]) {
      log("[patch] history already wrapped, skipping to avoid double-wrap \u2014 STACKED WRAPPER DETECTED");
      return null;
    }
    var originals = {};
    var wrappers = {};
    HISTORY_METHODS.forEach(function(name) {
      var original = window.history[name];
      originals[name] = original;
      var wrapper = function wrapper2() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        var result = original.apply(this, args);
        onNavigate(name);
        return result;
      };
      Object.defineProperty(wrapper, WRAPPED_MARKER, {
        value: true,
        enumerable: false
      });
      wrappers[name] = wrapper;
    });
    var restore = function restore2() {
      return HISTORY_METHODS.forEach(function(name) {
        if (window.history[name] === wrappers[name]) {
          window.history[name] = originals[name];
          log("[teardown] restored original ".concat(name));
        } else {
          log("[teardown] ".concat(name, " no longer ours; leaving in place, gating callback to no-op"));
        }
      });
    };
    try {
      HISTORY_METHODS.forEach(function(name) {
        window.history[name] = wrappers[name];
      });
    } catch (e) {
      log("[error] failed to patch history methods (frozen/sealed), rolling back: ".concat(e));
      try {
        restore();
      } catch (restoreError) {
        log("[error] failed to restore history methods after patch failure: ".concat(restoreError));
      }
      return null;
    }
    return restore;
  };
  var PageViewTracker = (
    /** @class */
    (function() {
      function PageViewTracker2(mpInstance) {
        this.lastPage = null;
        this.active = false;
        this.pendingNavigations = [];
        this.undoHistoryPatch = null;
        this.popStateListener = null;
        this.mpInstance = mpInstance;
      }
      Object.defineProperty(PageViewTracker2.prototype, "isActive", {
        // True while this tracker owns the history patch and is listening for
        // navigations. Flips to false on teardown, including the teardown a
        // successor tracker performs during a handoff. Read-only, and the one thing
        // worth checking on `window.__mpApv__.tracker` from a console.
        get: function get() {
          return this.active;
        },
        enumerable: false,
        configurable: true
      });
      PageViewTracker2.prototype.init = function() {
        var _this = this;
        this.log("[init] PageViewTracker Init");
        if (!supportsHistoryTracking(apvWindow())) {
          this.log("[init] unsupported environment (no History API), not starting");
          return;
        }
        var active = getActiveTracker();
        var inheritedPages = this.retire(active);
        if (this.active && active !== this) {
          inheritedPages = inheritedPages.concat(this.retire(this));
        }
        this.active = true;
        this.lastPage = currentPage();
        this.log("[init] seeded lastPage: ".concat(describePage(this.lastPage)));
        this.undoHistoryPatch = patchHistory(function(source) {
          return _this.safeHandleNavigation(source);
        }, function(message) {
          return _this.log(message);
        });
        this.popStateListener = function() {
          return _this.safeHandleNavigation("popstate");
        };
        window.addEventListener("popstate", this.popStateListener);
        setActiveTracker(this);
        this.log("[init] patched pushState/replaceState + listening for popstate");
        inheritedPages.forEach(function(page) {
          return _this.scheduleFire(page);
        });
      };
      PageViewTracker2.prototype.teardown = function() {
        this.takePendingNavigations();
        if (this.popStateListener) {
          window.removeEventListener("popstate", this.popStateListener);
          this.popStateListener = null;
        }
        if (this.undoHistoryPatch) {
          this.undoHistoryPatch();
          this.undoHistoryPatch = null;
        }
        this.active = false;
        clearActiveTracker(this);
      };
      PageViewTracker2.prototype.retire = function(outgoing) {
        if (!outgoing) {
          return [];
        }
        this.log(outgoing === this ? "[init] retiring this tracker for a repeat mParticle.init() \u2014 transferring pending navigations and tearing down" : "[init] retiring a tracker from a previous module load \u2014 transferring pending navigations and tearing down");
        var pages = outgoing.takePendingNavigations();
        outgoing.teardown();
        return pages;
      };
      PageViewTracker2.prototype.takePendingNavigations = function() {
        var pending = this.pendingNavigations;
        this.pendingNavigations = [];
        pending.forEach(function(_a2) {
          var timeoutId = _a2.timeoutId;
          return clearTimeout(timeoutId);
        });
        return pending.map(function(_a2) {
          var page = _a2.page;
          return page;
        });
      };
      PageViewTracker2.prototype.safeHandleNavigation = function(source) {
        if (!this.active) {
          return;
        }
        try {
          this.handleNavigation(source);
        } catch (e) {
          this.log("[error] navigation handler threw (".concat(source, "), page view skipped: ").concat(e));
        }
      };
      PageViewTracker2.prototype.handleNavigation = function(source) {
        var candidate = currentPage();
        var lastKey = this.lastPage ? pageKey(this.lastPage) : null;
        this.log("[detect] navigation signal (source: ".concat(source, ", candidate: ").concat(describePage(candidate), ", last: ").concat(describePage(this.lastPage), ")"));
        if (!isNewPage(lastKey, pageKey(candidate))) {
          this.log("[dedupe] page unchanged, skipping (source: ".concat(source, ", page: ").concat(describePage(candidate), ")"));
          return;
        }
        this.log("[accept] page changed, scheduling fire (source: ".concat(source, ", from: ").concat(describePage(this.lastPage), ", to: ").concat(describePage(candidate), ")"));
        this.lastPage = candidate;
        this.scheduleFire(candidate);
      };
      PageViewTracker2.prototype.scheduleFire = function(page) {
        var _this = this;
        var timeoutId = setTimeout(function() {
          _this.pendingNavigations = _this.pendingNavigations.filter(function(p) {
            return p.timeoutId !== timeoutId;
          });
          if (!_this.active) {
            _this.log("[defer] fire aborted, tracker inactive (torn down before flush)");
            return;
          }
          _this.mpInstance._SessionManager.resetSessionTimer();
          _this.firePageView(page);
        }, 0);
        this.pendingNavigations.push({
          page,
          timeoutId
        });
      };
      PageViewTracker2.prototype.firePageView = function(page) {
        var title = window.document.title;
        var event = buildPageViewEvent(__assign(__assign({}, page), {
          hostname: window.location.hostname,
          title
        }));
        this.log("[fire] deferred flush -> _Events.logEvent(PageView) (page: ".concat(describePage(page), ", title: ").concat(title, ")"));
        this.mpInstance._Events.logEvent(event);
      };
      PageViewTracker2.prototype.log = function(message) {
        this.mpInstance.Logger.verbose("mParticle APV: ".concat(message));
      };
      return PageViewTracker2;
    })()
  );
  var Messages$3 = Constants.Messages;
  function Events(mpInstance) {
    var self = this;
    this.logEvent = function(event, options) {
      mpInstance.Logger.verbose(Messages$3.InformationMessages.StartingLogEvent + ": " + event.name);
      if (mpInstance._Helpers.canLog()) {
        var uploadObject = mpInstance._ServerModel.createEventObject(event);
        mpInstance._APIClient.sendEventToServer(uploadObject, options);
      } else {
        mpInstance.Logger.verbose(Messages$3.InformationMessages.AbandonLogEvent);
      }
    };
    this.startTracking = function(callback) {
      if (!mpInstance._Store.isTracking) {
        if ("geolocation" in navigator) {
          mpInstance._Store.watchPositionId = navigator.geolocation.watchPosition(successTracking, errorTracking);
        }
      } else {
        var position = {
          coords: {
            latitude: mpInstance._Store.currentPosition.lat,
            longitude: mpInstance._Store.currentPosition.lng
          }
        };
        triggerCallback(callback, position);
      }
      function successTracking(position2) {
        mpInstance._Store.currentPosition = {
          lat: position2.coords.latitude,
          lng: position2.coords.longitude
        };
        triggerCallback(callback, position2);
        callback = null;
        mpInstance._Store.isTracking = true;
      }
      function errorTracking() {
        triggerCallback(callback);
        callback = null;
        mpInstance._Store.isTracking = false;
      }
      function triggerCallback(callback2, position2) {
        if (callback2) {
          try {
            if (position2) {
              callback2(position2);
            } else {
              callback2();
            }
          } catch (e) {
            mpInstance.Logger.error("Error invoking the callback passed to startTrackingLocation.");
            mpInstance.Logger.error(e);
          }
        }
      }
    };
    this.stopTracking = function() {
      if (mpInstance._Store.isTracking) {
        navigator.geolocation.clearWatch(mpInstance._Store.watchPositionId);
        mpInstance._Store.currentPosition = null;
        mpInstance._Store.isTracking = false;
      }
    };
    this.logOptOut = function() {
      mpInstance.Logger.verbose(Messages$3.InformationMessages.StartingLogOptOut);
      var event = mpInstance._ServerModel.createEventObject({
        messageType: Types.MessageType.OptOut,
        eventType: Types.EventType.Other
      });
      mpInstance._APIClient.sendEventToServer(event);
    };
    this.logAST = function() {
      self.logEvent({
        messageType: Types.MessageType.AppStateTransition
      });
    };
    this.logPageView = function() {
      self.logEvent({
        messageType: Types.MessageType.PageView,
        name: "PageView",
        data: __assign(__assign({}, allowedQueryParams(getHref())), {
          hostname: window.location.hostname,
          title: window.document.title
        }),
        eventType: Types.EventType.Unknown
      });
    };
    this.logCheckoutEvent = function(step, option, attrs, customFlags) {
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags);
      if (event) {
        event.EventName += mpInstance._Ecommerce.getProductActionEventName(Types.ProductActionType.Checkout);
        event.EventCategory = Types.CommerceEventType.ProductCheckout;
        event.ProductAction = {
          ProductActionType: Types.ProductActionType.Checkout,
          CheckoutStep: step,
          CheckoutOptions: option,
          ProductList: []
        };
        self.logCommerceEvent(event, attrs);
      }
    };
    this.logProductActionEvent = function(productActionType, product, customAttrs, customFlags, transactionAttributes, options) {
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags, options);
      var productList = Array.isArray(product) ? product : [product];
      productList.forEach(function(product2) {
        if (product2.TotalAmount) {
          product2.TotalAmount = mpInstance._Ecommerce.sanitizeAmount(product2.TotalAmount, "TotalAmount");
        }
        if (product2.Position) {
          product2.Position = mpInstance._Ecommerce.sanitizeAmount(product2.Position, "Position");
        }
        if (product2.Price) {
          product2.Price = mpInstance._Ecommerce.sanitizeAmount(product2.Price, "Price");
        }
        if (product2.Quantity) {
          product2.Quantity = mpInstance._Ecommerce.sanitizeAmount(product2.Quantity, "Quantity");
        }
      });
      if (event) {
        event.EventCategory = mpInstance._Ecommerce.convertProductActionToEventType(productActionType);
        event.EventName += mpInstance._Ecommerce.getProductActionEventName(productActionType);
        event.ProductAction = {
          ProductActionType: productActionType,
          ProductList: productList
        };
        if (Types.ProductActionType.isRoktCommerceType(productActionType)) {
          event.CustomFlags = event.CustomFlags || {};
          event.CustomFlags["Rokt.CommerceEventType"] = Types.ProductActionType.getExpansionName(productActionType);
        }
        if (mpInstance._Helpers.isObject(transactionAttributes)) {
          mpInstance._Ecommerce.convertTransactionAttributesToProductAction(transactionAttributes, event.ProductAction);
        }
        self.logCommerceEvent(event, customAttrs, options);
      }
    };
    this.logPurchaseEvent = function(transactionAttributes, product, attrs, customFlags) {
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags);
      if (event) {
        event.EventName += mpInstance._Ecommerce.getProductActionEventName(Types.ProductActionType.Purchase);
        event.EventCategory = Types.CommerceEventType.ProductPurchase;
        event.ProductAction = {
          ProductActionType: Types.ProductActionType.Purchase
        };
        event.ProductAction.ProductList = mpInstance._Ecommerce.buildProductList(event, product);
        mpInstance._Ecommerce.convertTransactionAttributesToProductAction(transactionAttributes, event.ProductAction);
        self.logCommerceEvent(event, attrs);
      }
    };
    this.logRefundEvent = function(transactionAttributes, product, attrs, customFlags) {
      if (!transactionAttributes) {
        mpInstance.Logger.error(Messages$3.ErrorMessages.TransactionRequired);
        return;
      }
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags);
      if (event) {
        event.EventName += mpInstance._Ecommerce.getProductActionEventName(Types.ProductActionType.Refund);
        event.EventCategory = Types.CommerceEventType.ProductRefund;
        event.ProductAction = {
          ProductActionType: Types.ProductActionType.Refund
        };
        event.ProductAction.ProductList = mpInstance._Ecommerce.buildProductList(event, product);
        mpInstance._Ecommerce.convertTransactionAttributesToProductAction(transactionAttributes, event.ProductAction);
        self.logCommerceEvent(event, attrs);
      }
    };
    this.logPromotionEvent = function(promotionType, promotion, attrs, customFlags, eventOptions) {
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags);
      if (event) {
        event.EventName += mpInstance._Ecommerce.getPromotionActionEventName(promotionType);
        event.EventCategory = mpInstance._Ecommerce.convertPromotionActionToEventType(promotionType);
        event.PromotionAction = {
          PromotionActionType: promotionType,
          PromotionList: Array.isArray(promotion) ? promotion : [promotion]
        };
        self.logCommerceEvent(event, attrs, eventOptions);
      }
    };
    this.logImpressionEvent = function(impression, attrs, customFlags, options) {
      var event = mpInstance._Ecommerce.createCommerceEventObject(customFlags);
      if (event) {
        event.EventName += "Impression";
        event.EventCategory = Types.CommerceEventType.ProductImpression;
        if (!Array.isArray(impression)) {
          impression = [impression];
        }
        event.ProductImpressions = [];
        impression.forEach(function(impression2) {
          event.ProductImpressions.push({
            ProductImpressionList: impression2.Name,
            ProductList: Array.isArray(impression2.Product) ? impression2.Product : [impression2.Product]
          });
        });
        self.logCommerceEvent(event, attrs, options);
      }
    };
    this.logCommerceEvent = function(commerceEvent, attrs, options) {
      mpInstance.Logger.verbose(Messages$3.InformationMessages.StartingLogCommerceEvent);
      if (commerceEvent.ProductAction && commerceEvent.EventCategory === null) {
        mpInstance.Logger.error("Commerce event not sent.  The mParticle.ProductActionType you passed was invalid. Re-check your code.");
        return;
      }
      var sanitizedAttrs = mpInstance._Helpers.sanitizeAttributes(attrs, commerceEvent.EventName);
      if (mpInstance._Helpers.canLog()) {
        if (mpInstance._Store.webviewBridgeEnabled) {
          commerceEvent.ShoppingCart = {};
        }
        if (sanitizedAttrs) {
          commerceEvent.EventAttributes = sanitizedAttrs;
        }
        if (commerceEvent.ProductAction) {
          mpInstance._Ecommerce.calculateProductActionTotalAmount(commerceEvent.ProductAction);
        }
        mpInstance._APIClient.sendEventToServer(commerceEvent, options);
        mpInstance._Persistence.update();
      } else {
        mpInstance.Logger.verbose(Messages$3.InformationMessages.AbandonLogEvent);
      }
    };
    this.addEventHandler = function(domEvent, selector, eventName, data, eventType) {
      var elements = [], handler = function handler2(e) {
        var timeoutHandler = function timeoutHandler2() {
          if (element.href) {
            window.location.href = element.href;
          } else if (element.submit) {
            element.submit();
          }
        };
        mpInstance.Logger.verbose("DOM event triggered, handling event");
        self.logEvent({
          messageType: Types.MessageType.PageEvent,
          name: typeof eventName === "function" ? eventName(element) : eventName,
          data: typeof data === "function" ? data(element) : data,
          eventType: eventType || Types.EventType.Other
        });
        if (element.href && element.target !== "_blank" || element.submit) {
          if (e.preventDefault) {
            e.preventDefault();
          } else {
            e.returnValue = false;
          }
          setTimeout(timeoutHandler, mpInstance._Store.SDKConfig.timeout);
        }
      }, element, i;
      if (!selector) {
        mpInstance.Logger.error("Can't bind event, selector is required");
        return;
      }
      if (typeof selector === "string") {
        elements = document.querySelectorAll(selector);
      } else if (selector.nodeType) {
        elements = [selector];
      }
      if (elements.length) {
        mpInstance.Logger.verbose("Found " + elements.length + " element" + (elements.length > 1 ? "s" : "") + ", attaching event handlers");
        for (i = 0; i < elements.length; i++) {
          element = elements[i];
          if (element.addEventListener) {
            element.addEventListener(domEvent, handler, false);
          } else if (element.attachEvent) {
            element.attachEvent("on" + domEvent, handler);
          } else {
            element["on" + domEvent] = handler;
          }
        }
      } else {
        mpInstance.Logger.verbose("No elements found");
      }
    };
  }
  function isAttributeKeyAllowed(kitBlocker, key) {
    return !(kitBlocker === null || kitBlocker === void 0 ? void 0 : kitBlocker.isAttributeKeyBlocked(key));
  }
  function isIdentityAllowed(kitBlocker, identityName) {
    return !(kitBlocker === null || kitBlocker === void 0 ? void 0 : kitBlocker.isIdentityBlocked(identityName));
  }
  function copyUserAttributeValue(value) {
    return Array.isArray(value) ? value.slice() : value;
  }
  function buildUserAttributesCopy(userAttributes, kitBlocker) {
    var userAttributesCopy = {};
    if (!userAttributes) {
      return userAttributesCopy;
    }
    for (var prop in userAttributes) {
      if (!userAttributes.hasOwnProperty(prop) || !isAttributeKeyAllowed(kitBlocker, prop)) {
        continue;
      }
      userAttributesCopy[prop] = copyUserAttributeValue(userAttributes[prop]);
    }
    return userAttributesCopy;
  }
  function buildUserAttributeLists(userAttributes, kitBlocker) {
    var userAttributesLists = {};
    for (var key in userAttributes) {
      if (!userAttributes.hasOwnProperty(key) || !Array.isArray(userAttributes[key]) || !isAttributeKeyAllowed(kitBlocker, key)) {
        continue;
      }
      userAttributesLists[key] = userAttributes[key].slice();
    }
    return userAttributesLists;
  }
  function buildFilteredUserIdentities(identities, kitBlocker, parseNumber2) {
    var currentUserIdentities = {};
    var identitiesByType = identities;
    for (var identityType in identitiesByType) {
      if (!identitiesByType.hasOwnProperty(identityType)) {
        continue;
      }
      var identityName = Types.IdentityType.getIdentityName(parseNumber2(identityType));
      if (!isIdentityAllowed(kitBlocker, identityName)) {
        continue;
      }
      currentUserIdentities[identityName] = identitiesByType[identityType];
    }
    return currentUserIdentities;
  }
  function filteredMparticleUser(mpid, forwarder, mpInstance, kitBlocker) {
    function getAllUserAttributes() {
      var userAttributesCopy = buildUserAttributesCopy(mpInstance._Store.getUserAttributes(mpid), kitBlocker);
      return mpInstance._Helpers.filterUserAttributes(userAttributesCopy, forwarder.userAttributeFilters);
    }
    return {
      getUserIdentities: function getUserIdentities() {
        var currentUserIdentities = buildFilteredUserIdentities(mpInstance._Store.getUserIdentities(mpid), kitBlocker, mpInstance._Helpers.parseNumber);
        currentUserIdentities = mpInstance._Helpers.filterUserIdentitiesForForwarders(currentUserIdentities, forwarder.userIdentityFilters);
        return {
          userIdentities: currentUserIdentities
        };
      },
      getMPID: function getMPID() {
        return mpid;
      },
      getUserAttributesLists: function getUserAttributesLists(forwarder2) {
        var userAttributesLists = buildUserAttributeLists(getAllUserAttributes(), kitBlocker);
        return mpInstance._Helpers.filterUserAttributes(userAttributesLists, forwarder2.userAttributeFilters);
      },
      getAllUserAttributes
    };
  }
  var FORWARDING_RULE_MESSAGE_TYPES = [Types.MessageType.PageEvent, Types.MessageType.PageView, Types.MessageType.Commerce];
  function inFilteredList(filterList, hash) {
    if (filterList && filterList.length) {
      return inArray(filterList, hash);
    }
    return false;
  }
  function isBlockedByForwardingRule(messageType, attributes, forwarder) {
    if (!FORWARDING_RULE_MESSAGE_TYPES.includes(messageType) || !forwarder.filteringEventAttributeValue || !forwarder.filteringEventAttributeValue.eventAttributeName || !forwarder.filteringEventAttributeValue.eventAttributeValue) {
      return false;
    }
    var foundProp = null;
    if (attributes) {
      for (var prop in attributes) {
        if (attributes.hasOwnProperty(prop)) {
          var hashedName = KitFilterHelper.hashAttributeConditionalForwarding(prop);
          if (hashedName === forwarder.filteringEventAttributeValue.eventAttributeName) {
            foundProp = {
              name: hashedName,
              value: KitFilterHelper.hashAttributeConditionalForwarding(attributes[prop])
            };
            break;
          }
        }
      }
    }
    var isMatch = foundProp !== null && foundProp.value === forwarder.filteringEventAttributeValue.eventAttributeValue;
    var shouldInclude = forwarder.filteringEventAttributeValue.includeOnMatch === true ? isMatch : !isMatch;
    return !shouldInclude;
  }
  function isBlockedByEventFilter(messageType, hashedEventName, hashedEventType, forwarder) {
    if (messageType === Types.MessageType.PageEvent && (inFilteredList(forwarder.eventNameFilters, hashedEventName) || inFilteredList(forwarder.eventTypeFilters, hashedEventType))) {
      return true;
    } else if (messageType === Types.MessageType.Commerce && inFilteredList(forwarder.eventTypeFilters, hashedEventType)) {
      return true;
    } else if (messageType === Types.MessageType.PageView && inFilteredList(forwarder.screenNameFilters, hashedEventName)) {
      return true;
    }
    return false;
  }
  function filterEventAttributes(messageType, eventCategory, eventName, attributes, forwarder) {
    if (!attributes) {
      return attributes;
    }
    var filterList;
    if (messageType === Types.MessageType.PageEvent) {
      filterList = forwarder.attributeFilters;
    } else if (messageType === Types.MessageType.PageView) {
      filterList = forwarder.screenAttributeFilters;
    }
    if (!filterList) {
      return attributes;
    }
    var filtered = {};
    for (var attrName in attributes) {
      if (attributes.hasOwnProperty(attrName)) {
        var hash = KitFilterHelper.hashEventAttributeKey(eventCategory, eventName, attrName);
        if (!inArray(filterList, hash)) {
          filtered[attrName] = attributes[attrName];
        }
      }
    }
    return filtered;
  }
  function filterUserIdentities(userIdentities, filterList) {
    if (!userIdentities || !userIdentities.length) {
      return userIdentities || [];
    }
    return userIdentities.filter(function(userIdentity) {
      return !inArray(filterList, KitFilterHelper.hashUserIdentity(userIdentity.Type));
    });
  }
  var _a;
  var _b = Constants.IdentityMethods, Modify$2 = _b.Modify, Identify$1 = _b.Identify, Login$1 = _b.Login, Logout$1 = _b.Logout;
  var identityCompleteKitMethods = (_a = {}, _a[Identify$1] = "onIdentifyComplete", _a[Login$1] = "onLoginComplete", _a[Logout$1] = "onLogoutComplete", _a[Modify$2] = "onModifyComplete", _a);
  function userAttributesMatchFilter(userAttributes, filterObject) {
    for (var attrName in userAttributes) {
      if (!userAttributes.hasOwnProperty(attrName)) {
        continue;
      }
      var attrHash = KitFilterHelper.hashAttributeConditionalForwarding(attrName);
      var valueHash = KitFilterHelper.hashAttributeConditionalForwarding(userAttributes[attrName]);
      if (attrHash === filterObject.userAttributeName && valueHash === filterObject.userAttributeValue) {
        return true;
      }
    }
    return false;
  }
  function Forwarders(mpInstance, kitBlocker) {
    var _this = this;
    var self = this;
    this.forwarderStatsUploader = new APIClient(mpInstance, kitBlocker).initializeForwarderStatsUploader();
    var UserAttributeActionTypes = {
      setUserAttribute: "setUserAttribute",
      removeUserAttribute: "removeUserAttribute"
    };
    this.initForwarders = function(userIdentities, forwardingStatsCallback) {
      var user = mpInstance.Identity.getCurrentUser();
      if (!mpInstance._Store.webviewBridgeEnabled && mpInstance._Store.configuredForwarders) {
        mpInstance._Store.configuredForwarders.sort(function(x, y) {
          x.settings.PriorityValue = x.settings.PriorityValue || 0;
          y.settings.PriorityValue = y.settings.PriorityValue || 0;
          return -1 * (x.settings.PriorityValue - y.settings.PriorityValue);
        });
        mpInstance._Store.activeForwarders = mpInstance._Store.configuredForwarders.filter(function(forwarder) {
          if (!mpInstance._Consent.isEnabledForUserConsent(forwarder.filteringConsentRuleValues, user)) {
            return false;
          }
          if (!self.isEnabledForUserAttributes(forwarder.filteringUserAttributeValue, user)) {
            return false;
          }
          if (!self.isEnabledForUnknownUser(forwarder.excludeAnonymousUser, user)) {
            return false;
          }
          var filteredUserIdentities = mpInstance._Helpers.filterUserIdentities(userIdentities, forwarder.userIdentityFilters);
          var filteredUserAttributes = KitFilterHelper.filterUserAttributes(user ? user.getAllUserAttributes() : {}, forwarder.userAttributeFilters);
          if (!forwarder.initialized) {
            forwarder.logger = mpInstance.Logger;
            forwarder.init(forwarder.settings, forwardingStatsCallback, false, null, filteredUserAttributes, filteredUserIdentities, mpInstance._Store.SDKConfig.appVersion, mpInstance._Store.SDKConfig.appName, mpInstance._Store.SDKConfig.customFlags, mpInstance._Store.clientId);
            forwarder.initialized = true;
          }
          return true;
        });
      }
    };
    this.isEnabledForUserAttributes = function(filterObject, user) {
      if (!filterObject || !mpInstance._Helpers.isObject(filterObject) || !Object.keys(filterObject).length) {
        return true;
      }
      if (!user) {
        return false;
      }
      var userAttributes = user.getAllUserAttributes();
      try {
        var hasUserAttributes = userAttributes && mpInstance._Helpers.isObject(userAttributes) && Object.keys(userAttributes).length > 0;
        var isMatch = hasUserAttributes ? userAttributesMatchFilter(userAttributes, filterObject) : false;
        return filterObject.includeOnMatch === isMatch;
      } catch (e) {
        return true;
      }
    };
    this.isEnabledForUnknownUser = function(excludeAnonymousUserBoolean, user) {
      if (!user || !user.isLoggedIn()) {
        if (excludeAnonymousUserBoolean) {
          return false;
        }
      }
      return true;
    };
    this.applyToForwarders = function(functionName, functionArgs) {
      if (mpInstance._Store.activeForwarders.length) {
        mpInstance._Store.activeForwarders.forEach(function(forwarder) {
          var forwarderFunction = forwarder[functionName];
          if (forwarderFunction) {
            try {
              var result = forwarder[functionName](functionArgs);
              if (result) {
                mpInstance.Logger.verbose(result);
              }
            } catch (e) {
              mpInstance.Logger.verbose(e);
            }
          }
        });
      }
    };
    this.sendEventToForwarders = function(event) {
      if (mpInstance._Store.webviewBridgeEnabled || !mpInstance._Store.activeForwarders) {
        return;
      }
      var hashedEventName = KitFilterHelper.hashEventName(event.EventName, event.EventCategory);
      var hashedEventType = KitFilterHelper.hashEventType(event.EventCategory);
      var forwardEvent = function forwardEvent2(forwarder) {
        if (isBlockedByForwardingRule(event.EventDataType, event.EventAttributes, forwarder)) {
          return;
        }
        var clonedEvent = extend(true, {}, event);
        if (isBlockedByEventFilter(event.EventDataType, hashedEventName, hashedEventType, forwarder)) {
          return;
        }
        clonedEvent.EventAttributes = filterEventAttributes(event.EventDataType, event.EventCategory, event.EventName, clonedEvent.EventAttributes, forwarder);
        clonedEvent.UserIdentities = filterUserIdentities(clonedEvent.UserIdentities, forwarder.userIdentityFilters);
        clonedEvent.UserAttributes = KitFilterHelper.filterUserAttributes(clonedEvent.UserAttributes, forwarder.userAttributeFilters);
        if (!forwarder.process) {
          return;
        }
        mpInstance.Logger.verbose("Sending message to forwarder: " + forwarder.name);
        var result = forwarder.process(clonedEvent);
        if (result) {
          mpInstance.Logger.verbose(result);
        }
      };
      mpInstance._Store.activeForwarders.forEach(function(forwarder) {
        forwardEvent(forwarder);
      });
    };
    this.handleForwarderUserAttributes = function(functionNameKey, key, value) {
      if (kitBlocker && kitBlocker.isAttributeKeyBlocked(key) || !mpInstance._Store.activeForwarders.length) {
        return;
      }
      mpInstance._Store.activeForwarders.forEach(function(forwarder) {
        var forwarderFunction = forwarder[functionNameKey];
        if (!forwarderFunction || KitFilterHelper.isFilteredUserAttribute(key, forwarder.userAttributeFilters)) {
          return;
        }
        try {
          var result = void 0;
          if (functionNameKey === UserAttributeActionTypes.setUserAttribute) {
            result = forwarder.setUserAttribute(key, value);
          } else if (functionNameKey === UserAttributeActionTypes.removeUserAttribute) {
            result = forwarder.removeUserAttribute(key);
          }
          if (result) {
            mpInstance.Logger.verbose(result);
          }
        } catch (e) {
          mpInstance.Logger.error(e);
        }
      });
    };
    this.setForwarderUserIdentities = function(userIdentities) {
      mpInstance._Store.activeForwarders.forEach(function(forwarder) {
        var filteredUserIdentities = mpInstance._Helpers.filterUserIdentities(userIdentities, forwarder.userIdentityFilters);
        if (forwarder.setUserIdentity) {
          filteredUserIdentities.forEach(function(identity) {
            var result = forwarder.setUserIdentity(identity.Identity, identity.Type);
            if (result) {
              mpInstance.Logger.verbose(result);
            }
          });
        }
      });
    };
    this.setForwarderOnUserIdentified = function(user) {
      mpInstance._Store.activeForwarders.forEach(function(forwarder) {
        var filteredUser = filteredMparticleUser(user.getMPID(), forwarder, mpInstance, kitBlocker);
        if (forwarder.onUserIdentified) {
          var result = forwarder.onUserIdentified(filteredUser);
          if (result) {
            mpInstance.Logger.verbose(result);
          }
        }
      });
    };
    this.setForwarderOnIdentityComplete = function(user, identityMethod) {
      var kitMethodName = identityCompleteKitMethods[identityMethod];
      if (!kitMethodName) {
        return;
      }
      mpInstance._Store.activeForwarders.forEach(function(forwarder) {
        var onIdentityComplete = forwarder[kitMethodName];
        if (!onIdentityComplete) {
          return;
        }
        var filteredUser = filteredMparticleUser(user.getMPID(), forwarder, mpInstance, kitBlocker);
        var result = onIdentityComplete.call(forwarder, filteredUser, filteredUser.getUserIdentities());
        if (result) {
          mpInstance.Logger.verbose(result);
        }
      });
    };
    this.getForwarderStatsQueue = function() {
      return mpInstance._Persistence.forwardingStatsBatches.forwardingStatsEventQueue;
    };
    this.setForwarderStatsQueue = function(queue) {
      mpInstance._Persistence.forwardingStatsBatches.forwardingStatsEventQueue = queue;
    };
    this.processForwarders = function(config, forwardingStatsCallback) {
      if (!config) {
        mpInstance.Logger.warning("No config was passed. Cannot process forwarders");
      } else {
        this.processUIEnabledKits(config);
        this.processSideloadedKits(config);
        self.initForwarders(mpInstance._Store.SDKConfig.identifyRequest.userIdentities, forwardingStatsCallback);
      }
    };
    this.processUIEnabledKits = function(config) {
      var kits = this.returnKitConstructors();
      try {
        if (Array.isArray(config.kitConfigs) && config.kitConfigs.length) {
          config.kitConfigs.forEach(function(kitConfig) {
            self.configureUIEnabledKit(kitConfig, kits);
          });
        }
      } catch (e) {
        mpInstance.Logger.error("MP Kits not configured propertly. Kits may not be initialized. " + e);
      }
    };
    this.returnKitConstructors = function() {
      var kits = {};
      if (!isEmpty(mpInstance._Store.SDKConfig.kits)) {
        kits = mpInstance._Store.SDKConfig.kits;
      } else if (!isEmpty(mpInstance._preInit.forwarderConstructors)) {
        mpInstance._preInit.forwarderConstructors.forEach(function(kitConstructor) {
          if (kitConstructor.suffix) {
            var kitNameWithConstructorSuffix = "".concat(kitConstructor.name, "-").concat(kitConstructor.suffix);
            kits[kitNameWithConstructorSuffix] = kitConstructor;
          } else {
            kits[kitConstructor.name] = kitConstructor;
          }
        });
      }
      return kits;
    };
    this.configureUIEnabledKit = function(configuration, kits) {
      var newKit = null;
      var config = configuration;
      for (var name_1 in kits) {
        var kitNameWithConfigSuffix = void 0;
        if (config.suffix) {
          kitNameWithConfigSuffix = "".concat(config.name, "-").concat(config.suffix);
        }
        if (name_1 === kitNameWithConfigSuffix || name_1 === config.name) {
          if (config.isDebug === mpInstance._Store.SDKConfig.isDevelopmentMode || config.isSandbox === mpInstance._Store.SDKConfig.isDevelopmentMode) {
            newKit = this.returnConfiguredKit(kits[name_1], config);
            mpInstance._Store.configuredForwarders.push(newKit);
            break;
          }
        }
      }
    };
    this.processSideloadedKits = function(mpConfig) {
      try {
        if (Array.isArray(mpConfig.sideloadedKits)) {
          var registeredSideloadedKits_1 = {
            kits: {}
          };
          var unregisteredSideloadedKits = mpConfig.sideloadedKits;
          unregisteredSideloadedKits.forEach(function(unregisteredKit) {
            try {
              unregisteredKit.kitInstance.register(registeredSideloadedKits_1);
              var kitName = unregisteredKit.kitInstance.name;
              registeredSideloadedKits_1.kits[kitName].filters = unregisteredKit.filterDictionary;
            } catch (e) {
              console.error("Error registering sideloaded kit " + unregisteredKit.kitInstance.name);
            }
          });
          for (var registeredKitKey in registeredSideloadedKits_1.kits) {
            var registeredKit = registeredSideloadedKits_1.kits[registeredKitKey];
            self.configureSideloadedKit(registeredKit);
          }
          if (!isEmpty(registeredSideloadedKits_1.kits)) {
            var kitKeys = Object.keys(registeredSideloadedKits_1.kits);
            mpInstance._Store.sideloadedKitsCount = kitKeys.length;
          }
        }
      } catch (e) {
        mpInstance.Logger.error("Sideloaded Kits not configured propertly. Kits may not be initialized. " + e);
      }
    };
    this.configureSideloadedKit = function(kitConstructor) {
      mpInstance._Store.configuredForwarders.push(this.returnConfiguredKit(kitConstructor, kitConstructor.filters));
    };
    this.returnConfiguredKit = function(forwarder, config) {
      if (config === void 0) {
        config = {};
      }
      var newForwarder = new forwarder.constructor();
      newForwarder.id = config.moduleId;
      newForwarder.isSandbox = config.isDebug || config.isSandbox;
      newForwarder.hasSandbox = config.hasDebugString === "true";
      newForwarder.isVisible = config.isVisible || true;
      newForwarder.settings = config.settings || {};
      newForwarder.eventNameFilters = config.eventNameFilters || [];
      newForwarder.eventTypeFilters = config.eventTypeFilters || [];
      newForwarder.attributeFilters = config.attributeFilters || [];
      newForwarder.screenNameFilters = config.screenNameFilters || [];
      newForwarder.screenAttributeFilters = config.screenAttributeFilters || [];
      newForwarder.userIdentityFilters = config.userIdentityFilters || [];
      newForwarder.userAttributeFilters = config.userAttributeFilters || [];
      newForwarder.filteringEventAttributeValue = config.filteringEventAttributeValue || {};
      newForwarder.filteringUserAttributeValue = config.filteringUserAttributeValue || {};
      newForwarder.eventSubscriptionId = config.eventSubscriptionId || null;
      newForwarder.filteringConsentRuleValues = config.filteringConsentRuleValues || {};
      newForwarder.excludeAnonymousUser = config.excludeAnonymousUser || false;
      return newForwarder;
    };
    this.configurePixel = function(settings) {
      if (settings.isDebug === mpInstance._Store.SDKConfig.isDevelopmentMode || settings.isProduction !== mpInstance._Store.SDKConfig.isDevelopmentMode) {
        mpInstance._Store.pixelConfigurations.push(settings);
      }
    };
    this.processPixelConfigs = function(config) {
      try {
        if (!isEmpty(config.pixelConfigs)) {
          config.pixelConfigs.forEach(function(pixelConfig) {
            self.configurePixel(pixelConfig);
          });
        }
      } catch (e) {
        mpInstance.Logger.error("Cookie Sync configs not configured propertly. Cookie Sync may not be initialized. " + e);
      }
    };
    this.sendSingleForwardingStatsToServer = function(forwardingStatsData) {
      return __awaiter(_this, void 0, void 0, function() {
        var fetchPayload, response, message;
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              fetchPayload = {
                method: "post",
                body: JSON.stringify(forwardingStatsData),
                headers: {
                  Accept: "text/plain;charset=UTF-8",
                  "Content-Type": "text/plain;charset=UTF-8"
                }
              };
              return [4, this.forwarderStatsUploader.upload(fetchPayload)];
            case 1:
              response = _b2.sent();
              if (response.status === 202) {
                message = "Successfully sent forwarding stats to mParticle Servers";
              } else {
                message = "Issue with forwarding stats to mParticle Servers, received HTTP Code of " + response.statusText;
              }
              (_a2 = mpInstance === null || mpInstance === void 0 ? void 0 : mpInstance.Logger) === null || _a2 === void 0 ? void 0 : _a2.verbose(message);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
  }
  var MessageType = Types.MessageType;
  var ApplicationTransitionType = Types.ApplicationTransitionType;
  function convertCustomFlags(event, dto) {
    var valueArray = [];
    dto.flags = {};
    for (var prop in event.CustomFlags) {
      valueArray = [];
      if (event.CustomFlags.hasOwnProperty(prop)) {
        if (Array.isArray(event.CustomFlags[prop])) {
          event.CustomFlags[prop].forEach(function(customFlagProperty) {
            if (isValidCustomFlagProperty(customFlagProperty)) {
              valueArray.push(customFlagProperty.toString());
            }
          });
        } else if (isValidCustomFlagProperty(event.CustomFlags[prop])) {
          valueArray.push(event.CustomFlags[prop].toString());
        }
        if (valueArray.length) {
          dto.flags[prop] = valueArray;
        }
      }
    }
  }
  function convertProductToV2DTO(product) {
    return {
      id: parseStringOrNumber(product.Sku),
      nm: parseStringOrNumber(product.Name),
      pr: parseNumber(product.Price),
      qt: parseNumber(product.Quantity),
      br: parseStringOrNumber(product.Brand),
      va: parseStringOrNumber(product.Variant),
      ca: parseStringOrNumber(product.Category),
      ps: parseNumber(product.Position),
      cc: parseStringOrNumber(product.CouponCode),
      tpa: parseNumber(product.TotalAmount),
      attrs: product.Attributes
    };
  }
  function convertProductListToV2DTO(productList) {
    if (!productList) {
      return [];
    }
    return productList.map(function(product) {
      return convertProductToV2DTO(product);
    });
  }
  function ServerModel(mpInstance) {
    var self = this;
    this.convertToConsentStateV2DTO = function(state) {
      if (!state) {
        return null;
      }
      var jsonObject = {};
      var gdprConsentState = state.getGDPRConsentState();
      if (gdprConsentState) {
        var gdpr = {};
        jsonObject.gdpr = gdpr;
        for (var purpose in gdprConsentState) {
          if (gdprConsentState.hasOwnProperty(purpose)) {
            var gdprConsent = gdprConsentState[purpose];
            jsonObject.gdpr[purpose] = {};
            if (typeof gdprConsent.Consented === "boolean") {
              gdpr[purpose].c = gdprConsent.Consented;
            }
            if (typeof gdprConsent.Timestamp === "number") {
              gdpr[purpose].ts = gdprConsent.Timestamp;
            }
            if (typeof gdprConsent.ConsentDocument === "string") {
              gdpr[purpose].d = gdprConsent.ConsentDocument;
            }
            if (typeof gdprConsent.Location === "string") {
              gdpr[purpose].l = gdprConsent.Location;
            }
            if (typeof gdprConsent.HardwareId === "string") {
              gdpr[purpose].h = gdprConsent.HardwareId;
            }
          }
        }
      }
      var ccpaConsentState = state.getCCPAConsentState();
      if (ccpaConsentState) {
        jsonObject.ccpa = {
          data_sale_opt_out: {
            c: ccpaConsentState.Consented,
            ts: ccpaConsentState.Timestamp,
            d: ccpaConsentState.ConsentDocument,
            l: ccpaConsentState.Location,
            h: ccpaConsentState.HardwareId
          }
        };
      }
      return jsonObject;
    };
    this.createEventObject = function(event, user) {
      var _a2, _b2, _c;
      var uploadObject = {};
      var eventObject = {};
      var optOut = event.messageType === Types.MessageType.OptOut ? !mpInstance._Store.isEnabled : null;
      if (mpInstance._Store.sessionId || event.messageType === Types.MessageType.OptOut || mpInstance._Store.webviewBridgeEnabled) {
        var customFlags = __assign({}, event.customFlags);
        var integrationAttributes = mpInstance._Store.integrationAttributes;
        var getFeatureFlag = mpInstance._Helpers.getFeatureFlag;
        var integrationSpecificIds = getFeatureFlag && getFeatureFlag(Constants.FeatureFlags.CaptureIntegrationSpecificIds);
        var integrationSpecificIdsV2 = getFeatureFlag && (getFeatureFlag(Constants.FeatureFlags.CaptureIntegrationSpecificIdsV2) || "");
        var isIntegrationCaptureEnabled = integrationSpecificIdsV2 && integrationSpecificIdsV2 !== Constants.CaptureIntegrationSpecificIdsV2Modes.None || integrationSpecificIds === true;
        if (isIntegrationCaptureEnabled) {
          mpInstance._IntegrationCapture.capture();
          var transformedClickIDs = mpInstance._IntegrationCapture.getClickIdsAsCustomFlags();
          customFlags = __assign(__assign({}, transformedClickIDs), customFlags);
          var transformedIntegrationAttributes = mpInstance._IntegrationCapture.getClickIdsAsIntegrationAttributes();
          integrationAttributes = __assign(__assign({}, transformedIntegrationAttributes), integrationAttributes);
        }
        if (event.hasOwnProperty("toEventAPIObject")) {
          eventObject = event.toEventAPIObject();
        } else {
          eventObject = {
            // This is an artifact from v2 events where SessionStart/End and AST event
            //  names are numbers (1, 2, or 10), but going forward with v3, these lifecycle
            //  events do not have names, but are denoted by their `event_type`
            EventName: event.name || String(event.messageType),
            EventCategory: event.eventType,
            EventAttributes: mpInstance._Helpers.sanitizeAttributes(event.data, event.name),
            ActiveTimeOnSite: (_a2 = mpInstance._timeOnSiteTimer) === null || _a2 === void 0 ? void 0 : _a2.getTimeInForeground(),
            TotalTimeOnSite: (_c = (_b2 = mpInstance._Store).getTotalTimeOnSite) === null || _c === void 0 ? void 0 : _c.call(_b2),
            PageUrl: getHref() || null,
            SourceMessageId: event.sourceMessageId || mpInstance._Helpers.generateUniqueId(),
            EventDataType: event.messageType,
            CustomFlags: customFlags,
            UserAttributeChanges: event.userAttributeChanges,
            UserIdentityChanges: event.userIdentityChanges
          };
        }
        if (event.messageType !== Types.MessageType.SessionEnd) {
          mpInstance._Store.dateLastEventSent = /* @__PURE__ */ new Date();
        }
        uploadObject = {
          // FIXME: Deprecate when we get rid of V2
          Store: mpInstance._Store.serverSettings,
          SDKVersion: Constants.sdkVersion,
          SessionId: mpInstance._Store.sessionId,
          SessionStartDate: mpInstance._Store.sessionStartDate ? mpInstance._Store.sessionStartDate.getTime() : 0,
          Debug: mpInstance._Store.SDKConfig.isDevelopmentMode,
          Location: mpInstance._Store.currentPosition,
          OptOut: optOut,
          ExpandedEventCount: 0,
          AppVersion: mpInstance.getAppVersion(),
          AppName: mpInstance.getAppName(),
          Package: mpInstance._Store.SDKConfig["package"],
          ClientGeneratedId: mpInstance._Store.clientId,
          DeviceId: mpInstance._Store.deviceId,
          IntegrationAttributes: integrationAttributes,
          CurrencyCode: mpInstance._Store.currencyCode,
          DataPlan: mpInstance._Store.SDKConfig.dataPlan ? mpInstance._Store.SDKConfig.dataPlan : {}
        };
        if (eventObject.EventDataType === MessageType.AppStateTransition) {
          eventObject.IsFirstRun = mpInstance._Store.isFirstRun;
          eventObject.LaunchReferral = window.location.href || null;
        }
        eventObject.CurrencyCode = mpInstance._Store.currencyCode;
        var currentUser = user || mpInstance.Identity.getCurrentUser();
        appendUserInfo(currentUser, eventObject);
        if (event.messageType === Types.MessageType.SessionEnd) {
          eventObject.SessionLength = mpInstance._Store.dateLastEventSent.getTime() - mpInstance._Store.sessionStartDate.getTime();
          eventObject.currentSessionMPIDs = mpInstance._Store.currentSessionMPIDs;
          eventObject.EventAttributes = mpInstance._Store.sessionAttributes;
          mpInstance._Store.currentSessionMPIDs = [];
          mpInstance._Store.sessionStartDate = null;
        }
        uploadObject.Timestamp = mpInstance._Store.dateLastEventSent.getTime();
        return extend({}, eventObject, uploadObject);
      }
      return null;
    };
    this.convertEventToV2DTO = function(event) {
      var dto = {
        n: event.EventName,
        et: event.EventCategory,
        ua: event.UserAttributes,
        ui: event.UserIdentities,
        ia: event.IntegrationAttributes,
        str: event.Store,
        attrs: event.EventAttributes,
        sdk: event.SDKVersion,
        sid: event.SessionId,
        sl: event.SessionLength,
        ssd: event.SessionStartDate,
        dt: event.EventDataType,
        dbg: event.Debug,
        ct: event.Timestamp,
        lc: event.Location,
        o: event.OptOut,
        eec: event.ExpandedEventCount,
        av: event.AppVersion,
        cgid: event.ClientGeneratedId,
        das: event.DeviceId,
        mpid: event.MPID,
        smpids: event.currentSessionMPIDs
      };
      if (event.DataPlan && event.DataPlan.PlanId) {
        dto.dp_id = event.DataPlan.PlanId;
        if (event.DataPlan.PlanVersion) {
          dto.dp_v = event.DataPlan.PlanVersion;
        }
      }
      var consent = self.convertToConsentStateV2DTO(event.ConsentState);
      if (consent) {
        dto.con = consent;
      }
      if (event.EventDataType === MessageType.AppStateTransition) {
        dto.fr = event.IsFirstRun;
        dto.iu = false;
        dto.at = ApplicationTransitionType.AppInit;
        dto.lr = event.LaunchReferral;
        dto.attrs = null;
      }
      if (event.CustomFlags) {
        convertCustomFlags(event, dto);
      }
      if (event.EventDataType === MessageType.Commerce) {
        dto.cu = event.CurrencyCode;
        if (event.ShoppingCart) {
          dto.sc = {
            pl: convertProductListToV2DTO(event.ShoppingCart.ProductList)
          };
        }
        if (event.ProductAction) {
          dto.pd = {
            an: event.ProductAction.ProductActionType,
            cs: mpInstance._Helpers.parseNumber(event.ProductAction.CheckoutStep),
            co: event.ProductAction.CheckoutOptions,
            pl: convertProductListToV2DTO(event.ProductAction.ProductList),
            ti: event.ProductAction.TransactionId,
            ta: event.ProductAction.Affiliation,
            tcc: event.ProductAction.CouponCode,
            tr: mpInstance._Helpers.parseNumber(event.ProductAction.TotalAmount),
            ts: mpInstance._Helpers.parseNumber(event.ProductAction.ShippingAmount),
            tt: mpInstance._Helpers.parseNumber(event.ProductAction.TaxAmount)
          };
        } else if (event.PromotionAction) {
          dto.pm = {
            an: event.PromotionAction.PromotionActionType,
            pl: event.PromotionAction.PromotionList.map(function(promotion) {
              return {
                id: promotion.Id,
                nm: promotion.Name,
                cr: promotion.Creative,
                ps: promotion.Position ? promotion.Position : 0
              };
            })
          };
        } else if (event.ProductImpressions) {
          dto.pi = event.ProductImpressions.map(function(impression) {
            return {
              pil: impression.ProductImpressionList,
              pl: convertProductListToV2DTO(impression.ProductList)
            };
          });
        }
      } else if (event.EventDataType === MessageType.Profile) {
        dto.pet = event.ProfileMessageType;
      }
      return dto;
    };
  }
  function forwardingStatsUploader(mpInstance) {
    this.startForwardingStatsTimer = function() {
      window.mParticle._forwardingStatsTimer = setInterval(function() {
        prepareAndSendForwardingStatsBatch();
      }, mpInstance._Store.SDKConfig.forwarderStatsTimeout);
    };
    function prepareAndSendForwardingStatsBatch() {
      var forwarderQueue = mpInstance._Forwarders.getForwarderStatsQueue(), uploadsTable = mpInstance._Persistence.forwardingStatsBatches.uploadsTable, now = Date.now();
      if (forwarderQueue.length) {
        uploadsTable[now] = {
          uploading: false,
          data: forwarderQueue
        };
        mpInstance._Forwarders.setForwarderStatsQueue([]);
      }
      for (var date in uploadsTable) {
        (function(date2) {
          if (uploadsTable.hasOwnProperty(date2)) {
            if (uploadsTable[date2].uploading === false) {
              var xhrCallback = function xhrCallback2() {
                if (xhr_1.readyState === 4) {
                  if (xhr_1.status === 200 || xhr_1.status === 202) {
                    mpInstance.Logger.verbose("Successfully sent  " + xhr_1.statusText + " from server");
                    delete uploadsTable[date2];
                  } else if (xhr_1.status.toString()[0] === "4") {
                    if (xhr_1.status !== 429) {
                      delete uploadsTable[date2];
                    }
                  } else {
                    uploadsTable[date2].uploading = false;
                  }
                }
              };
              var xhr_1 = mpInstance._Helpers.createXHR(xhrCallback);
              var forwardingStatsData = uploadsTable[date2].data;
              uploadsTable[date2].uploading = true;
              mpInstance._APIClient.sendBatchForwardingStatsToServer(forwardingStatsData, xhr_1);
            }
          }
        })(date);
      }
    }
  }
  var AudienceManager = (
    /** @class */
    (function() {
      function AudienceManager2(userAudienceUrl, apiKey, logger) {
        this.url = "";
        this.logger = logger;
        this.url = "https://".concat(userAudienceUrl).concat(apiKey, "/audience");
        this.userAudienceAPI = window.fetch ? new FetchUploader(this.url) : new XHRUploader(this.url);
      }
      AudienceManager2.prototype.sendGetUserAudienceRequest = function(mpid, callback) {
        return __awaiter(this, void 0, void 0, function() {
          var fetchPayload, audienceURLWithMPID, userAudiencePromise, userAudienceMembershipsServerResponse, parsedUserAudienceMemberships, e_1;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                this.logger.verbose("Fetching user audiences from server");
                fetchPayload = {
                  method: "GET",
                  headers: {
                    Accept: "*/*"
                  }
                };
                audienceURLWithMPID = "".concat(this.url, "?mpid=").concat(mpid);
                _a2.label = 1;
              case 1:
                _a2.trys.push([1, 6, , 7]);
                return [4, this.userAudienceAPI.upload(fetchPayload, audienceURLWithMPID)];
              case 2:
                userAudiencePromise = _a2.sent();
                if (!(userAudiencePromise.status >= 200 && userAudiencePromise.status < 300)) return [3, 4];
                this.logger.verbose("User Audiences successfully received");
                return [4, userAudiencePromise.json()];
              case 3:
                userAudienceMembershipsServerResponse = _a2.sent();
                parsedUserAudienceMemberships = {
                  currentAudienceMemberships: userAudienceMembershipsServerResponse === null || userAudienceMembershipsServerResponse === void 0 ? void 0 : userAudienceMembershipsServerResponse.audience_memberships
                };
                try {
                  callback(parsedUserAudienceMemberships);
                } catch (e) {
                  throw new Error("Error invoking callback on user audience response.");
                }
                return [3, 5];
              case 4:
                if (userAudiencePromise.status === 401) {
                  throw new Error("`HTTP error status ${userAudiencePromise.status} while retrieving User Audiences - please verify your API key.`");
                } else if (userAudiencePromise.status === 403) {
                  throw new Error("`HTTP error status ${userAudiencePromise.status} while retrieving User Audiences - please verify your workspace is enabled for audiences.`");
                } else {
                  throw new Error("Uncaught HTTP Error ".concat(userAudiencePromise.status, "."));
                }
              case 5:
                return [3, 7];
              case 6:
                e_1 = _a2.sent();
                this.logger.error("Error retrieving audiences. ".concat(e_1));
                return [3, 7];
              case 7:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      return AudienceManager2;
    })()
  );
  var processReadyQueue = function processReadyQueue2(readyQueue, logger) {
    if (isEmpty(readyQueue)) {
      return [];
    }
    var items = readyQueue.splice(0, readyQueue.length);
    items.forEach(function(readyQueueItem) {
      try {
        if (isFunction(readyQueueItem)) {
          readyQueueItem();
        } else if (Array.isArray(readyQueueItem)) {
          processPreloadedItem(readyQueueItem);
        }
      } catch (e) {
        logger.error("Error processing ready queue item: " + getErrorMessage(e));
      }
    });
    return [];
  };
  var processPreloadedItem = function processPreloadedItem2(readyQueueItem) {
    var args = readyQueueItem.slice();
    var method = args.splice(0, 1)[0];
    if (typeof method !== "string" || method.length === 0) {
      return;
    }
    if (typeof window !== "undefined" && window.mParticle && window.mParticle[args[0]]) {
      window.mParticle[method].apply(window.mParticle, args);
    } else {
      var methodArray = method.split(".");
      try {
        var computedMPFunction = window.mParticle;
        var context_1 = window.mParticle;
        for (var _i = 0, methodArray_1 = methodArray; _i < methodArray_1.length; _i++) {
          var currentMethod = methodArray_1[_i];
          context_1 = computedMPFunction;
          computedMPFunction = computedMPFunction[currentMethod];
        }
        computedMPFunction.apply(context_1, args);
      } catch (e) {
        throw new Error("Unable to compute proper mParticle function " + e);
      }
    }
  };
  var Messages$2 = Constants.Messages, HTTPCodes$2 = Constants.HTTPCodes, FeatureFlags$1 = Constants.FeatureFlags, IdentityMethods$1 = Constants.IdentityMethods;
  var ErrorMessages = Messages$2.ErrorMessages;
  var CacheIdentity = FeatureFlags$1.CacheIdentity;
  var Identify = IdentityMethods$1.Identify, Modify$1 = IdentityMethods$1.Modify, Login = IdentityMethods$1.Login, Logout = IdentityMethods$1.Logout;
  function Identity(mpInstance) {
    var _a2 = mpInstance._Helpers, getFeatureFlag = _a2.getFeatureFlag, extend2 = _a2.extend;
    var self = this;
    this.idCache = null;
    this.audienceManager = null;
    this.IdentityRequest = {
      preProcessIdentityRequest: function preProcessIdentityRequest(identityApiData, callback, method) {
        mpInstance.Logger.verbose(Messages$2.InformationMessages.StartingLogEvent + ": " + method);
        var removedFalsyIdentityData = mpInstance._Helpers.Validators.removeFalsyIdentityValues(identityApiData, mpInstance.Logger);
        var cleanedIdentityApiData = (removedFalsyIdentityData === null || removedFalsyIdentityData === void 0 ? void 0 : removedFalsyIdentityData.userIdentities) ? __assign(__assign({}, removedFalsyIdentityData), {
          userIdentities: normalizeUserIdentityKeys(removedFalsyIdentityData.userIdentities)
        }) : removedFalsyIdentityData;
        var identityValidationResult = mpInstance._Helpers.Validators.validateIdentities(cleanedIdentityApiData, method);
        if (!identityValidationResult.valid) {
          mpInstance.Logger.error("ERROR: " + identityValidationResult.error);
          return {
            valid: false,
            error: identityValidationResult.error
          };
        }
        if (callback && !mpInstance._Helpers.Validators.isFunction(callback)) {
          var error = "The optional callback must be a function. You tried entering a(n) " + _typeof(callback);
          mpInstance.Logger.error(error);
          return {
            valid: false,
            error
          };
        }
        return {
          valid: true,
          cleanedIdentities: cleanedIdentityApiData
        };
      },
      createIdentityRequest: function createIdentityRequest(identityApiData, platform, sdkVendor, sdkVersion, deviceId, context, mpid) {
        var APIRequest = {
          client_sdk: {
            platform,
            sdk_vendor: sdkVendor,
            sdk_version: sdkVersion
          },
          context,
          environment: mpInstance._Store.SDKConfig.isDevelopmentMode ? "development" : "production",
          request_id: mpInstance._Helpers.generateUniqueId(),
          request_timestamp_ms: (/* @__PURE__ */ new Date()).getTime(),
          previous_mpid: mpid || null,
          known_identities: createKnownIdentities(identityApiData, deviceId)
        };
        return APIRequest;
      },
      createModifyIdentityRequest: function createModifyIdentityRequest(currentUserIdentities, newUserIdentities, platform, sdkVendor, sdkVersion, context) {
        return {
          client_sdk: {
            platform,
            sdk_vendor: sdkVendor,
            sdk_version: sdkVersion
          },
          context,
          environment: mpInstance._Store.SDKConfig.isDevelopmentMode ? "development" : "production",
          request_id: mpInstance._Helpers.generateUniqueId(),
          request_timestamp_ms: (/* @__PURE__ */ new Date()).getTime(),
          identity_changes: this.createIdentityChanges(currentUserIdentities, newUserIdentities)
        };
      },
      createIdentityChanges: function createIdentityChanges(previousIdentities, newIdentities) {
        var identityChanges = [];
        if (newIdentities && isObject(newIdentities) && previousIdentities && isObject(previousIdentities)) {
          for (var key in newIdentities) {
            identityChanges.push({
              old_value: previousIdentities[key] || null,
              new_value: newIdentities[key],
              identity_type: key
            });
          }
        }
        return identityChanges;
      },
      // takes 2 UI objects keyed by name, combines them, returns them keyed by type
      combineUserIdentities: function combineUserIdentities(previousUIByName, newUIByName) {
        var combinedUIByType = {};
        var combinedUIByName = extend2({}, previousUIByName, newUIByName);
        for (var key in combinedUIByName) {
          var type = Types.IdentityType.getIdentityType(key);
          if (type !== false && type >= 0) {
            combinedUIByType[Types.IdentityType.getIdentityType(key)] = combinedUIByName[key];
          }
        }
        return combinedUIByType;
      },
      createAliasNetworkRequest: function createAliasNetworkRequest(aliasRequest) {
        return {
          request_id: mpInstance._Helpers.generateUniqueId(),
          request_type: "alias",
          environment: mpInstance._Store.SDKConfig.isDevelopmentMode ? "development" : "production",
          api_key: mpInstance._Store.devToken,
          data: {
            destination_mpid: aliasRequest.destinationMpid,
            source_mpid: aliasRequest.sourceMpid,
            start_unixtime_ms: aliasRequest.startTime,
            end_unixtime_ms: aliasRequest.endTime,
            scope: aliasRequest.scope,
            device_application_stamp: mpInstance._Store.deviceId
          }
        };
      },
      convertAliasToNative: function convertAliasToNative(aliasRequest) {
        return {
          DestinationMpid: aliasRequest.destinationMpid,
          SourceMpid: aliasRequest.sourceMpid,
          StartUnixtimeMs: aliasRequest.startTime,
          EndUnixtimeMs: aliasRequest.endTime,
          Scope: aliasRequest.scope
        };
      },
      convertToNative: function convertToNative(identityApiData) {
        var nativeIdentityRequest = [];
        if (identityApiData === null || identityApiData === void 0 ? void 0 : identityApiData.userIdentities) {
          for (var key in identityApiData.userIdentities) {
            if (identityApiData.userIdentities.hasOwnProperty(key)) {
              nativeIdentityRequest.push({
                Type: Types.IdentityType.getIdentityType(key),
                Identity: identityApiData.userIdentities[key]
              });
            }
          }
          return {
            UserIdentities: nativeIdentityRequest
          };
        }
        return void 0;
      }
    };
    this.IdentityAPI = {
      HTTPCodes: HTTPCodes$2,
      /**
       * Initiate a logout request to the mParticle server
       * @method identify
       * @param {Object} identityApiData The identityApiData object as indicated [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/README.md#1-customize-the-sdk)
       * @param {Function} [callback] A callback function that is called when the identify request completes
       */
      identify: function identify(identityApiData, callback) {
        var mpid;
        var currentUser = mpInstance.Identity.getCurrentUser();
        var preProcessResult = mpInstance._Identity.IdentityRequest.preProcessIdentityRequest(identityApiData, callback, Identify);
        if (currentUser) {
          mpid = currentUser.getMPID();
        }
        if (preProcessResult.valid) {
          var identityApiRequest = mpInstance._Identity.IdentityRequest.createIdentityRequest(preProcessResult.cleanedIdentities, Constants.platform, Constants.sdkVendor, Constants.sdkVersion, mpInstance._Store.deviceId, mpInstance._Store.context, mpid);
          if (mpInstance._Helpers.getFeatureFlag(Constants.FeatureFlags.CacheIdentity)) {
            var successfullyCachedIdentity = tryCacheIdentity(identityApiRequest.known_identities, self.idCache, self.parseIdentityResponse, mpid, callback, identityApiData, Identify);
            if (successfullyCachedIdentity) {
              return;
            }
          }
          if (mpInstance._Helpers.canLog()) {
            if (mpInstance._Store.webviewBridgeEnabled) {
              mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Identify, JSON.stringify(mpInstance._Identity.IdentityRequest.convertToNative(identityApiData)));
              mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.nativeIdentityRequest, "Identify request sent to native sdk");
            } else {
              mpInstance._IdentityAPIClient.sendIdentityRequest(identityApiRequest, Identify, callback, identityApiData, self.parseIdentityResponse, mpid, identityApiRequest.known_identities);
            }
          } else {
            mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.loggingDisabledOrMissingAPIKey, Messages$2.InformationMessages.AbandonLogEvent);
            mpInstance.Logger.verbose(Messages$2.InformationMessages.AbandonLogEvent);
          }
        } else {
          mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.validationIssue, preProcessResult.error);
          mpInstance.Logger.verbose(preProcessResult);
        }
      },
      /**
       * Initiate a logout request to the mParticle server
       * @method logout
       * @param {Object} identityApiData The identityApiData object as indicated [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/README.md#1-customize-the-sdk)
       * @param {Function} [callback] A callback function that is called when the logout request completes
       */
      logout: function logout(identityApiData, callback) {
        var mpid;
        var currentUser = mpInstance.Identity.getCurrentUser();
        var preProcessResult = mpInstance._Identity.IdentityRequest.preProcessIdentityRequest(identityApiData, callback, Logout);
        if (currentUser) {
          mpid = currentUser.getMPID();
        }
        if (preProcessResult.valid) {
          var evt_1;
          var identityApiRequest = mpInstance._Identity.IdentityRequest.createIdentityRequest(preProcessResult.cleanedIdentities, Constants.platform, Constants.sdkVendor, Constants.sdkVersion, mpInstance._Store.deviceId, mpInstance._Store.context, mpid);
          if (mpInstance._Helpers.canLog()) {
            if (mpInstance._Store.webviewBridgeEnabled) {
              mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Logout, JSON.stringify(mpInstance._Identity.IdentityRequest.convertToNative(identityApiData)));
              mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.nativeIdentityRequest, "Logout request sent to native sdk");
            } else {
              mpInstance._IdentityAPIClient.sendIdentityRequest(identityApiRequest, Logout, callback, identityApiData, self.parseIdentityResponse, mpid);
              evt_1 = mpInstance._ServerModel.createEventObject({
                messageType: Types.MessageType.Profile
              });
              evt_1.ProfileMessageType = Types.ProfileMessageType.Logout;
              if (mpInstance._Store.activeForwarders.length) {
                mpInstance._Store.activeForwarders.forEach(function(forwarder) {
                  var kit = forwarder;
                  if (kit.logOut) {
                    kit.logOut(evt_1);
                  }
                });
              }
            }
          } else {
            mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.loggingDisabledOrMissingAPIKey, Messages$2.InformationMessages.AbandonLogEvent);
            mpInstance.Logger.verbose(Messages$2.InformationMessages.AbandonLogEvent);
          }
        } else {
          mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.validationIssue, preProcessResult.error);
          mpInstance.Logger.verbose(preProcessResult);
        }
      },
      /**
       * Initiate a login request to the mParticle server
       * @method login
       * @param {Object} identityApiData The identityApiData object as indicated [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/README.md#1-customize-the-sdk)
       * @param {Function} [callback] A callback function that is called when the login request completes
       */
      login: function login(identityApiData, callback) {
        var mpid;
        var currentUser = mpInstance.Identity.getCurrentUser();
        var preProcessResult = mpInstance._Identity.IdentityRequest.preProcessIdentityRequest(identityApiData, callback, Login);
        if (currentUser) {
          mpid = currentUser.getMPID();
        }
        if (preProcessResult.valid) {
          var identityApiRequest = mpInstance._Identity.IdentityRequest.createIdentityRequest(preProcessResult.cleanedIdentities, Constants.platform, Constants.sdkVendor, Constants.sdkVersion, mpInstance._Store.deviceId, mpInstance._Store.context, mpid);
          if (mpInstance._Helpers.getFeatureFlag(Constants.FeatureFlags.CacheIdentity)) {
            var successfullyCachedIdentity = tryCacheIdentity(identityApiRequest.known_identities, self.idCache, self.parseIdentityResponse, mpid, callback, identityApiData, Login);
            if (successfullyCachedIdentity) {
              return;
            }
          }
          if (mpInstance._Helpers.canLog()) {
            if (mpInstance._Store.webviewBridgeEnabled) {
              mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Login, JSON.stringify(mpInstance._Identity.IdentityRequest.convertToNative(identityApiData)));
              mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.nativeIdentityRequest, "Login request sent to native sdk");
            } else {
              mpInstance._IdentityAPIClient.sendIdentityRequest(identityApiRequest, Login, callback, identityApiData, self.parseIdentityResponse, mpid, identityApiRequest.known_identities);
            }
          } else {
            mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.loggingDisabledOrMissingAPIKey, Messages$2.InformationMessages.AbandonLogEvent);
            mpInstance.Logger.verbose(Messages$2.InformationMessages.AbandonLogEvent);
          }
        } else {
          mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.validationIssue, preProcessResult.error);
          mpInstance.Logger.verbose(preProcessResult);
        }
      },
      /**
       * Initiate a modify request to the mParticle server
       * @method modify
       * @param {Object} identityApiData The identityApiData object as indicated [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/README.md#1-customize-the-sdk)
       * @param {Function} [callback] A callback function that is called when the modify request completes
       */
      modify: function modify(identityApiData, callback) {
        var mpid;
        var currentUser = mpInstance.Identity.getCurrentUser();
        var preProcessResult = mpInstance._Identity.IdentityRequest.preProcessIdentityRequest(identityApiData, callback, Modify$1);
        if (currentUser) {
          mpid = currentUser.getMPID();
        }
        if (preProcessResult.valid) {
          var newUserIdentities = (identityApiData === null || identityApiData === void 0 ? void 0 : identityApiData.userIdentities) ? preProcessResult.cleanedIdentities.userIdentities : {};
          var identityApiRequest = mpInstance._Identity.IdentityRequest.createModifyIdentityRequest(currentUser ? currentUser.getUserIdentities().userIdentities : {}, newUserIdentities, Constants.platform, Constants.sdkVendor, Constants.sdkVersion, mpInstance._Store.context);
          if (mpInstance._Helpers.canLog()) {
            if (mpInstance._Store.webviewBridgeEnabled) {
              mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Modify, JSON.stringify(mpInstance._Identity.IdentityRequest.convertToNative(identityApiData)));
              mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.nativeIdentityRequest, "Modify request sent to native sdk");
            } else {
              mpInstance._IdentityAPIClient.sendIdentityRequest(identityApiRequest, Modify$1, callback, identityApiData, self.parseIdentityResponse, mpid);
            }
          } else {
            mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.loggingDisabledOrMissingAPIKey, Messages$2.InformationMessages.AbandonLogEvent);
            mpInstance.Logger.verbose(Messages$2.InformationMessages.AbandonLogEvent);
          }
        } else {
          mpInstance._Helpers.invokeCallback(callback, HTTPCodes$2.validationIssue, preProcessResult.error);
          mpInstance.Logger.verbose(preProcessResult);
        }
      },
      /**
       * Returns a user object with methods to interact with the current user
       * @method getCurrentUser
       * @return {Object} the current user object
       */
      getCurrentUser: function getCurrentUser() {
        var mpid;
        if (mpInstance._Store) {
          mpid = mpInstance._Store.mpid;
          if (mpid) {
            mpid = mpInstance._Store.mpid.slice();
            return self.mParticleUser(mpid, mpInstance._Store.isLoggedIn);
          } else if (mpInstance._Store.webviewBridgeEnabled) {
            return self.mParticleUser();
          } else {
            return null;
          }
        } else {
          return null;
        }
      },
      /**
       * Returns a the user object associated with the mpid parameter or 'null' if no such
       * user exists
       * @method getUser
       * @param {String} mpid of the desired user
       * @return {Object} the user for  mpid
       */
      getUser: function getUser(mpid) {
        var persistence = mpInstance._Persistence.getPersistence();
        if (persistence) {
          if (persistence[mpid] && !Constants.SDKv2NonMPIDCookieKeys.hasOwnProperty(mpid)) {
            return self.mParticleUser(mpid);
          } else {
            return null;
          }
        } else {
          return null;
        }
      },
      /**
       * Returns all users, including the current user and all previous users that are stored on the device.
       * @method getUsers
       * @return {Array} array of users
       */
      getUsers: function getUsers() {
        var persistence = mpInstance._Persistence.getPersistence();
        var users = [];
        if (persistence) {
          for (var key in persistence) {
            if (!Constants.SDKv2NonMPIDCookieKeys.hasOwnProperty(key)) {
              users.push(self.mParticleUser(key));
            }
          }
        }
        users.sort(function(a, b) {
          var aLastSeen = a.getLastSeenTime() || 0;
          var bLastSeen = b.getLastSeenTime() || 0;
          if (aLastSeen > bLastSeen) {
            return -1;
          } else {
            return 1;
          }
        });
        return users;
      },
      /**
       * Initiate an alias request to the mParticle server
       * @method aliasUsers
       * @param {Object} aliasRequest  object representing an AliasRequest
       * @param {Function} [callback] A callback function that is called when the aliasUsers request completes
       */
      aliasUsers: function aliasUsers(aliasRequest, callback) {
        var message;
        if (!aliasRequest.destinationMpid || !aliasRequest.sourceMpid) {
          message = Messages$2.ValidationMessages.AliasMissingMpid;
        }
        if (aliasRequest.destinationMpid === aliasRequest.sourceMpid) {
          message = Messages$2.ValidationMessages.AliasNonUniqueMpid;
        }
        if (!aliasRequest.startTime || !aliasRequest.endTime) {
          message = Messages$2.ValidationMessages.AliasMissingTime;
        }
        if (aliasRequest.startTime > aliasRequest.endTime) {
          message = Messages$2.ValidationMessages.AliasStartBeforeEndTime;
        }
        if (message) {
          mpInstance.Logger.warning(message);
          mpInstance._Helpers.invokeAliasCallback(callback, HTTPCodes$2.validationIssue, message);
          return;
        }
        if (mpInstance._Helpers.canLog()) {
          if (mpInstance._Store.webviewBridgeEnabled) {
            mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Alias, JSON.stringify(mpInstance._Identity.IdentityRequest.convertAliasToNative(aliasRequest)));
            mpInstance._Helpers.invokeAliasCallback(callback, HTTPCodes$2.nativeIdentityRequest, "Alias request sent to native sdk");
          } else {
            mpInstance.Logger.verbose(Messages$2.InformationMessages.StartingAliasRequest + ": " + aliasRequest.sourceMpid + " -> " + aliasRequest.destinationMpid);
            var aliasRequestMessage = mpInstance._Identity.IdentityRequest.createAliasNetworkRequest(aliasRequest);
            mpInstance._IdentityAPIClient.sendAliasRequest(aliasRequestMessage, callback);
          }
        } else {
          mpInstance._Helpers.invokeAliasCallback(callback, HTTPCodes$2.loggingDisabledOrMissingAPIKey, Messages$2.InformationMessages.AbandonAliasUsers);
          mpInstance.Logger.verbose(Messages$2.InformationMessages.AbandonAliasUsers);
        }
      },
      /**
       * Search the IDSync Workspace endpoint for a known identity.
       *
       * POSTs to mParticle's `/v1/search` endpoint and invokes `callback`
       * with `{ httpCode, body? }`.
       *
       * The `workspaceApiKey` is a workspace-specific API key supplied by
       * the caller (passed in from a kit's settings). It is intentionally
       * NOT read from the SDK's own workspace token, so that workspace
       * searches can be authorised independently of the host SDK's
       * workspace.
       *
       * @method search
       * @param {String} workspaceApiKey Workspace API key (sent as x-mp-key).
       * @param {Object} knownIdentities A `UserIdentities` map.
       * @param {Function} callback Invoked with the `IIdentitySearchResult`.
       */
      search: function search(workspaceApiKey, knownIdentities, callback) {
        executeSearchRequest(mpInstance, workspaceApiKey, knownIdentities, callback);
      },
      /**
       Create a default AliasRequest for 2 MParticleUsers. This will construct the request
      using the sourceUser's firstSeenTime as the startTime, and its lastSeenTime as the endTime.
      
      In the unlikely scenario that the sourceUser does not have a firstSeenTime, which will only
      be the case if they have not been the current user since this functionality was added, the
      startTime will be populated with the earliest firstSeenTime out of any stored user. Similarly,
      if the sourceUser does not have a lastSeenTime, the endTime will be populated with the current time
      
      There is a limit to how old the startTime can be, represented by the config field 'aliasMaxWindow', in days.
      If the startTime falls before the limit, it will be adjusted to the oldest allowed startTime.
      In rare cases, where the sourceUser's lastSeenTime also falls outside of the aliasMaxWindow limit,
      after applying this adjustment it will be impossible to create an aliasRequest passes the aliasUsers()
      validation that the startTime must be less than the endTime
      */
      createAliasRequest: function createAliasRequest(sourceUser, destinationUser, scope) {
        try {
          if (!destinationUser || !sourceUser) {
            mpInstance.Logger.error("'destinationUser' and 'sourceUser' must both be present");
            return null;
          }
          var startTime_1 = sourceUser.getFirstSeenTime();
          if (!startTime_1) {
            mpInstance.Identity.getUsers().forEach(function(user) {
              if (user.getFirstSeenTime() && (!startTime_1 || user.getFirstSeenTime() < startTime_1)) {
                startTime_1 = user.getFirstSeenTime();
              }
            });
          }
          var minFirstSeenTimeMs = (/* @__PURE__ */ new Date()).getTime() - mpInstance._Store.SDKConfig.aliasMaxWindow * 24 * 60 * 60 * 1e3;
          var endTime = sourceUser.getLastSeenTime() || (/* @__PURE__ */ new Date()).getTime();
          if (startTime_1 < minFirstSeenTimeMs) {
            startTime_1 = minFirstSeenTimeMs;
            if (endTime < startTime_1) {
              mpInstance.Logger.warning("Source User has not been seen in the last " + mpInstance._Store.SDKConfig.maxAliasWindow + " days, Alias Request will likely fail");
            }
          }
          return {
            destinationMpid: destinationUser.getMPID(),
            sourceMpid: sourceUser.getMPID(),
            startTime: startTime_1,
            endTime,
            scope: scope || "device"
          };
        } catch (e) {
          mpInstance.Logger.error("There was a problem with creating an alias request: " + e);
          return null;
        }
      }
    };
    this.mParticleUser = function(mpid, _isLoggedIn) {
      return {
        /**
         * Get user identities for current user
         * @method getUserIdentities
         * @return {Object} an object with userIdentities as its key
         */
        getUserIdentities: function getUserIdentities() {
          var currentUserIdentities = {};
          var identities = mpInstance._Store.getUserIdentities(mpid);
          for (var identityType in identities) {
            if (identities.hasOwnProperty(identityType)) {
              currentUserIdentities[Types.IdentityType.getIdentityName(mpInstance._Helpers.parseNumber(identityType))] = identities[identityType];
            }
          }
          return {
            userIdentities: currentUserIdentities
          };
        },
        /**
         * Get the MPID of the current user
         * @method getMPID
         * @return {String} the current user MPID as a string
         */
        getMPID: function getMPID() {
          return mpid;
        },
        /**
         * Sets a user tag
         * @method setUserTag
         * @param {String} tagName
         */
        setUserTag: function setUserTag(tagName) {
          if (!mpInstance._Helpers.Validators.isValidKeyValue(tagName)) {
            mpInstance.Logger.error(Messages$2.ErrorMessages.BadKey);
            return;
          }
          this.setUserAttribute(tagName, null);
        },
        /**
         * Removes a user tag
         * @method removeUserTag
         * @param {String} tagName
         */
        removeUserTag: function removeUserTag(tagName) {
          if (!mpInstance._Helpers.Validators.isValidKeyValue(tagName)) {
            mpInstance.Logger.error(Messages$2.ErrorMessages.BadKey);
            return;
          }
          this.removeUserAttribute(tagName);
        },
        /**
         * Sets a user attribute
         * @method setUserAttribute
         * @param {String} key
         * @param {String} value
         */
        // https://go.mparticle.com/work/SQDSDKS-4576
        // https://go.mparticle.com/work/SQDSDKS-6373
        setUserAttribute: function setUserAttribute(key, newValue) {
          mpInstance._SessionManager.resetSessionTimer();
          if (mpInstance._Helpers.canLog()) {
            if (!mpInstance._Helpers.Validators.isValidAttributeValue(newValue)) {
              mpInstance.Logger.error(Messages$2.ErrorMessages.BadAttribute);
              return;
            }
            if (!mpInstance._Helpers.Validators.isValidKeyValue(key)) {
              mpInstance.Logger.error(Messages$2.ErrorMessages.BadKey);
              return;
            }
            if (mpInstance._Store.webviewBridgeEnabled) {
              mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.SetUserAttribute, JSON.stringify({
                key,
                value: newValue
              }));
            } else {
              var userAttributes = this.getAllUserAttributes();
              var previousUserAttributeValue = void 0;
              var isNewAttribute = void 0;
              var existingProp = mpInstance._Helpers.findKeyInObject(userAttributes, key);
              if (existingProp) {
                isNewAttribute = false;
                previousUserAttributeValue = userAttributes[existingProp];
                delete userAttributes[existingProp];
              } else {
                isNewAttribute = true;
              }
              userAttributes[key] = newValue;
              mpInstance._Store.setUserAttributes(mpid, userAttributes);
              self.sendUserAttributeChangeEvent(key, newValue, previousUserAttributeValue, isNewAttribute, false, this);
              mpInstance._Forwarders.initForwarders(self.IdentityAPI.getCurrentUser().getUserIdentities(), mpInstance._APIClient.prepareForwardingStats);
              mpInstance._Forwarders.handleForwarderUserAttributes("setUserAttribute", key, newValue);
            }
          }
        },
        /**
         * Set multiple user attributes
         * @method setUserAttributes
         * @param {Object} user attribute object with keys of the attribute type, and value of the attribute value
         */
        // https://go.mparticle.com/work/SQDSDKS-6373
        setUserAttributes: function setUserAttributes(userAttributes) {
          mpInstance._SessionManager.resetSessionTimer();
          if (isObject(userAttributes)) {
            if (mpInstance._Helpers.canLog()) {
              for (var key in userAttributes) {
                if (userAttributes.hasOwnProperty(key)) {
                  this.setUserAttribute(key, userAttributes[key]);
                }
              }
            }
          } else {
            mpInstance.Logger.error("Must pass an object into setUserAttributes. You passed a " + _typeof(userAttributes));
          }
        },
        /**
         * Removes a specific user attribute
         * @method removeUserAttribute
         * @param {String} key
         */
        removeUserAttribute: function removeUserAttribute(key) {
          var cookies;
          var userAttributes;
          mpInstance._SessionManager.resetSessionTimer();
          if (!mpInstance._Helpers.Validators.isValidKeyValue(key)) {
            mpInstance.Logger.error(Messages$2.ErrorMessages.BadKey);
            return;
          }
          if (mpInstance._Store.webviewBridgeEnabled) {
            mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.RemoveUserAttribute, JSON.stringify({
              key,
              value: null
            }));
          } else {
            cookies = mpInstance._Persistence.getPersistence();
            userAttributes = this.getAllUserAttributes();
            var existingProp = mpInstance._Helpers.findKeyInObject(userAttributes, key);
            if (existingProp) {
              key = existingProp;
            }
            var deletedUAKeyCopy = userAttributes[key] ? userAttributes[key].toString() : null;
            delete userAttributes[key];
            if (cookies && cookies[mpid]) {
              cookies[mpid].ua = userAttributes;
              mpInstance._Persistence.savePersistence(cookies);
            }
            self.sendUserAttributeChangeEvent(key, null, deletedUAKeyCopy, false, true, this);
            mpInstance._Forwarders.initForwarders(self.IdentityAPI.getCurrentUser().getUserIdentities(), mpInstance._APIClient.prepareForwardingStats);
            mpInstance._Forwarders.handleForwarderUserAttributes("removeUserAttribute", key, null);
          }
        },
        /**
         * Sets a list of user attributes
         * @method setUserAttributeList
         * @param {String} key
         * @param {Array} value an array of values
         */
        // https://go.mparticle.com/work/SQDSDKS-6373
        setUserAttributeList: function setUserAttributeList(key, newValue) {
          mpInstance._SessionManager.resetSessionTimer();
          if (!mpInstance._Helpers.Validators.isValidKeyValue(key)) {
            mpInstance.Logger.error(Messages$2.ErrorMessages.BadKey);
            return;
          }
          if (!Array.isArray(newValue)) {
            mpInstance.Logger.error("The value you passed in to setUserAttributeList must be an array. You passed in a " + _typeof(newValue));
            return;
          }
          var arrayCopy = newValue.slice();
          if (mpInstance._Store.webviewBridgeEnabled) {
            mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.SetUserAttributeList, JSON.stringify({
              key,
              value: arrayCopy
            }));
          } else {
            var userAttributes = this.getAllUserAttributes();
            var previousUserAttributeValue = void 0;
            var isNewAttribute = void 0;
            var userAttributeChange = void 0;
            var existingProp = mpInstance._Helpers.findKeyInObject(userAttributes, key);
            if (existingProp) {
              isNewAttribute = false;
              previousUserAttributeValue = userAttributes[existingProp];
              delete userAttributes[existingProp];
            } else {
              isNewAttribute = true;
            }
            userAttributes[key] = arrayCopy;
            mpInstance._Store.setUserAttributes(mpid, userAttributes);
            if (!previousUserAttributeValue || !Array.isArray(previousUserAttributeValue)) {
              userAttributeChange = true;
            } else if (newValue.length !== previousUserAttributeValue.length) {
              userAttributeChange = true;
            } else {
              for (var i = 0; i < newValue.length; i++) {
                if (previousUserAttributeValue[i] !== newValue[i]) {
                  userAttributeChange = true;
                  break;
                }
              }
            }
            if (userAttributeChange) {
              self.sendUserAttributeChangeEvent(key, newValue, previousUserAttributeValue, isNewAttribute, false, this);
            }
            mpInstance._Forwarders.initForwarders(self.IdentityAPI.getCurrentUser().getUserIdentities(), mpInstance._APIClient.prepareForwardingStats);
            mpInstance._Forwarders.handleForwarderUserAttributes("setUserAttribute", key, arrayCopy);
          }
        },
        /**
         * Removes all user attributes
         * @method removeAllUserAttributes
         */
        removeAllUserAttributes: function removeAllUserAttributes() {
          var userAttributes;
          mpInstance._SessionManager.resetSessionTimer();
          if (mpInstance._Store.webviewBridgeEnabled) {
            mpInstance._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.RemoveAllUserAttributes);
          } else {
            userAttributes = this.getAllUserAttributes();
            mpInstance._Forwarders.initForwarders(self.IdentityAPI.getCurrentUser().getUserIdentities(), mpInstance._APIClient.prepareForwardingStats);
            if (userAttributes) {
              for (var prop in userAttributes) {
                if (userAttributes.hasOwnProperty(prop)) {
                  mpInstance._Forwarders.handleForwarderUserAttributes("removeUserAttribute", prop, null);
                }
                this.removeUserAttribute(prop);
              }
            }
          }
        },
        /**
         * Returns all user attribute keys that have values that are arrays
         * @method getUserAttributesLists
         * @return {Object} an object of only keys with array values. Example: { attr1: [1, 2, 3], attr2: ['a', 'b', 'c'] }
         */
        getUserAttributesLists: function getUserAttributesLists() {
          var userAttributes;
          var userAttributesLists = {};
          userAttributes = this.getAllUserAttributes();
          for (var key in userAttributes) {
            if (userAttributes.hasOwnProperty(key) && Array.isArray(userAttributes[key])) {
              userAttributesLists[key] = userAttributes[key].slice();
            }
          }
          return userAttributesLists;
        },
        /**
         * Returns all user attributes
         * @method getAllUserAttributes
         * @return {Object} an object of all user attributes. Example: { attr1: 'value1', attr2: ['a', 'b', 'c'] }
         */
        getAllUserAttributes: function getAllUserAttributes() {
          var getUserAttributes = mpInstance._Store.getUserAttributes;
          var userAttributesCopy = {};
          var userAttributes = getUserAttributes(mpid);
          if (userAttributes) {
            for (var prop in userAttributes) {
              if (userAttributes.hasOwnProperty(prop)) {
                var attrValue = userAttributes[prop];
                if (Array.isArray(attrValue)) {
                  userAttributesCopy[prop] = attrValue.slice();
                } else {
                  userAttributesCopy[prop] = attrValue;
                }
              }
            }
          }
          return userAttributesCopy;
        },
        /**
         * Returns the cart object for the current user
         * @method getCart
         * @return a cart object
         */
        getCart: function getCart() {
          logDeprecatedMethodUsage({
            methodName: "Identity.getCurrentUser().getCart()",
            warningMessage: "Deprecated function Identity.getCurrentUser().getCart() will be removed in future releases"
          }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
          return self.mParticleUserCart();
        },
        /**
         * Returns the Consent State stored locally for this user.
         * @method getConsentState
         * @return a ConsentState object
         */
        getConsentState: function getConsentState() {
          return mpInstance._Store.getConsentState(mpid);
        },
        /**
         * Sets the Consent State stored locally for this user.
         * @method setConsentState
         * @param {Object} consent state
         */
        setConsentState: function setConsentState(state) {
          mpInstance._Store.setConsentState(mpid, state);
          mpInstance._Forwarders.initForwarders(this.getUserIdentities().userIdentities, mpInstance._APIClient.prepareForwardingStats);
          mpInstance._CookieSyncManager.attemptCookieSync(this.getMPID());
        },
        isLoggedIn: function isLoggedIn() {
          return _isLoggedIn;
        },
        getLastSeenTime: function getLastSeenTime() {
          return mpInstance._Persistence.getLastSeenTime(mpid);
        },
        getFirstSeenTime: function getFirstSeenTime() {
          return mpInstance._Persistence.getFirstSeenTime(mpid);
        },
        /**
         * Get user audiences
         * @method getuserAudiences
         * @param {Function} [callback] A callback function that is invoked when the user audience request completes
         */
        // https://go.mparticle.com/work/SQDSDKS-6436
        getUserAudiences: function getUserAudiences(callback) {
          if (!mpInstance._Helpers.getFeatureFlag(FeatureFlags$1.AudienceAPI)) {
            mpInstance.Logger.error(ErrorMessages.AudienceAPINotEnabled);
            return;
          }
          if (self.audienceManager === null) {
            self.audienceManager = new AudienceManager(mpInstance._Store.SDKConfig.userAudienceUrl, mpInstance._Store.devToken, mpInstance.Logger);
          }
          self.audienceManager.sendGetUserAudienceRequest(mpid, callback);
        }
      };
    };
    this.mParticleUserCart = function() {
      return {
        /**
         * Adds a cart product to the user cart
         * @method add
         * @deprecated
         */
        add: function add() {
          logDeprecatedMethodUsage({
            methodName: "Identity.getCurrentUser().getCart().add()",
            warningMessage: generateDeprecationMessage("Identity.getCurrentUser().getCart().add()", true, "eCommerce.logProductAction()", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
        },
        /**
         * Removes a cart product from the current user cart
         * @method remove
         * @deprecated
         */
        remove: function remove() {
          logDeprecatedMethodUsage({
            methodName: "Identity.getCurrentUser().getCart().remove()",
            warningMessage: generateDeprecationMessage("Identity.getCurrentUser().getCart().remove()", true, "eCommerce.logProductAction()", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
        },
        /**
         * Clears the user's cart
         * @method clear
         * @deprecated
         */
        clear: function clear() {
          logDeprecatedMethodUsage({
            methodName: "Identity.getCurrentUser().getCart().clear()",
            warningMessage: generateDeprecationMessage("Identity.getCurrentUser().getCart().clear()", true, "", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
        },
        /**
         * Returns all cart products
         * @method getCartProducts
         * @return {Array} array of cart products
         * @deprecated
         */
        getCartProducts: function getCartProducts() {
          logDeprecatedMethodUsage({
            methodName: "Identity.getCurrentUser().getCart().getCartProducts()",
            warningMessage: generateDeprecationMessage("Identity.getCurrentUser().getCart().getCartProducts()", true, "eCommerce.logProductAction()", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
          return [];
        }
      };
    };
    this.parseIdentityResponse = function(identityResponse, previousMPID, callback, identityApiData, method, knownIdentities, parsingCachedResponse) {
      var _a3, _b2, _c;
      var prevUser = mpInstance.Identity.getUser(previousMPID);
      var prevUserMPID = prevUser ? prevUser.getMPID() : null;
      var previousUIByName = prevUser ? prevUser.getUserIdentities().userIdentities : {};
      var mpidIsNotInCookies;
      var identityApiResult;
      var newUser;
      var newIdentitiesByType = {};
      mpInstance._Store.identityCallInFlight = false;
      try {
        mpInstance.Logger.verbose('Parsing "' + method + '" identity response from server');
        identityApiResult = (_a3 = identityResponse.responseText) !== null && _a3 !== void 0 ? _a3 : null;
        mpInstance._Store.isLoggedIn = (identityApiResult === null || identityApiResult === void 0 ? void 0 : identityApiResult.is_logged_in) || false;
        if (hasMPIDChanged(prevUser, identityApiResult)) {
          mpInstance._Store.mpid = identityApiResult.mpid;
          if (prevUser) {
            mpInstance._Persistence.setLastSeenTime(previousMPID);
          }
          mpidIsNotInCookies = !mpInstance._Persistence.getFirstSeenTime(identityApiResult.mpid);
          mpInstance._Persistence.setFirstSeenTime(identityApiResult.mpid);
        }
        if (identityResponse.status === HTTP_OK) {
          if (getFeatureFlag(CacheIdentity)) {
            cacheOrClearIdCache(method, knownIdentities, self.idCache, identityResponse, parsingCachedResponse);
          }
          var incomingUser = self.IdentityAPI.getUser(identityApiResult.mpid);
          var incomingUIByName = incomingUser ? incomingUser.getUserIdentities().userIdentities : {};
          if (method === Modify$1) {
            newIdentitiesByType = mpInstance._Identity.IdentityRequest.combineUserIdentities(previousUIByName, identityApiData.userIdentities);
            mpInstance._Store.setUserIdentities(previousMPID, newIdentitiesByType);
          } else {
            if (method === Identify && prevUser && identityApiResult.mpid === prevUserMPID) {
              mpInstance._Persistence.setFirstSeenTime(identityApiResult.mpid);
            }
            mpInstance._Store.addMpidToSessionHistory(identityApiResult.mpid, previousMPID);
            mpInstance._CookieSyncManager.attemptCookieSync(identityApiResult.mpid, mpidIsNotInCookies);
            mpInstance._Persistence.swapCurrentUser(previousMPID, identityApiResult.mpid, mpInstance._Store.currentSessionMPIDs);
            if (identityApiData && !isEmpty(identityApiData.userIdentities)) {
              newIdentitiesByType = self.IdentityRequest.combineUserIdentities(incomingUIByName, identityApiData.userIdentities);
            }
            mpInstance._Store.setUserIdentities(identityApiResult.mpid, newIdentitiesByType);
            mpInstance._Persistence.update();
            mpInstance._Store.syncPersistenceData();
            mpInstance._Persistence.findPrevCookiesBasedOnUI(identityApiData);
            mpInstance._Store.context = identityApiResult.context || mpInstance._Store.context;
          }
          newUser = mpInstance.Identity.getCurrentUser();
          tryOnUserAlias(prevUser, newUser, identityApiData, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
          var persistence = mpInstance._Persistence.getPersistence();
          if (newUser) {
            mpInstance._Persistence.storeDataInMemory(persistence, newUser.getMPID());
            self.reinitForwardersOnUserChange(prevUser, newUser);
            self.setForwarderCallbacks(newUser, method);
          }
          var newIdentitiesByName = IdentityType.getNewIdentitiesByName(newIdentitiesByType);
          var uiByName = method === Modify$1 ? previousUIByName : incomingUIByName;
          (_b2 = mpInstance._CookieConsentManager) === null || _b2 === void 0 ? void 0 : _b2.syncNoTargetingAttribute(newUser);
          self.sendUserIdentityChangeEvent(newIdentitiesByName, method, identityApiResult.mpid, uiByName);
        }
        if (callback) {
          var callbackCode = identityResponse.status === 0 ? HTTPCodes$2.noHttpCoverage : identityResponse.status;
          mpInstance._Helpers.invokeCallback(callback, callbackCode, identityApiResult || null, newUser);
        } else if (identityApiResult && !isEmpty(identityApiResult.errors)) {
          mpInstance.Logger.error("Received HTTP response code of " + identityResponse.status + " - " + identityApiResult.errors[0].message);
        }
        mpInstance.Logger.verbose("Successfully parsed Identity Response");
        (_c = mpInstance._APIClient) === null || _c === void 0 ? void 0 : _c.processQueuedEvents();
      } catch (e) {
        if (callback) {
          mpInstance._Helpers.invokeCallback(callback, identityResponse.status, identityApiResult || null);
        }
        mpInstance.Logger.error("Error parsing JSON response from Identity server: " + e);
      }
      mpInstance._Store.isInitialized = true;
      mpInstance._RoktManager.onIdentityComplete();
      mpInstance._preInit.readyQueue = processReadyQueue(mpInstance._preInit.readyQueue, mpInstance.Logger);
    };
    this.sendUserIdentityChangeEvent = function(newUserIdentities, method, mpid, prevUserIdentities) {
      var _a3;
      if (!mpid) {
        if (method !== Modify$1) {
          return;
        }
      }
      var currentUserInMemory = this.IdentityAPI.getUser(mpid);
      for (var identityType in newUserIdentities) {
        if (prevUserIdentities[identityType] !== newUserIdentities[identityType]) {
          var isNewUserIdentityType = !prevUserIdentities[identityType];
          var userIdentityChangeEvent = self.createUserIdentityChange(identityType, newUserIdentities[identityType], prevUserIdentities[identityType], isNewUserIdentityType, currentUserInMemory);
          (_a3 = mpInstance._APIClient) === null || _a3 === void 0 ? void 0 : _a3.sendEventToServer(userIdentityChangeEvent);
        }
      }
    };
    this.createUserIdentityChange = function(identityType, newIdentity, oldIdentity, isIdentityTypeNewToBatch, userInMemory) {
      var userIdentityChangeEvent;
      userIdentityChangeEvent = mpInstance._ServerModel.createEventObject({
        messageType: Types.MessageType.UserIdentityChange,
        userIdentityChanges: {
          New: {
            IdentityType: identityType,
            Identity: newIdentity,
            CreatedThisBatch: isIdentityTypeNewToBatch
          },
          Old: {
            IdentityType: identityType,
            Identity: oldIdentity,
            CreatedThisBatch: false
          }
        },
        userInMemory
      });
      return userIdentityChangeEvent;
    };
    this.sendUserAttributeChangeEvent = function(attributeKey, newUserAttributeValue, previousUserAttributeValue, isNewAttribute, deleted, user) {
      var _a3;
      var userAttributeChangeEvent = self.createUserAttributeChange(attributeKey, newUserAttributeValue, previousUserAttributeValue, isNewAttribute, deleted, user);
      if (userAttributeChangeEvent) {
        (_a3 = mpInstance._APIClient) === null || _a3 === void 0 ? void 0 : _a3.sendEventToServer(userAttributeChangeEvent);
      }
    };
    this.createUserAttributeChange = function(key, newValue, previousUserAttributeValue, isNewAttribute, deleted, user) {
      if (typeof previousUserAttributeValue === "undefined") {
        previousUserAttributeValue = null;
      }
      var userAttributeChangeEvent;
      if (newValue !== previousUserAttributeValue) {
        userAttributeChangeEvent = mpInstance._ServerModel.createEventObject({
          messageType: Types.MessageType.UserAttributeChange,
          userAttributeChanges: {
            UserAttributeName: key,
            New: newValue,
            Old: previousUserAttributeValue,
            Deleted: deleted,
            IsNewAttribute: isNewAttribute
          }
        }, user);
      }
      return userAttributeChangeEvent;
    };
    this.reinitForwardersOnUserChange = function(prevUser, newUser) {
      var _a3;
      if (hasMPIDAndUserLoginChanged(prevUser, newUser)) {
        (_a3 = mpInstance._Forwarders) === null || _a3 === void 0 ? void 0 : _a3.initForwarders(newUser.getUserIdentities().userIdentities, mpInstance._APIClient.prepareForwardingStats);
      }
    };
    this.setForwarderCallbacks = function(user, method) {
      var _a3, _b2, _c;
      (_a3 = mpInstance._Forwarders) === null || _a3 === void 0 ? void 0 : _a3.setForwarderUserIdentities(user.getUserIdentities().userIdentities);
      (_b2 = mpInstance._Forwarders) === null || _b2 === void 0 ? void 0 : _b2.setForwarderOnIdentityComplete(user, method);
      (_c = mpInstance._Forwarders) === null || _c === void 0 ? void 0 : _c.setForwarderOnUserIdentified(user);
    };
  }
  function tryOnUserAlias(previousUser, newUser, identityApiData, logger, errorReporter) {
    if (identityApiData && identityApiData.onUserAlias && isFunction(identityApiData.onUserAlias)) {
      try {
        logDeprecatedMethodUsage({
          methodName: "onUserAlias",
          warningMessage: generateDeprecationMessage("onUserAlias")
        }, logger, errorReporter);
        identityApiData.onUserAlias(previousUser, newUser);
      } catch (e) {
        logger.error("There was an error with your onUserAlias function - " + e);
      }
    }
  }
  var CCPAPurpose = Constants.CCPAPurpose;
  function Consent(mpInstance) {
    var self = this;
    this.isEnabledForUserConsent = function(consentRules, user) {
      if (!consentRules || !consentRules.values || !consentRules.values.length) {
        return true;
      }
      if (!user) {
        return false;
      }
      var purposeHashes = {};
      var consentState = user.getConsentState();
      var purposeHash;
      if (consentState) {
        var GDPRConsentHashPrefix = "1";
        var CCPAHashPrefix = "2";
        var gdprConsentState = consentState.getGDPRConsentState();
        if (gdprConsentState) {
          for (var purpose in gdprConsentState) {
            if (gdprConsentState.hasOwnProperty(purpose)) {
              purposeHash = KitFilterHelper.hashConsentPurposeConditionalForwarding(GDPRConsentHashPrefix, purpose);
              purposeHashes[purposeHash] = gdprConsentState[purpose].Consented;
            }
          }
        }
        var CCPAConsentState = consentState.getCCPAConsentState();
        if (CCPAConsentState) {
          purposeHash = KitFilterHelper.hashConsentPurposeConditionalForwarding(CCPAHashPrefix, CCPAPurpose);
          purposeHashes[purposeHash] = CCPAConsentState.Consented;
        }
      }
      var isMatch = consentRules.values.some(function(consentRule) {
        var consentPurposeHash = consentRule.consentPurpose;
        var hasConsented = consentRule.hasConsented;
        if (purposeHashes.hasOwnProperty(consentPurposeHash)) {
          return purposeHashes[consentPurposeHash] === hasConsented;
        }
        return false;
      });
      return consentRules.includeOnMatch === isMatch;
    };
    this.createPrivacyConsent = function(consented, timestamp, consentDocument, location2, hardwareId) {
      if (typeof consented !== "boolean") {
        mpInstance.Logger.error("Consented boolean is required when constructing a Consent object.");
        return null;
      }
      if (timestamp && isNaN(timestamp)) {
        mpInstance.Logger.error("Timestamp must be a valid number when constructing a Consent object.");
        return null;
      }
      if (consentDocument && typeof consentDocument !== "string") {
        mpInstance.Logger.error("Document must be a valid string when constructing a Consent object.");
        return null;
      }
      if (location2 && typeof location2 !== "string") {
        mpInstance.Logger.error("Location must be a valid string when constructing a Consent object.");
        return null;
      }
      if (hardwareId && typeof hardwareId !== "string") {
        mpInstance.Logger.error("Hardware ID must be a valid string when constructing a Consent object.");
        return null;
      }
      return {
        Consented: consented,
        Timestamp: timestamp || Date.now(),
        ConsentDocument: consentDocument,
        Location: location2,
        HardwareId: hardwareId
      };
    };
    this.ConsentSerialization = {
      toMinifiedJsonObject: function toMinifiedJsonObject(state) {
        var _a2;
        var jsonObject = {};
        if (state) {
          var gdprConsentState = state.getGDPRConsentState();
          if (gdprConsentState) {
            jsonObject.gdpr = {};
            for (var purpose in gdprConsentState) {
              if (gdprConsentState.hasOwnProperty(purpose)) {
                var gdprConsent = gdprConsentState[purpose];
                jsonObject.gdpr[purpose] = {};
                if (typeof gdprConsent.Consented === "boolean") {
                  jsonObject.gdpr[purpose].c = gdprConsent.Consented;
                }
                if (typeof gdprConsent.Timestamp === "number") {
                  jsonObject.gdpr[purpose].ts = gdprConsent.Timestamp;
                }
                if (typeof gdprConsent.ConsentDocument === "string") {
                  jsonObject.gdpr[purpose].d = gdprConsent.ConsentDocument;
                }
                if (typeof gdprConsent.Location === "string") {
                  jsonObject.gdpr[purpose].l = gdprConsent.Location;
                }
                if (typeof gdprConsent.HardwareId === "string") {
                  jsonObject.gdpr[purpose].h = gdprConsent.HardwareId;
                }
              }
            }
          }
          var ccpaConsentState = state.getCCPAConsentState();
          if (ccpaConsentState) {
            jsonObject.ccpa = (_a2 = {}, _a2[CCPAPurpose] = {}, _a2);
            if (typeof ccpaConsentState.Consented === "boolean") {
              jsonObject.ccpa[CCPAPurpose].c = ccpaConsentState.Consented;
            }
            if (typeof ccpaConsentState.Timestamp === "number") {
              jsonObject.ccpa[CCPAPurpose].ts = ccpaConsentState.Timestamp;
            }
            if (typeof ccpaConsentState.ConsentDocument === "string") {
              jsonObject.ccpa[CCPAPurpose].d = ccpaConsentState.ConsentDocument;
            }
            if (typeof ccpaConsentState.Location === "string") {
              jsonObject.ccpa[CCPAPurpose].l = ccpaConsentState.Location;
            }
            if (typeof ccpaConsentState.HardwareId === "string") {
              jsonObject.ccpa[CCPAPurpose].h = ccpaConsentState.HardwareId;
            }
          }
        }
        return jsonObject;
      },
      fromMinifiedJsonObject: function fromMinifiedJsonObject(json) {
        var state = self.createConsentState();
        if (json.gdpr) {
          for (var purpose in json.gdpr) {
            if (json.gdpr.hasOwnProperty(purpose)) {
              var gdprConsent = self.createPrivacyConsent(json.gdpr[purpose].c, json.gdpr[purpose].ts, json.gdpr[purpose].d, json.gdpr[purpose].l, json.gdpr[purpose].h);
              state.addGDPRConsentState(purpose, gdprConsent);
            }
          }
        }
        if (json.ccpa) {
          if (json.ccpa.hasOwnProperty(CCPAPurpose)) {
            var ccpaConsent = self.createPrivacyConsent(json.ccpa[CCPAPurpose].c, json.ccpa[CCPAPurpose].ts, json.ccpa[CCPAPurpose].d, json.ccpa[CCPAPurpose].l, json.ccpa[CCPAPurpose].h);
            state.setCCPAConsentState(ccpaConsent);
          }
        }
        return state;
      }
    };
    this.createConsentState = function(consentState) {
      var gdpr = {};
      var ccpa = {};
      if (consentState) {
        var consentStateCopy = self.createConsentState();
        consentStateCopy.setGDPRConsentState(consentState.getGDPRConsentState());
        consentStateCopy.setCCPAConsentState(consentState.getCCPAConsentState());
        return consentStateCopy;
      }
      function canonicalizeForDeduplication(purpose) {
        if (typeof purpose !== "string") {
          return null;
        }
        var trimmedPurpose = purpose.trim();
        if (!trimmedPurpose.length) {
          return null;
        }
        return trimmedPurpose.toLowerCase();
      }
      function addGDPRConsentState(purpose, gdprConsent) {
        var normalizedPurpose = canonicalizeForDeduplication(purpose);
        if (!normalizedPurpose) {
          mpInstance.Logger.error("Purpose must be a string.");
          return this;
        }
        if (!isObject(gdprConsent)) {
          mpInstance.Logger.error("Invoked with a bad or empty consent object.");
          return this;
        }
        var gdprConsentCopy = self.createPrivacyConsent(gdprConsent.Consented, gdprConsent.Timestamp, gdprConsent.ConsentDocument, gdprConsent.Location, gdprConsent.HardwareId);
        if (gdprConsentCopy) {
          gdpr[normalizedPurpose] = gdprConsentCopy;
        }
        return this;
      }
      function setGDPRConsentState(gdprConsentState) {
        if (!gdprConsentState) {
          gdpr = {};
        } else if (isObject(gdprConsentState)) {
          gdpr = {};
          for (var purpose in gdprConsentState) {
            if (gdprConsentState.hasOwnProperty(purpose)) {
              this.addGDPRConsentState(purpose, gdprConsentState[purpose]);
            }
          }
        }
        return this;
      }
      function removeGDPRConsentState(purpose) {
        var normalizedPurpose = canonicalizeForDeduplication(purpose);
        if (!normalizedPurpose) {
          return this;
        }
        delete gdpr[normalizedPurpose];
        return this;
      }
      function getGDPRConsentState() {
        return Object.assign({}, gdpr);
      }
      function setCCPAConsentState(ccpaConsent) {
        if (!isObject(ccpaConsent)) {
          mpInstance.Logger.error("Invoked with a bad or empty CCPA consent object.");
          return this;
        }
        var ccpaConsentCopy = self.createPrivacyConsent(ccpaConsent.Consented, ccpaConsent.Timestamp, ccpaConsent.ConsentDocument, ccpaConsent.Location, ccpaConsent.HardwareId);
        if (ccpaConsentCopy) {
          ccpa[CCPAPurpose] = ccpaConsentCopy;
        }
        return this;
      }
      function getCCPAConsentState() {
        return ccpa[CCPAPurpose];
      }
      function removeCCPAConsentState() {
        delete ccpa[CCPAPurpose];
        return this;
      }
      function removeCCPAState() {
        logDeprecatedMethodUsage({
          methodName: "Consent.removeCCPAState",
          warningMessage: "removeCCPAState is deprecated and will be removed in a future release; use removeCCPAConsentState instead"
        }, mpInstance.Logger, mpInstance._ErrorReportingDispatcher);
        return removeCCPAConsentState();
      }
      return {
        setGDPRConsentState,
        addGDPRConsentState,
        setCCPAConsentState,
        getCCPAConsentState,
        getGDPRConsentState,
        removeGDPRConsentState,
        removeCCPAState,
        removeCCPAConsentState
      };
    };
  }
  var DataPlanMatchType = {
    ScreenView: "screen_view",
    CustomEvent: "custom_event",
    Commerce: "commerce",
    UserAttributes: "user_attributes",
    UserIdentities: "user_identities",
    ProductAction: "product_action",
    PromotionAction: "promotion_action",
    ProductImpression: "product_impression"
  };
  var KitBlocker = (
    /** @class */
    (function() {
      function KitBlocker2(dataPlan, mpInstance) {
        var _this = this;
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        this.dataPlanMatchLookups = {};
        this.blockEvents = false;
        this.blockEventAttributes = false;
        this.blockUserAttributes = false;
        this.blockUserIdentities = false;
        this.kitBlockingEnabled = false;
        if (dataPlan && !dataPlan.document) {
          this.kitBlockingEnabled = false;
          return;
        }
        this.kitBlockingEnabled = true;
        this.mpInstance = mpInstance;
        this.blockEvents = (_c = (_b2 = (_a2 = dataPlan === null || dataPlan === void 0 ? void 0 : dataPlan.document) === null || _a2 === void 0 ? void 0 : _a2.dtpn) === null || _b2 === void 0 ? void 0 : _b2.blok) === null || _c === void 0 ? void 0 : _c.ev;
        this.blockEventAttributes = (_f = (_e = (_d = dataPlan === null || dataPlan === void 0 ? void 0 : dataPlan.document) === null || _d === void 0 ? void 0 : _d.dtpn) === null || _e === void 0 ? void 0 : _e.blok) === null || _f === void 0 ? void 0 : _f.ea;
        this.blockUserAttributes = (_j = (_h = (_g = dataPlan === null || dataPlan === void 0 ? void 0 : dataPlan.document) === null || _g === void 0 ? void 0 : _g.dtpn) === null || _h === void 0 ? void 0 : _h.blok) === null || _j === void 0 ? void 0 : _j.ua;
        this.blockUserIdentities = (_m = (_l = (_k = dataPlan === null || dataPlan === void 0 ? void 0 : dataPlan.document) === null || _k === void 0 ? void 0 : _k.dtpn) === null || _l === void 0 ? void 0 : _l.blok) === null || _m === void 0 ? void 0 : _m.id;
        var versionDocument = (_q = (_p = (_o = dataPlan === null || dataPlan === void 0 ? void 0 : dataPlan.document) === null || _o === void 0 ? void 0 : _o.dtpn) === null || _p === void 0 ? void 0 : _p.vers) === null || _q === void 0 ? void 0 : _q.version_document;
        var dataPoints = versionDocument === null || versionDocument === void 0 ? void 0 : versionDocument.data_points;
        if (versionDocument) {
          try {
            if ((dataPoints === null || dataPoints === void 0 ? void 0 : dataPoints.length) > 0) {
              dataPoints.forEach(function(point) {
                return _this.addToMatchLookups(point);
              });
            }
          } catch (e) {
            this.mpInstance.Logger.error("There was an issue with the data plan: " + e);
          }
        }
      }
      KitBlocker2.prototype.addToMatchLookups = function(point) {
        var _a2, _b2, _c;
        if (!point.match || !point.validator) {
          this.mpInstance.Logger.warning("Data Plan Point is not valid' + ".concat(point));
          return;
        }
        var matchKey = this.generateMatchKey(point.match);
        var properties = this.getPlannedProperties(point.match.type, point.validator);
        this.dataPlanMatchLookups[matchKey] = properties;
        if (((_a2 = point === null || point === void 0 ? void 0 : point.match) === null || _a2 === void 0 ? void 0 : _a2.type) === DataPlanMatchType.ProductImpression || ((_b2 = point === null || point === void 0 ? void 0 : point.match) === null || _b2 === void 0 ? void 0 : _b2.type) === DataPlanMatchType.ProductAction || ((_c = point === null || point === void 0 ? void 0 : point.match) === null || _c === void 0 ? void 0 : _c.type) === DataPlanMatchType.PromotionAction) {
          matchKey = this.generateProductAttributeMatchKey(point.match);
          properties = this.getProductProperties(point.match.type, point.validator);
          this.dataPlanMatchLookups[matchKey] = properties;
        }
      };
      KitBlocker2.prototype.generateMatchKey = function(match) {
        var criteria = match.criteria || "";
        switch (match.type) {
          case DataPlanMatchType.CustomEvent:
            var customEventCriteria = criteria;
            return [DataPlanMatchType.CustomEvent, customEventCriteria.custom_event_type, customEventCriteria.event_name].join(":");
          case DataPlanMatchType.ScreenView:
            var screenViewCriteria = criteria;
            return [DataPlanMatchType.ScreenView, "", screenViewCriteria.screen_name].join(":");
          case DataPlanMatchType.ProductAction:
            var productActionMatch = criteria;
            return [match.type, productActionMatch.action].join(":");
          case DataPlanMatchType.PromotionAction:
            var promoActionMatch = criteria;
            return [match.type, promoActionMatch.action].join(":");
          case DataPlanMatchType.ProductImpression:
            var productImpressionActionMatch = criteria;
            return [match.type, productImpressionActionMatch.action].join(":");
          case DataPlanMatchType.UserIdentities:
          case DataPlanMatchType.UserAttributes:
            return [match.type].join(":");
          default:
            return null;
        }
      };
      KitBlocker2.prototype.generateProductAttributeMatchKey = function(match) {
        var criteria = match.criteria || "";
        switch (match.type) {
          case DataPlanMatchType.ProductAction:
            var productActionMatch = criteria;
            return [match.type, productActionMatch.action, "ProductAttributes"].join(":");
          case DataPlanMatchType.PromotionAction:
            var promoActionMatch = criteria;
            return [match.type, promoActionMatch.action, "ProductAttributes"].join(":");
          case DataPlanMatchType.ProductImpression:
            return [match.type, "ProductAttributes"].join(":");
          default:
            return null;
        }
      };
      KitBlocker2.prototype.getPlannedProperties = function(type, validator) {
        var _a2, _b2, _c, _d, _e, _f, _g, _h;
        var customAttributes;
        var userAdditionalProperties;
        switch (type) {
          case DataPlanMatchType.CustomEvent:
          case DataPlanMatchType.ScreenView:
          case DataPlanMatchType.ProductAction:
          case DataPlanMatchType.PromotionAction:
          case DataPlanMatchType.ProductImpression:
            customAttributes = (_d = (_c = (_b2 = (_a2 = validator === null || validator === void 0 ? void 0 : validator.definition) === null || _a2 === void 0 ? void 0 : _a2.properties) === null || _b2 === void 0 ? void 0 : _b2.data) === null || _c === void 0 ? void 0 : _c.properties) === null || _d === void 0 ? void 0 : _d.custom_attributes;
            if (customAttributes) {
              if (customAttributes.additionalProperties === true || customAttributes.additionalProperties === void 0) {
                return true;
              } else {
                var properties = {};
                for (var _i = 0, _j = Object.keys(customAttributes.properties); _i < _j.length; _i++) {
                  var property = _j[_i];
                  properties[property] = true;
                }
                return properties;
              }
            } else {
              if (((_g = (_f = (_e = validator === null || validator === void 0 ? void 0 : validator.definition) === null || _e === void 0 ? void 0 : _e.properties) === null || _f === void 0 ? void 0 : _f.data) === null || _g === void 0 ? void 0 : _g.additionalProperties) === false) {
                return {};
              } else {
                return true;
              }
            }
          case DataPlanMatchType.UserAttributes:
          case DataPlanMatchType.UserIdentities:
            userAdditionalProperties = (_h = validator === null || validator === void 0 ? void 0 : validator.definition) === null || _h === void 0 ? void 0 : _h.additionalProperties;
            if (userAdditionalProperties === true || userAdditionalProperties === void 0) {
              return true;
            } else {
              var properties = {};
              var userProperties = validator.definition.properties;
              for (var _k = 0, _l = Object.keys(userProperties); _k < _l.length; _k++) {
                var property = _l[_k];
                properties[property] = true;
              }
              return properties;
            }
          default:
            return null;
        }
      };
      KitBlocker2.prototype.getProductProperties = function(type, validator) {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
        var productCustomAttributes;
        switch (type) {
          case DataPlanMatchType.ProductImpression:
            productCustomAttributes = (_k = (_j = (_h = (_g = (_f = (_e = (_d = (_c = (_b2 = (_a2 = validator === null || validator === void 0 ? void 0 : validator.definition) === null || _a2 === void 0 ? void 0 : _a2.properties) === null || _b2 === void 0 ? void 0 : _b2.data) === null || _c === void 0 ? void 0 : _c.properties) === null || _d === void 0 ? void 0 : _d.product_impressions) === null || _e === void 0 ? void 0 : _e.items) === null || _f === void 0 ? void 0 : _f.properties) === null || _g === void 0 ? void 0 : _g.products) === null || _h === void 0 ? void 0 : _h.items) === null || _j === void 0 ? void 0 : _j.properties) === null || _k === void 0 ? void 0 : _k.custom_attributes;
            if ((productCustomAttributes === null || productCustomAttributes === void 0 ? void 0 : productCustomAttributes.additionalProperties) === false) {
              var properties = {};
              for (var _i = 0, _v = Object.keys(productCustomAttributes === null || productCustomAttributes === void 0 ? void 0 : productCustomAttributes.properties); _i < _v.length; _i++) {
                var property = _v[_i];
                properties[property] = true;
              }
              return properties;
            }
            return true;
          case DataPlanMatchType.ProductAction:
          case DataPlanMatchType.PromotionAction:
            productCustomAttributes = (_u = (_t = (_s = (_r = (_q = (_p = (_o = (_m = (_l = validator === null || validator === void 0 ? void 0 : validator.definition) === null || _l === void 0 ? void 0 : _l.properties) === null || _m === void 0 ? void 0 : _m.data) === null || _o === void 0 ? void 0 : _o.properties) === null || _p === void 0 ? void 0 : _p.product_action) === null || _q === void 0 ? void 0 : _q.properties) === null || _r === void 0 ? void 0 : _r.products) === null || _s === void 0 ? void 0 : _s.items) === null || _t === void 0 ? void 0 : _t.properties) === null || _u === void 0 ? void 0 : _u.custom_attributes;
            if (productCustomAttributes) {
              if (productCustomAttributes.additionalProperties === false) {
                var properties = {};
                for (var _w = 0, _x = Object.keys(productCustomAttributes === null || productCustomAttributes === void 0 ? void 0 : productCustomAttributes.properties); _w < _x.length; _w++) {
                  var property = _x[_w];
                  properties[property] = true;
                }
                return properties;
              }
            }
            return true;
          default:
            return null;
        }
      };
      KitBlocker2.prototype.getMatchKey = function(eventToMatch) {
        switch (eventToMatch.event_type) {
          case dist.EventTypeEnum.screenView:
            var screenViewEvent = eventToMatch;
            if (screenViewEvent.data) {
              return ["screen_view", "", screenViewEvent.data.screen_name].join(":");
            }
            return null;
          case dist.EventTypeEnum.commerceEvent:
            var commerceEvent = eventToMatch;
            var matchKey = [];
            if (commerceEvent && commerceEvent.data) {
              var _a2 = commerceEvent.data, product_action = _a2.product_action, product_impressions = _a2.product_impressions, promotion_action = _a2.promotion_action;
              if (product_action) {
                matchKey.push(DataPlanMatchType.ProductAction);
                matchKey.push(product_action.action);
              } else if (promotion_action) {
                matchKey.push(DataPlanMatchType.PromotionAction);
                matchKey.push(promotion_action.action);
              } else if (product_impressions) {
                matchKey.push(DataPlanMatchType.ProductImpression);
              }
            }
            return matchKey.join(":");
          case dist.EventTypeEnum.customEvent:
            var customEvent = eventToMatch;
            if (customEvent.data) {
              return ["custom_event", customEvent.data.custom_event_type, customEvent.data.event_name].join(":");
            }
            return null;
          default:
            return null;
        }
      };
      KitBlocker2.prototype.getProductAttributeMatchKey = function(eventToMatch) {
        switch (eventToMatch.event_type) {
          case dist.EventTypeEnum.commerceEvent:
            var commerceEvent = eventToMatch;
            var matchKey = [];
            var _a2 = commerceEvent.data, product_action = _a2.product_action, product_impressions = _a2.product_impressions, promotion_action = _a2.promotion_action;
            if (product_action) {
              matchKey.push(DataPlanMatchType.ProductAction);
              matchKey.push(product_action.action);
              matchKey.push("ProductAttributes");
            } else if (promotion_action) {
              matchKey.push(DataPlanMatchType.PromotionAction);
              matchKey.push(promotion_action.action);
              matchKey.push("ProductAttributes");
            } else if (product_impressions) {
              matchKey.push(DataPlanMatchType.ProductImpression);
              matchKey.push("ProductAttributes");
            }
            return matchKey.join(":");
          default:
            return null;
        }
      };
      KitBlocker2.prototype.createBlockedEvent = function(event) {
        try {
          if (event) {
            event = this.transformEventAndEventAttributes(event);
          }
          if (event && event.EventDataType === Types.MessageType.Commerce) {
            event = this.transformProductAttributes(event);
          }
          if (event) {
            event = this.transformUserAttributes(event);
            event = this.transformUserIdentities(event);
          }
          return event;
        } catch (e) {
          return event;
        }
      };
      KitBlocker2.prototype.transformEventAndEventAttributes = function(event) {
        var clonedEvent = __assign({}, event);
        var baseEvent = convertEvent(clonedEvent);
        var matchKey = this.getMatchKey(baseEvent);
        var matchedEvent = this.dataPlanMatchLookups[matchKey];
        if (this.blockEvents) {
          if (!matchedEvent) {
            return null;
          }
        }
        if (this.blockEventAttributes) {
          if (matchedEvent === true) {
            return clonedEvent;
          }
          if (matchedEvent) {
            for (var _i = 0, _a2 = Object.keys(clonedEvent.EventAttributes); _i < _a2.length; _i++) {
              var key = _a2[_i];
              if (!matchedEvent[key]) {
                delete clonedEvent.EventAttributes[key];
              }
            }
            return clonedEvent;
          } else {
            return clonedEvent;
          }
        }
        return clonedEvent;
      };
      KitBlocker2.prototype.transformProductAttributes = function(event) {
        var _a2;
        var clonedEvent = __assign({}, event);
        var baseEvent = convertEvent(clonedEvent);
        var matchKey = this.getProductAttributeMatchKey(baseEvent);
        var matchedEvent = this.dataPlanMatchLookups[matchKey];
        function removeAttribute(matchedEvent2, productList) {
          productList.forEach(function(product) {
            for (var _i = 0, _a3 = Object.keys(product.Attributes); _i < _a3.length; _i++) {
              var productKey = _a3[_i];
              if (!matchedEvent2[productKey]) {
                delete product.Attributes[productKey];
              }
            }
          });
        }
        if (this.blockEvents) {
          if (!matchedEvent) {
            return null;
          }
        }
        if (this.blockEventAttributes) {
          if (matchedEvent === true) {
            return clonedEvent;
          }
          if (matchedEvent) {
            switch (event.EventCategory) {
              case Types.CommerceEventType.ProductImpression:
                clonedEvent.ProductImpressions.forEach(function(impression) {
                  removeAttribute(matchedEvent, impression === null || impression === void 0 ? void 0 : impression.ProductList);
                });
                break;
              case Types.CommerceEventType.ProductPurchase:
                removeAttribute(matchedEvent, (_a2 = clonedEvent.ProductAction) === null || _a2 === void 0 ? void 0 : _a2.ProductList);
                break;
              default:
                this.mpInstance.Logger.warning("Product Not Supported ");
            }
            return clonedEvent;
          } else {
            return clonedEvent;
          }
        }
        return clonedEvent;
      };
      KitBlocker2.prototype.transformUserAttributes = function(event) {
        var clonedEvent = __assign({}, event);
        if (this.blockUserAttributes) {
          var matchedAttributes = this.dataPlanMatchLookups["user_attributes"];
          if (this.mpInstance._Helpers.isObject(matchedAttributes)) {
            for (var _i = 0, _a2 = Object.keys(clonedEvent.UserAttributes); _i < _a2.length; _i++) {
              var ua = _a2[_i];
              if (!matchedAttributes[ua]) {
                delete clonedEvent.UserAttributes[ua];
              }
            }
          }
        }
        return clonedEvent;
      };
      KitBlocker2.prototype.isAttributeKeyBlocked = function(key) {
        if (!this.blockUserAttributes) {
          return false;
        }
        var matchedAttributes = this.dataPlanMatchLookups["user_attributes"];
        if (typeof matchedAttributes === "boolean" && matchedAttributes) {
          return false;
        }
        if (_typeof(matchedAttributes) === "object") {
          if (matchedAttributes[key] === true) {
            return false;
          } else {
            return true;
          }
        }
        return false;
      };
      KitBlocker2.prototype.isIdentityBlocked = function(key) {
        if (!this.blockUserIdentities) {
          return false;
        }
        if (this.blockUserIdentities) {
          var matchedIdentities = this.dataPlanMatchLookups["user_identities"];
          if (matchedIdentities === true) {
            return false;
          }
          if (!matchedIdentities[key]) {
            return true;
          }
        } else {
          return false;
        }
        return false;
      };
      KitBlocker2.prototype.transformUserIdentities = function(event) {
        var _this = this;
        var _a2;
        var clonedEvent = __assign({}, event);
        if (this.blockUserIdentities) {
          var matchedIdentities_1 = this.dataPlanMatchLookups["user_identities"];
          if (this.mpInstance._Helpers.isObject(matchedIdentities_1)) {
            if ((_a2 = clonedEvent === null || clonedEvent === void 0 ? void 0 : clonedEvent.UserIdentities) === null || _a2 === void 0 ? void 0 : _a2.length) {
              clonedEvent.UserIdentities.forEach(function(uiByType, i) {
                var identityName = Types.IdentityType.getIdentityName(_this.mpInstance._Helpers.parseNumber(uiByType.Type));
                if (!matchedIdentities_1[identityName]) {
                  clonedEvent.UserIdentities.splice(i, 1);
                }
              });
            }
          }
        }
        return clonedEvent;
      };
      return KitBlocker2;
    })()
  );
  var buildUrl = function buildUrl2(configUrl, apiKey, dataPlanConfig, isDevelopmentMode) {
    var url = configUrl + apiKey + "/config";
    var env = isDevelopmentMode ? "1" : "0";
    var queryParams = ["env=".concat(env)];
    var _a2 = dataPlanConfig || {}, planId = _a2.planId, planVersion = _a2.planVersion;
    if (planId) {
      queryParams.push("plan_id=".concat(planId));
    }
    if (planVersion) {
      queryParams.push("plan_version=".concat(planVersion));
    }
    return "".concat(url, "?").concat(queryParams.join("&"));
  };
  function ConfigAPIClient(apiKey, config, mpInstance) {
    var _this = this;
    var baseUrl = "https://" + mpInstance._Store.SDKConfig.configUrl;
    var isDevelopmentMode = config.isDevelopmentMode;
    var dataPlan = config.dataPlan;
    var uploadUrl = buildUrl(baseUrl, apiKey, dataPlan, isDevelopmentMode);
    var uploader = window.fetch ? new FetchUploader(uploadUrl) : new XHRUploader(uploadUrl);
    this.getSDKConfiguration = function() {
      return __awaiter(_this, void 0, void 0, function() {
        var configResponse, fetchPayload, response, xhrResponse;
        var _a2, _b2, _c;
        return __generator(this, function(_d) {
          switch (_d.label) {
            case 0:
              fetchPayload = {
                method: "get",
                headers: {
                  Accept: "text/plain;charset=UTF-8",
                  "Content-Type": "text/plain;charset=UTF-8"
                },
                body: null
              };
              _d.label = 1;
            case 1:
              _d.trys.push([1, 6, , 7]);
              return [4, uploader.upload(fetchPayload)];
            case 2:
              response = _d.sent();
              if (!(response.status === 200)) return [3, 5];
              (_a2 = mpInstance === null || mpInstance === void 0 ? void 0 : mpInstance.Logger) === null || _a2 === void 0 ? void 0 : _a2.verbose("Successfully received configuration from server");
              if (!response.json) return [3, 4];
              return [4, response.json()];
            case 3:
              configResponse = _d.sent();
              return [2, configResponse];
            case 4:
              xhrResponse = response;
              configResponse = JSON.parse(xhrResponse.responseText);
              return [2, configResponse];
            case 5:
              (_b2 = mpInstance === null || mpInstance === void 0 ? void 0 : mpInstance.Logger) === null || _b2 === void 0 ? void 0 : _b2.verbose("Issue with receiving configuration from server, received HTTP Code of " + response.statusText);
              return [3, 7];
            case 6:
              _d.sent();
              (_c = mpInstance === null || mpInstance === void 0 ? void 0 : mpInstance.Logger) === null || _c === void 0 ? void 0 : _c.error("Error getting forwarder configuration from mParticle servers.");
              return [3, 7];
            case 7:
              return [2, config];
          }
        });
      });
    };
  }
  var HTTPCodes$1 = Constants.HTTPCodes, Messages$1 = Constants.Messages, IdentityMethods = Constants.IdentityMethods;
  var Modify = IdentityMethods.Modify;
  function IdentityAPIClient(mpInstance) {
    this.sendAliasRequest = function(aliasRequest, aliasCallback) {
      return __awaiter(this, void 0, void 0, function() {
        var Logger2, invokeAliasCallback, aliasUrl, apiKey, uploadUrl, uploader, uploadPayload, response, aliasResponseBody, message, errorMessage, _a2, xhrResponse, errorResponse, e_2, errorMessage;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              Logger2 = mpInstance.Logger;
              invokeAliasCallback = mpInstance._Helpers.invokeAliasCallback;
              aliasUrl = mpInstance._Store.SDKConfig.aliasUrl;
              apiKey = mpInstance._Store.devToken;
              Logger2.verbose(Messages$1.InformationMessages.SendAliasHttp);
              uploadUrl = "https://".concat(aliasUrl).concat(apiKey, "/Alias");
              uploader = window.fetch ? new FetchUploader(uploadUrl) : new XHRUploader(uploadUrl);
              uploadPayload = {
                method: "post",
                headers: {
                  Accept: "text/plain;charset=UTF-8",
                  "Content-Type": "application/json"
                },
                body: JSON.stringify(aliasRequest)
              };
              _b2.label = 1;
            case 1:
              _b2.trys.push([1, 13, , 14]);
              return [4, uploader.upload(uploadPayload)];
            case 2:
              response = _b2.sent();
              aliasResponseBody = void 0;
              message = void 0;
              errorMessage = void 0;
              _a2 = response.status;
              switch (_a2) {
                case HTTP_ACCEPTED:
                  return [3, 3];
                case HTTP_OK:
                  return [3, 3];
                case HTTP_BAD_REQUEST:
                  return [3, 4];
              }
              return [3, 11];
            case 3:
              message = "Received Alias Response from server: " + JSON.stringify(response.status);
              return [3, 12];
            case 4:
              if (!response.json) return [3, 9];
              _b2.label = 5;
            case 5:
              _b2.trys.push([5, 7, , 8]);
              return [4, response.json()];
            case 6:
              aliasResponseBody = _b2.sent();
              return [3, 8];
            case 7:
              _b2.sent();
              Logger2.verbose("The request has no response body");
              return [3, 8];
            case 8:
              return [3, 10];
            case 9:
              xhrResponse = response;
              aliasResponseBody = xhrResponse.responseText ? JSON.parse(xhrResponse.responseText) : "";
              _b2.label = 10;
            case 10:
              errorResponse = aliasResponseBody;
              if (errorResponse === null || errorResponse === void 0 ? void 0 : errorResponse.message) {
                errorMessage = errorResponse.message;
              }
              message = "Issue with sending Alias Request to mParticle Servers, received HTTP Code of " + response.status;
              if (errorResponse === null || errorResponse === void 0 ? void 0 : errorResponse.code) {
                message += " - " + errorResponse.code;
              }
              return [3, 12];
            case 11: {
              throw new Error("Received HTTP Code of " + response.status);
            }
            case 12:
              Logger2.verbose(message);
              invokeAliasCallback(aliasCallback, response.status, errorMessage);
              return [3, 14];
            case 13:
              e_2 = _b2.sent();
              errorMessage = getErrorMessage(e_2);
              Logger2.error("Error sending alias request to mParticle servers. " + errorMessage);
              invokeAliasCallback(aliasCallback, HTTPCodes$1.noHttpCoverage, errorMessage);
              return [3, 14];
            case 14:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    this.sendIdentityRequest = function(identityApiRequest, method, callback, originalIdentityApiData, parseIdentityResponse2, mpid, knownIdentities) {
      var _a2, _b2, _c, _d;
      return __awaiter(this, void 0, void 0, function() {
        var requestCount, invokeCallback, Logger2, errorReporter, previousMPID, uploadUrl, uploader, fetchPayload, response, identityResponse, message, _e, responseBody, errorResponse, errorMessage, responseText, isDevelopmentMode, responseToLog, errorMessage, requestCount, err_1, requestCount, errorMessage, msg;
        return __generator(this, function(_f) {
          switch (_f.label) {
            case 0:
              if ((_a2 = mpInstance._RoktManager) === null || _a2 === void 0 ? void 0 : _a2.isInitialized) {
                mpInstance._Store.identifyRequestCount = (mpInstance._Store.identifyRequestCount || 0) + 1;
                requestCount = mpInstance._Store.identifyRequestCount;
                mpInstance.captureTiming("".concat(requestCount, "-identityRequestStart"));
              }
              invokeCallback = mpInstance._Helpers.invokeCallback;
              Logger2 = mpInstance.Logger, errorReporter = mpInstance._ErrorReportingDispatcher;
              Logger2.verbose(Messages$1.InformationMessages.SendIdentityBegin);
              if (!identityApiRequest) {
                Logger2.error(Messages$1.ErrorMessages.APIRequestEmpty);
                return [
                  2
                  /*return*/
                ];
              }
              Logger2.verbose(Messages$1.InformationMessages.SendIdentityHttp);
              if (mpInstance._Store.identityCallInFlight) {
                invokeCallback(callback, HTTPCodes$1.activeIdentityRequest, "There is currently an Identity request processing. Please wait for this to return before requesting again");
                return [
                  2
                  /*return*/
                ];
              }
              previousMPID = mpid || null;
              uploadUrl = this.getUploadUrl(method, mpid);
              uploader = window.fetch ? new FetchUploader(uploadUrl) : new XHRUploader(uploadUrl);
              fetchPayload = {
                method: "post",
                headers: {
                  Accept: "text/plain;charset=UTF-8",
                  "Content-Type": "application/json",
                  "x-mp-key": mpInstance._Store.devToken
                },
                body: JSON.stringify(identityApiRequest)
              };
              mpInstance._Store.identityCallInFlight = true;
              _f.label = 1;
            case 1:
              _f.trys.push([1, 9, , 10]);
              return [4, uploader.upload(fetchPayload)];
            case 2:
              response = _f.sent();
              identityResponse = void 0;
              message = void 0;
              _e = response.status;
              switch (_e) {
                case HTTP_ACCEPTED:
                  return [3, 3];
                case HTTP_OK:
                  return [3, 3];
                case HTTP_BAD_REQUEST:
                  return [3, 3];
              }
              return [3, 7];
            case 3:
              if (!response.json) return [3, 5];
              return [4, response.json()];
            case 4:
              responseBody = _f.sent();
              identityResponse = this.getIdentityResponseFromFetch(response, responseBody);
              return [3, 6];
            case 5:
              identityResponse = this.getIdentityResponseFromXHR(response);
              _f.label = 6;
            case 6:
              if (identityResponse.status === HTTP_BAD_REQUEST) {
                errorResponse = identityResponse.responseText;
                message = "Issue with sending Identity Request to mParticle Servers, received HTTP Code of " + identityResponse.status;
                if (errorResponse === null || errorResponse === void 0 ? void 0 : errorResponse.Errors) {
                  errorMessage = errorResponse.Errors.map(function(error) {
                    return error.message;
                  }).join(", ");
                  message += " - " + errorMessage;
                }
              } else if (Logger2.isVerbose()) {
                responseText = identityResponse.responseText;
                isDevelopmentMode = mpInstance._Store.SDKConfig.isDevelopmentMode;
                responseToLog = responseText;
                if (!isDevelopmentMode && (responseText === null || responseText === void 0 ? void 0 : responseText.matched_identities)) {
                  responseToLog = __assign(__assign({}, responseText), {
                    matched_identities: obfuscateData(responseText.matched_identities)
                  });
                }
                message = "Received Identity Response from server: " + JSON.stringify(responseToLog);
              }
              return [3, 8];
            case 7: {
              if (response.status >= HTTP_SERVER_ERROR) {
                throw new Error("Received HTTP Code of " + response.status);
              }
              mpInstance._Store.identityCallInFlight = false;
              mpInstance._Store.identityCallFailed = false;
              errorMessage = "Received HTTP Code of " + response.status;
              Logger2.error("Error sending identity request to servers - " + errorMessage);
              invokeCallback(callback, HTTPCodes$1.noHttpCoverage, errorMessage);
              return [
                2
                /*return*/
              ];
            }
            case 8:
              mpInstance._Store.identityCallInFlight = false;
              mpInstance._Store.identityCallFailed = false;
              if (message) {
                Logger2.verbose(message);
              }
              if ((_b2 = mpInstance._RoktManager) === null || _b2 === void 0 ? void 0 : _b2.isInitialized) {
                requestCount = mpInstance._Store.identifyRequestCount;
                mpInstance.captureTiming("".concat(requestCount, "-identityRequestEnd"));
              }
              parseIdentityResponse2(identityResponse, previousMPID, callback, originalIdentityApiData, method, knownIdentities, false);
              return [3, 10];
            case 9:
              err_1 = _f.sent();
              mpInstance._Store.identityCallInFlight = false;
              mpInstance._Store.identityCallFailed = true;
              if ((_c = mpInstance._RoktManager) === null || _c === void 0 ? void 0 : _c.isInitialized) {
                requestCount = mpInstance._Store.identifyRequestCount;
                mpInstance.captureTiming("".concat(requestCount, "-identityRequestEnd"));
              }
              errorMessage = getErrorMessage(err_1);
              msg = "Error sending identity request to servers - " + errorMessage;
              Logger2.error(msg);
              errorReporter === null || errorReporter === void 0 ? void 0 : errorReporter.report({
                message: msg,
                code: ErrorCodes.IDENTITY_REQUEST,
                severity: WSDKErrorSeverity.ERROR
              });
              (_d = mpInstance.processQueueOnIdentityFailure) === null || _d === void 0 ? void 0 : _d.call(mpInstance);
              invokeCallback(callback, HTTPCodes$1.noHttpCoverage, errorMessage);
              return [3, 10];
            case 10:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    this.getUploadUrl = function(method, mpid) {
      var uploadServiceUrl = mpInstance._Helpers.createServiceUrl(mpInstance._Store.SDKConfig.identityUrl);
      var uploadUrl = method === Modify ? uploadServiceUrl + mpid + "/" + method : uploadServiceUrl + method;
      return uploadUrl;
    };
    this.getIdentityResponseFromFetch = function(response, responseBody) {
      return {
        status: response.status,
        responseText: responseBody,
        cacheMaxAge: parseInt(response.headers.get(CACHE_HEADER)) || 0,
        expireTimestamp: 0
      };
    };
    this.getIdentityResponseFromXHR = function(response) {
      return {
        status: response.status,
        responseText: response.responseText ? JSON.parse(response.responseText) : {},
        cacheMaxAge: parseNumber(response.getResponseHeader(CACHE_HEADER) || ""),
        expireTimestamp: 0
      };
    };
  }
  var facebookClickIdProcessor = function facebookClickIdProcessor2(clickId, url, timestamp) {
    if (!clickId || !url) {
      return "";
    }
    var urlSegments = url === null || url === void 0 ? void 0 : url.split("//");
    if (!urlSegments) {
      return "";
    }
    var urlParts = urlSegments[1].split("/");
    var domainParts = urlParts[0].split(".");
    var subdomainIndex = 1;
    if (domainParts.length >= 3) {
      subdomainIndex = 2;
    }
    var _timestamp = timestamp || Date.now();
    return "fb.".concat(subdomainIndex, ".").concat(_timestamp, ".").concat(clickId);
  };
  var IntegrationOutputs = {
    CUSTOM_FLAGS: "custom_flags",
    PARTNER_IDENTITIES: "partner_identities",
    INTEGRATION_ATTRIBUTES: "integration_attributes"
  };
  var integrationMappingExternal = {
    // Facebook / Meta
    fbclid: {
      mappedKey: "Facebook.ClickId",
      processor: facebookClickIdProcessor,
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    _fbp: {
      mappedKey: "Facebook.BrowserId",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    _fbc: {
      mappedKey: "Facebook.ClickId",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    // Google
    gclid: {
      mappedKey: "GoogleEnhancedConversions.Gclid",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    gbraid: {
      mappedKey: "GoogleEnhancedConversions.Gbraid",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    wbraid: {
      mappedKey: "GoogleEnhancedConversions.Wbraid",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    // TIKTOK
    ttclid: {
      mappedKey: "TikTok.Callback",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    _ttp: {
      mappedKey: "tiktok_cookie_id",
      output: IntegrationOutputs.PARTNER_IDENTITIES
    },
    // Snapchat
    // https://businesshelp.snapchat.com/s/article/troubleshooting-click-id?language=en_US
    ScCid: {
      mappedKey: "SnapchatConversions.ClickId",
      output: IntegrationOutputs.CUSTOM_FLAGS
    },
    // Snapchat
    // https://developers.snap.com/api/marketing-api/Conversions-API/UsingTheAPI#sending-click-id
    _scid: {
      mappedKey: "SnapchatConversions.Cookie1",
      output: IntegrationOutputs.CUSTOM_FLAGS
    }
  };
  var integrationMappingRokt = {
    // Rokt
    // https://docs.rokt.com/developers/integration-guides/web/advanced/rokt-id-tag/
    // https://go.mparticle.com/work/SQDSDKS-7167
    rtid: {
      mappedKey: "passbackconversiontrackingid",
      output: IntegrationOutputs.INTEGRATION_ATTRIBUTES,
      moduleId: 1277
    },
    rclid: {
      mappedKey: "passbackconversiontrackingid",
      output: IntegrationOutputs.INTEGRATION_ATTRIBUTES,
      moduleId: 1277
    },
    RoktTransactionId: {
      mappedKey: "passbackconversiontrackingid",
      output: IntegrationOutputs.INTEGRATION_ATTRIBUTES,
      moduleId: 1277
    }
  };
  var IntegrationCapture = (
    /** @class */
    (function() {
      function IntegrationCapture2(captureMode) {
        this.initialTimestamp = Date.now();
        this.captureMode = captureMode;
        this.filteredPartnerIdentityMappings = this.filterMappings(IntegrationOutputs.PARTNER_IDENTITIES);
        this.filteredCustomFlagMappings = this.filterMappings(IntegrationOutputs.CUSTOM_FLAGS);
        this.filteredIntegrationAttributeMappings = this.filterMappings(IntegrationOutputs.INTEGRATION_ATTRIBUTES);
      }
      IntegrationCapture2.prototype.capture = function() {
        var queryParams = this.captureQueryParams() || {};
        var cookies = this.captureCookies() || {};
        var localStorage2 = this.captureLocalStorage() || {};
        if (queryParams["fbclid"] && cookies["_fbc"]) {
          delete cookies["_fbc"];
        }
        var hasQueryParamId = queryParams["rtid"] || queryParams["rclid"];
        var hasLocalStorageId = localStorage2["RoktTransactionId"];
        var hasCookieId = cookies["RoktTransactionId"];
        if (hasQueryParamId) {
          if (hasLocalStorageId) {
            delete localStorage2["RoktTransactionId"];
          }
          if (hasCookieId) {
            delete cookies["RoktTransactionId"];
          }
        } else if (hasLocalStorageId && hasCookieId) {
          delete cookies["RoktTransactionId"];
        }
        this.clickIds = __assign(__assign(__assign(__assign({}, this.clickIds), queryParams), localStorage2), cookies);
      };
      IntegrationCapture2.prototype.captureCookies = function() {
        var integrationKeys = this.getAllowedKeysForMode();
        var cookies = getCookies(integrationKeys);
        return this.applyProcessors(cookies, getHref(), this.initialTimestamp);
      };
      IntegrationCapture2.prototype.captureQueryParams = function() {
        var queryParams = this.getQueryParams();
        return this.applyProcessors(queryParams, getHref(), this.initialTimestamp);
      };
      IntegrationCapture2.prototype.captureLocalStorage = function() {
        var integrationKeys = this.getAllowedKeysForMode();
        var localStorageItems = {};
        for (var _i = 0, integrationKeys_1 = integrationKeys; _i < integrationKeys_1.length; _i++) {
          var key = integrationKeys_1[_i];
          var localStorageItem = localStorage.getItem(key);
          if (localStorageItem) {
            localStorageItems[key] = localStorageItem;
          }
        }
        return this.applyProcessors(localStorageItems, getHref(), this.initialTimestamp);
      };
      IntegrationCapture2.prototype.getQueryParams = function() {
        var integrationKeys = this.getAllowedKeysForMode();
        return queryStringParser(getHref(), integrationKeys);
      };
      IntegrationCapture2.prototype.getClickIdsAsCustomFlags = function() {
        return this.getClickIds(this.clickIds, this.filteredCustomFlagMappings);
      };
      IntegrationCapture2.prototype.getClickIdsAsPartnerIdentities = function() {
        return this.getClickIds(this.clickIds, this.filteredPartnerIdentityMappings);
      };
      IntegrationCapture2.prototype.getClickIdsAsIntegrationAttributes = function() {
        var _a2;
        var _b2, _c;
        var mappedClickIds = {};
        for (var key in this.clickIds) {
          if (this.clickIds.hasOwnProperty(key)) {
            var value = this.clickIds[key];
            var mappingKey = (_b2 = this.filteredIntegrationAttributeMappings[key]) === null || _b2 === void 0 ? void 0 : _b2.mappedKey;
            if (!isEmpty(mappingKey)) {
              var moduleId = (_c = this.filteredIntegrationAttributeMappings[key]) === null || _c === void 0 ? void 0 : _c.moduleId;
              if (moduleId && !mappedClickIds[moduleId]) {
                mappedClickIds[moduleId] = (_a2 = {}, _a2[mappingKey] = value, _a2);
              }
            }
          }
        }
        return mappedClickIds;
      };
      IntegrationCapture2.prototype.getClickIds = function(clickIds, mappingList) {
        var _a2;
        var mappedClickIds = {};
        if (!clickIds) {
          return mappedClickIds;
        }
        for (var key in clickIds) {
          if (clickIds.hasOwnProperty(key)) {
            var value = clickIds[key];
            var mappedKey = (_a2 = mappingList[key]) === null || _a2 === void 0 ? void 0 : _a2.mappedKey;
            if (!isEmpty(mappedKey)) {
              mappedClickIds[mappedKey] = value;
            }
          }
        }
        return mappedClickIds;
      };
      IntegrationCapture2.prototype.applyProcessors = function(clickIds, url, timestamp) {
        var _a2;
        var processedClickIds = {};
        var integrationKeys = this.getActiveIntegrationMapping();
        for (var key in clickIds) {
          if (clickIds.hasOwnProperty(key)) {
            var value = clickIds[key];
            var processor = (_a2 = integrationKeys[key]) === null || _a2 === void 0 ? void 0 : _a2.processor;
            processedClickIds[key] = processor ? processor(value, url, timestamp) : value;
          }
        }
        return processedClickIds;
      };
      IntegrationCapture2.prototype.filterMappings = function(outputType) {
        var filteredMappings = {};
        var integrationKeys = this.getActiveIntegrationMapping();
        for (var key in integrationKeys) {
          if (integrationKeys[key].output === outputType) {
            filteredMappings[key] = integrationKeys[key];
          }
        }
        return filteredMappings;
      };
      IntegrationCapture2.prototype.getAllowedKeysForMode = function() {
        return Object.keys(this.getActiveIntegrationMapping());
      };
      IntegrationCapture2.prototype.getActiveIntegrationMapping = function() {
        if (this.captureMode === Constants.CaptureIntegrationSpecificIdsV2Modes.RoktOnly) {
          return integrationMappingRokt;
        }
        if (this.captureMode === Constants.CaptureIntegrationSpecificIdsV2Modes.All) {
          return __assign(__assign({}, integrationMappingExternal), integrationMappingRokt);
        }
        return {};
      };
      return IntegrationCapture2;
    })()
  );
  var PASSBACK_CONVERSION_TRACKING_ID = "passbackconversiontrackingid";
  var ON_SHOPPABLE_ADS_READY_METHOD = "onShoppableAdsReady";
  var RoktManager = (
    /** @class */
    (function() {
      function RoktManager2() {
        this.kit = null;
        this.filters = {};
        this.currentUser = null;
        this.messageQueue = /* @__PURE__ */ new Map();
        this.sandbox = null;
        this.placementAttributesMapping = [];
        this.onReadyCallback = null;
        this.initialized = false;
        this.isShoppableAdsLoaded = false;
      }
      RoktManager2.prototype.setOnReadyCallback = function(callback) {
        this.onReadyCallback = callback;
      };
      RoktManager2.prototype.init = function(roktConfig, filteredUser, identityService, store, logger, options, captureTiming, errorReporter, loggingService, integrationCapture) {
        var _a2, _b2;
        var _c = roktConfig || {}, userAttributeFilters = _c.userAttributeFilters, settings = _c.settings;
        var _d = settings || {}, placementAttributesMapping = _d.placementAttributesMapping, hashedEmailUserIdentityType = _d.hashedEmailUserIdentityType;
        this.mappedEmailShaIdentityType = (_a2 = hashedEmailUserIdentityType === null || hashedEmailUserIdentityType === void 0 ? void 0 : hashedEmailUserIdentityType.toLowerCase()) !== null && _a2 !== void 0 ? _a2 : null;
        this.identityService = identityService;
        this.store = store;
        this.logger = logger;
        this.errorReporter = errorReporter;
        this.loggingService = loggingService;
        this.captureTiming = captureTiming;
        this.integrationCapture = integrationCapture;
        (_b2 = this.captureTiming) === null || _b2 === void 0 ? void 0 : _b2.call(this, PerformanceMarkType.JointSdkRoktKitInit);
        this.filters = {
          userAttributeFilters,
          filterUserAttributes: KitFilterHelper.filterUserAttributes,
          filteredUser
        };
        try {
          this.placementAttributesMapping = parseSettingsString(placementAttributesMapping);
        } catch (error) {
          this.logger.error("Error parsing placement attributes mapping from config: " + error);
        }
        var sandbox = (options === null || options === void 0 ? void 0 : options.sandbox) || false;
        var launcherOptions = normalizeRoktLauncherOptions(options === null || options === void 0 ? void 0 : options.launcherOptions);
        this.launcherOptions = __assign({
          sandbox
        }, launcherOptions);
        if (options === null || options === void 0 ? void 0 : options.domain) {
          this.domain = options.domain;
        }
        this.initialized = true;
      };
      Object.defineProperty(RoktManager2.prototype, "isInitialized", {
        get: function get() {
          return this.initialized;
        },
        enumerable: false,
        configurable: true
      });
      RoktManager2.prototype.attachKit = function(kit) {
        var _a2, _b2, _c, _d;
        this.kit = kit;
        if ((_a2 = kit.settings) === null || _a2 === void 0 ? void 0 : _a2.accountId) {
          this.store.setRoktAccountId(kit.settings.accountId);
        }
        if (kit.integrationName) {
          (_b2 = this.store) === null || _b2 === void 0 ? void 0 : _b2.setIntegrationName(kit.integrationName);
        }
        this.processMessageQueue();
        try {
          (_c = this.onReadyCallback) === null || _c === void 0 ? void 0 : _c.call(this);
        } catch (e) {
          (_d = this.logger) === null || _d === void 0 ? void 0 : _d.error("RoktManager: Error in onReadyCallback: " + e);
        }
      };
      RoktManager2.prototype.selectPlacements = function(options) {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r;
        return __awaiter(this, void 0, void 0, function() {
          var attributes, sandboxValue, mappedAttributes, attributesToLog, currentUserIdentities, currentEmail, newEmail, currentHashedEmail, newHashedEmail, isValidHashedEmailIdentityType, emailChanged, hashedEmailChanged, newIdentities, msg, msg, finalUserIdentities, timeOnSite, totalTimeOnSite, enrichedAttributes, hashedEmail, capturedAttrs, passbackId, enrichedOptions;
          var _this = this;
          return __generator(this, function(_s) {
            (_a2 = this.captureTiming) === null || _a2 === void 0 ? void 0 : _a2.call(this, PerformanceMarkType.JointSdkSelectPlacements);
            if (!this.isReady() || ((_b2 = this.store) === null || _b2 === void 0 ? void 0 : _b2.identityCallInFlight)) {
              return [2, this.deferredCall("selectPlacements", options)];
            }
            try {
              attributes = options.attributes;
              sandboxValue = (attributes === null || attributes === void 0 ? void 0 : attributes.sandbox) || null;
              mappedAttributes = this.mapPlacementAttributes(attributes, this.placementAttributesMapping);
              if ((_c = this.logger) === null || _c === void 0 ? void 0 : _c.isVerbose()) {
                attributesToLog = obfuscateDevData(attributes, (_e = (_d = this.store) === null || _d === void 0 ? void 0 : _d.SDKConfig) === null || _e === void 0 ? void 0 : _e.isDevelopmentMode);
                this.logger.verbose("mParticle.Rokt selectPlacements called with attributes:\n".concat(JSON.stringify(attributesToLog, null, 2)));
              }
              this.currentUser = this.identityService.getCurrentUser();
              currentUserIdentities = ((_g = (_f = this.currentUser) === null || _f === void 0 ? void 0 : _f.getUserIdentities()) === null || _g === void 0 ? void 0 : _g.userIdentities) || {};
              currentEmail = currentUserIdentities.email;
              newEmail = mappedAttributes.email;
              currentHashedEmail = void 0;
              newHashedEmail = void 0;
              isValidHashedEmailIdentityType = this.mappedEmailShaIdentityType && IdentityType.getIdentityType(this.mappedEmailShaIdentityType) !== false;
              if (isValidHashedEmailIdentityType) {
                currentHashedEmail = currentUserIdentities[this.mappedEmailShaIdentityType];
                newHashedEmail = mappedAttributes["emailsha256"] || mappedAttributes[this.mappedEmailShaIdentityType] || void 0;
              }
              emailChanged = this.hasIdentityChanged(currentEmail, newEmail);
              hashedEmailChanged = this.hasIdentityChanged(currentHashedEmail, newHashedEmail);
              newIdentities = {};
              if (emailChanged) {
                newIdentities.email = newEmail;
                if (newEmail) {
                  msg = "Email mismatch detected. Current email differs from email passed to selectPlacements call. Proceeding to call identify with email from selectPlacements call. Please verify your implementation.";
                  this.logger.warning(msg);
                  (_h = this.errorReporter) === null || _h === void 0 ? void 0 : _h.report({
                    message: msg,
                    code: ErrorCodes.IDENTITY_MISMATCH,
                    severity: WSDKErrorSeverity.WARNING
                  });
                }
              }
              if (hashedEmailChanged) {
                newIdentities[this.mappedEmailShaIdentityType] = newHashedEmail;
                msg = "emailsha256 mismatch detected. Current mParticle hashedEmail differs from hashedEmail passed to selectPlacements call. Proceeding to call identify with hashedEmail from selectPlacements call. Please verify your implementation.";
                this.logger.warning(msg);
                (_j = this.errorReporter) === null || _j === void 0 ? void 0 : _j.report({
                  message: msg,
                  code: ErrorCodes.IDENTITY_MISMATCH,
                  severity: WSDKErrorSeverity.WARNING
                });
              }
              if (!isEmpty(newIdentities)) {
                try {
                  this.identityService.identify({
                    userIdentities: __assign(__assign({}, currentUserIdentities), newIdentities)
                  }, function(result) {
                    var httpCode = Number(result === null || result === void 0 ? void 0 : result.httpCode);
                    if (httpCode && (httpCode >= 400 || httpCode < 0)) {
                      _this.logger.error("Background identify failed with HTTP " + httpCode);
                    }
                    _this.processMessageQueue();
                  });
                } catch (error) {
                  this.logger.error("Background identify threw an error: " + getErrorMessage(error));
                }
              }
              finalUserIdentities = __assign(__assign({}, currentUserIdentities), newIdentities);
              this.setUserAttributes(mappedAttributes);
              timeOnSite = (_l = (_k = this.store) === null || _k === void 0 ? void 0 : _k.getTimeOnSite) === null || _l === void 0 ? void 0 : _l.call(_k);
              totalTimeOnSite = (_o = (_m = this.store) === null || _m === void 0 ? void 0 : _m.getTotalTimeOnSite) === null || _o === void 0 ? void 0 : _o.call(_m);
              enrichedAttributes = __assign(__assign(__assign(__assign({}, mappedAttributes), sandboxValue !== null ? {
                sandbox: sandboxValue
              } : {}), timeOnSite ? {
                active_time_on_site_ms: timeOnSite
              } : {}), totalTimeOnSite ? {
                total_time_on_site_ms: totalTimeOnSite
              } : {});
              if (finalUserIdentities.email && !enrichedAttributes.email) {
                enrichedAttributes.email = finalUserIdentities.email;
              }
              if (isValidHashedEmailIdentityType) {
                hashedEmail = finalUserIdentities[this.mappedEmailShaIdentityType];
                if (hashedEmail && !enrichedAttributes.emailsha256 && !enrichedAttributes[this.mappedEmailShaIdentityType]) {
                  enrichedAttributes.emailsha256 = hashedEmail;
                }
              }
              if (!enrichedAttributes[PASSBACK_CONVERSION_TRACKING_ID]) {
                (_p = this.integrationCapture) === null || _p === void 0 ? void 0 : _p.capture();
                capturedAttrs = (_q = this.integrationCapture) === null || _q === void 0 ? void 0 : _q.getClickIdsAsIntegrationAttributes();
                passbackId = (_r = capturedAttrs === null || capturedAttrs === void 0 ? void 0 : capturedAttrs[PARTNER_MODULE_IDS.Rokt]) === null || _r === void 0 ? void 0 : _r[PASSBACK_CONVERSION_TRACKING_ID];
                if (passbackId) {
                  enrichedAttributes[PASSBACK_CONVERSION_TRACKING_ID] = passbackId;
                }
              }
              this.filters.filteredUser = this.currentUser || this.filters.filteredUser || null;
              enrichedOptions = __assign(__assign({}, options), {
                attributes: enrichedAttributes
              });
              return [2, this.kit.selectPlacements(enrichedOptions)];
            } catch (error) {
              return [2, Promise.reject(error instanceof Error ? error : new Error("Unknown error occurred"))];
            }
            return [
              2
              /*return*/
            ];
          });
        });
      };
      RoktManager2.prototype.hashAttributes = function(attributes) {
        return __awaiter(this, void 0, void 0, function() {
          var keys, hashPromises, results, hashedAttributes, _i, results_1, _a2, key, attributeValue, hashedValue, error_1;
          var _this = this;
          return __generator(this, function(_b2) {
            switch (_b2.label) {
              case 0:
                _b2.trys.push([0, 2, , 3]);
                if (!attributes || _typeof(attributes) !== "object") {
                  return [2, {}];
                }
                keys = Object.keys(attributes);
                if (keys.length === 0) {
                  return [2, {}];
                }
                hashPromises = keys.map(function(key2) {
                  return __awaiter(_this, void 0, void 0, function() {
                    var attributeValue2, hashedValue2;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          attributeValue2 = attributes[key2];
                          return [4, this.hashSha256(attributeValue2)];
                        case 1:
                          hashedValue2 = _a3.sent();
                          return [2, {
                            key: key2,
                            attributeValue: attributeValue2,
                            hashedValue: hashedValue2
                          }];
                      }
                    });
                  });
                });
                return [4, Promise.all(hashPromises)];
              case 1:
                results = _b2.sent();
                hashedAttributes = {};
                for (_i = 0, results_1 = results; _i < results_1.length; _i++) {
                  _a2 = results_1[_i], key = _a2.key, attributeValue = _a2.attributeValue, hashedValue = _a2.hashedValue;
                  hashedAttributes[key] = attributeValue;
                  if (hashedValue) {
                    hashedAttributes["".concat(key, "sha256")] = hashedValue;
                  }
                }
                return [2, hashedAttributes];
              case 2:
                error_1 = _b2.sent();
                this.logger.error("Failed to hashAttributes, returning an empty object: ".concat(getErrorMessage(error_1)));
                return [2, {}];
              case 3:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      RoktManager2.prototype.setExtensionData = function(extensionData) {
        if (!this.isReady()) {
          this.deferredCall("setExtensionData", extensionData);
          return;
        }
        try {
          this.kit.setExtensionData(extensionData);
        } catch (error) {
          throw new Error("Error setting extension data: " + getErrorMessage(error));
        }
      };
      RoktManager2.prototype.use = function(name) {
        if (!this.isReady()) {
          return this.deferredCall("use", name);
        }
        try {
          return this.kit.use(name);
        } catch (error) {
          return Promise.reject(error instanceof Error ? error : new Error("Error using extension: " + name));
        }
      };
      RoktManager2.prototype.terminate = function() {
        var _a2, _b2, _c;
        return __awaiter(this, void 0, void 0, function() {
          var error_2;
          return __generator(this, function(_d) {
            switch (_d.label) {
              case 0:
                if (!this.isReady()) {
                  (_a2 = this.logger) === null || _a2 === void 0 ? void 0 : _a2.verbose("mParticle.Rokt.terminate called before the Rokt kit was ready. Nothing to terminate.");
                  return [
                    2
                    /*return*/
                  ];
                }
                if (!isFunction(this.kit.terminate)) {
                  (_b2 = this.logger) === null || _b2 === void 0 ? void 0 : _b2.error("mParticle.Rokt.terminate is not supported by the attached Rokt Kit version.");
                  return [
                    2
                    /*return*/
                  ];
                }
                _d.label = 1;
              case 1:
                _d.trys.push([1, 3, , 4]);
                return [4, this.kit.terminate()];
              case 2:
                _d.sent();
                return [3, 4];
              case 3:
                error_2 = _d.sent();
                (_c = this.logger) === null || _c === void 0 ? void 0 : _c.error("Failed to terminate the Rokt launcher: ".concat(getErrorMessage(error_2)));
                return [3, 4];
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      RoktManager2.prototype.onShoppableAdsReady = function(callback) {
        if (!this.kit || !this.isShoppableAdsLoaded) {
          this.deferredCall("onShoppableAdsReady", callback);
          return;
        }
        try {
          this.kit.onShoppableAdsReady(callback);
        } catch (error) {
          this.logger.error("Failed to register onShoppableAdsReady callback: ".concat(getErrorMessage(error)));
        }
      };
      RoktManager2.prototype.flushOnShoppableAdsReadyMessageQueue = function(kit) {
        var _this = this;
        this.kit = kit;
        this.messageQueue.forEach(function(message, key) {
          var _a2;
          if (message.methodName === ON_SHOPPABLE_ADS_READY_METHOD) {
            try {
              kit.onShoppableAdsReady(message.payload);
            } catch (e) {
              (_a2 = _this.logger) === null || _a2 === void 0 ? void 0 : _a2.error("RoktManager: Error flushing onShoppableAdsReady: " + e);
            }
            _this.messageQueue["delete"](key);
          }
        });
        this.isShoppableAdsLoaded = true;
      };
      RoktManager2.prototype.hashSha256 = function(attribute) {
        return __awaiter(this, void 0, void 0, function() {
          var normalizedValue, error_3;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                if (attribute === null || attribute === void 0) {
                  this.logger.warning("hashSha256 received null/undefined as input");
                  return [2, attribute];
                }
                _a2.label = 1;
              case 1:
                _a2.trys.push([1, 3, , 4]);
                normalizedValue = String(attribute).trim().toLocaleLowerCase();
                return [4, this.sha256Hex(normalizedValue)];
              case 2:
                return [2, _a2.sent()];
              case 3:
                error_3 = _a2.sent();
                this.logger.error("Failed to hashSha256, returning undefined: ".concat(getErrorMessage(error_3)));
                return [2, void 0];
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      RoktManager2.prototype.getLocalSessionAttributes = function() {
        return this.store.getLocalSessionAttributes();
      };
      RoktManager2.prototype.setLocalSessionAttribute = function(key, value) {
        this.store.setLocalSessionAttribute(key, value);
      };
      RoktManager2.prototype.isReady = function() {
        return Boolean(this.kit && this.kit.launcher);
      };
      RoktManager2.prototype.setUserAttributes = function(attributes) {
        var reservedAttributes = ["sandbox"];
        var filteredAttributes = {};
        for (var key in attributes) {
          if (attributes.hasOwnProperty(key) && reservedAttributes.indexOf(key) === -1) {
            var value = attributes[key];
            filteredAttributes[key] = Array.isArray(value) ? JSON.stringify(value) : value;
          }
        }
        try {
          this.currentUser.setUserAttributes(filteredAttributes);
        } catch (error) {
          this.logger.error("Error setting user attributes: " + error);
        }
      };
      RoktManager2.prototype.mapPlacementAttributes = function(attributes, placementAttributesMapping) {
        var mappingLookup = {};
        for (var _i = 0, placementAttributesMapping_1 = placementAttributesMapping; _i < placementAttributesMapping_1.length; _i++) {
          var mapping = placementAttributesMapping_1[_i];
          mappingLookup[mapping.map] = mapping.value;
        }
        var mappedAttributes = {};
        for (var key in attributes) {
          if (attributes.hasOwnProperty(key)) {
            var newKey = mappingLookup[key] || key;
            mappedAttributes[newKey] = attributes[key];
          }
        }
        return mappedAttributes;
      };
      RoktManager2.prototype.onIdentityComplete = function() {
        if (this.isReady()) {
          this.currentUser = this.identityService.getCurrentUser();
          this.processMessageQueue();
        }
      };
      RoktManager2.prototype.processMessageQueue = function() {
        var _this = this;
        var _a2;
        if (!this.isReady() || this.messageQueue.size === 0) {
          return;
        }
        (_a2 = this.logger) === null || _a2 === void 0 ? void 0 : _a2.verbose("RoktManager: Processing ".concat(this.messageQueue.size, " queued messages"));
        var messagesToProcess = Array.from(this.messageQueue.values());
        this.messageQueue.clear();
        messagesToProcess.forEach(function(message) {
          var _a3, _b2, _c, _d;
          if (!(message.methodName in _this) || !isFunction(_this[message.methodName])) {
            (_a3 = _this.logger) === null || _a3 === void 0 ? void 0 : _a3.error("RoktManager: Method ".concat(message.methodName, " not found"));
            return;
          }
          if ((_b2 = _this.logger) === null || _b2 === void 0 ? void 0 : _b2.isVerbose()) {
            var payloadToLog = obfuscateDevData(message.payload, (_d = (_c = _this.store) === null || _c === void 0 ? void 0 : _c.SDKConfig) === null || _d === void 0 ? void 0 : _d.isDevelopmentMode);
            _this.logger.verbose("RoktManager: Processing queued message: ".concat(message.methodName, " with payload: ").concat(JSON.stringify(payloadToLog)));
          }
          var resolve = message.resolve;
          var reject = message.reject;
          var handleError = function handleError2(error) {
            var _a4;
            (_a4 = _this.logger) === null || _a4 === void 0 ? void 0 : _a4.error("RoktManager: Error processing message '".concat(message.methodName, "': ").concat(getErrorMessage(error)));
            if (reject) {
              reject(error);
            }
          };
          try {
            var result = _this[message.methodName](message.payload);
            Promise.resolve(result).then(function(resolvedResult) {
              if (resolve) {
                resolve(resolvedResult);
              }
            })["catch"](handleError);
          } catch (error) {
            handleError(error);
          }
        });
      };
      RoktManager2.prototype.queueMessage = function(message) {
        this.messageQueue.set(message.messageId, message);
      };
      RoktManager2.prototype.deferredCall = function(methodName, payload) {
        var _this = this;
        return new Promise(function(resolve, reject) {
          var messageId = "".concat(methodName, "_").concat(generateUniqueId());
          _this.queueMessage({
            messageId,
            methodName,
            payload,
            resolve,
            reject
          });
        });
      };
      RoktManager2.prototype.sha256Hex = function(input) {
        return __awaiter(this, void 0, void 0, function() {
          var encoder, encodedInput, digest;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                encoder = new TextEncoder();
                encodedInput = encoder.encode(input);
                return [4, crypto.subtle.digest("SHA-256", encodedInput)];
              case 1:
                digest = _a2.sent();
                return [2, this.arrayBufferToHex(digest)];
            }
          });
        });
      };
      RoktManager2.prototype.arrayBufferToHex = function(buffer) {
        var bytes = new Uint8Array(buffer);
        var hexString = "";
        for (var i = 0; i < bytes.length; i++) {
          var hexByte = bytes[i].toString(16).padStart(2, "0");
          hexString += hexByte;
        }
        return hexString;
      };
      RoktManager2.prototype.hasIdentityChanged = function(currentValue, newValue) {
        if (!newValue) {
          return false;
        }
        if (!currentValue) {
          return true;
        }
        if (currentValue !== newValue) {
          return true;
        }
        return false;
      };
      return RoktManager2;
    })()
  );
  var CookieConsentManager = (
    /** @class */
    (function() {
      function CookieConsentManager2(flags) {
        this.flags = flags;
        this.flags = {
          noFunctional: flags.noFunctional === true,
          noTargeting: flags.noTargeting === true
        };
      }
      CookieConsentManager2.prototype.getNoTargeting = function() {
        return this.flags.noTargeting;
      };
      CookieConsentManager2.prototype.getNoFunctional = function() {
        return this.flags.noFunctional;
      };
      CookieConsentManager2.prototype.syncNoTargetingAttribute = function(user) {
        if (!user) return;
        if (this.flags.noTargeting) {
          user.setUserAttribute(NO_TARGETING_ATTRIBUTE, true);
        } else if (user.getAllUserAttributes().hasOwnProperty(NO_TARGETING_ATTRIBUTE)) {
          user.removeUserAttribute(NO_TARGETING_ATTRIBUTE);
        }
      };
      return CookieConsentManager2;
    })()
  );
  var ErrorReportingDispatcher = (
    /** @class */
    (function() {
      function ErrorReportingDispatcher2() {
        this.services = [];
      }
      ErrorReportingDispatcher2.prototype.register = function(service) {
        this.services.push(service);
      };
      ErrorReportingDispatcher2.prototype.report = function(error) {
        var _this = this;
        this.services.forEach(function(s) {
          var _a2;
          try {
            s.report(error);
          } catch (e) {
            (_a2 = _this.logger) === null || _a2 === void 0 ? void 0 : _a2.error("Error in ErrorReportingService: " + e);
          }
        });
      };
      return ErrorReportingDispatcher2;
    })()
  );
  var LoggingDispatcher = (
    /** @class */
    (function() {
      function LoggingDispatcher2() {
        this.services = [];
      }
      LoggingDispatcher2.prototype.register = function(service) {
        this.services.push(service);
      };
      LoggingDispatcher2.prototype.log = function(entry) {
        var _this = this;
        this.services.forEach(function(s) {
          var _a2;
          try {
            s.log(entry);
          } catch (e) {
            (_a2 = _this.logger) === null || _a2 === void 0 ? void 0 : _a2.error("Error in LoggingService: " + e);
          }
        });
      };
      return LoggingDispatcher2;
    })()
  );
  var Messages = Constants.Messages, HTTPCodes = Constants.HTTPCodes, FeatureFlags = Constants.FeatureFlags, CaptureIntegrationSpecificIdsV2Modes = Constants.CaptureIntegrationSpecificIdsV2Modes;
  var ReportBatching = FeatureFlags.ReportBatching, CaptureIntegrationSpecificIds = FeatureFlags.CaptureIntegrationSpecificIds, CaptureIntegrationSpecificIdsV2 = FeatureFlags.CaptureIntegrationSpecificIdsV2;
  var StartingInitialization = Messages.InformationMessages.StartingInitialization;
  function mParticleInstance(instanceName) {
    var self = this;
    this._instanceName = instanceName;
    this._NativeSdkHelpers = new NativeSdkHelpers(this);
    this._SessionManager = new SessionManager(this);
    this._Persistence = new _Persistence(this);
    this._Helpers = new Helpers(this);
    this._Events = new Events(this);
    this._CookieSyncManager = new CookieSyncManager(this);
    this._ServerModel = new ServerModel(this);
    this._Ecommerce = new Ecommerce(this);
    this._ForwardingStatsUploader = new forwardingStatsUploader(this);
    this._Consent = new Consent(this);
    this._IdentityAPIClient = new IdentityAPIClient(this);
    this._preInit = {
      readyQueue: [],
      integrationDelays: {},
      forwarderConstructors: []
    };
    this._ErrorReportingDispatcher = new ErrorReportingDispatcher();
    this._LoggingDispatcher = new LoggingDispatcher();
    this._RoktManager = new RoktManager();
    this._RoktManager.setOnReadyCallback(function() {
      self.processQueueOnIdentityFailure();
    });
    this.processQueueOnIdentityFailure = function() {
      var _a2, _b2, _c;
      if ((_a2 = self._Store) === null || _a2 === void 0 ? void 0 : _a2.isInitialized) {
        return;
      }
      if (((_b2 = self._Store) === null || _b2 === void 0 ? void 0 : _b2.identityCallFailed) && ((_c = self._RoktManager) === null || _c === void 0 ? void 0 : _c.isReady())) {
        self._RoktManager.processMessageQueue();
        self._preInit.readyQueue = processReadyQueue(self._preInit.readyQueue, self.Logger);
      }
    };
    this.processQueueOnNoFunctional = function() {
      var _a2, _b2;
      if ((_a2 = self._Store) === null || _a2 === void 0 ? void 0 : _a2.isInitialized) {
        return;
      }
      var noFunctionalWithoutId = ((_b2 = self._CookieConsentManager) === null || _b2 === void 0 ? void 0 : _b2.getNoFunctional()) && !hasExplicitIdentifier(self._Store);
      if (noFunctionalWithoutId) {
        self._preInit.readyQueue = processReadyQueue(self._preInit.readyQueue, self.Logger);
      }
    };
    this.IdentityType = IdentityType;
    this.EventType = EventType;
    this.CommerceEventType = CommerceEventType;
    this.PromotionType = PromotionActionType;
    this.ProductActionType = ProductActionType;
    this.RoktEvents = RoktEvents;
    this._Identity = new Identity(this);
    this.Identity = this._Identity.IdentityAPI;
    this.generateHash = this._Helpers.generateHash;
    this.getDeviceId = this._Persistence.getDeviceId;
    if (typeof window !== "undefined") {
      if (window.mParticle && window.mParticle.config) {
        if (window.mParticle.config.hasOwnProperty("rq")) {
          this._preInit.readyQueue = window.mParticle.config.rq;
        }
      }
    }
    this.init = function(apiKey, config) {
      var _this = this;
      if (!config) {
        console.warn("You did not pass a config object to init(). mParticle will not initialize properly");
      }
      runPreConfigFetchInitialization(this, apiKey, config);
      if (config) {
        if (!config.hasOwnProperty("requestConfig") || config.requestConfig) {
          var configApiClient = new ConfigAPIClient(apiKey, config, this);
          configApiClient.getSDKConfiguration().then(function(result) {
            var mergedConfig = extend({}, config, result);
            completeSDKInitialization(apiKey, mergedConfig, _this);
          });
        } else {
          completeSDKInitialization(apiKey, config, this);
        }
      } else {
        console.error("No config available on the window, please pass a config object to mParticle.init()");
        return;
      }
    };
    this.setLogLevel = function(newLogLevel) {
      self.Logger.setLogLevel(newLogLevel);
    };
    this.reset = function(instance) {
      try {
        instance._Persistence.resetPersistence();
        if (instance._Store) {
          delete instance._Store;
        }
      } catch (error) {
        console.error("Cannot reset mParticle", error);
      }
    };
    this._resetForTests = function(config, keepPersistence, instance) {
      if (instance._Store) {
        delete instance._Store;
      }
      instance._ErrorReportingDispatcher = new ErrorReportingDispatcher();
      instance._LoggingDispatcher = new LoggingDispatcher();
      instance.Logger = new Logger(config);
      instance._ErrorReportingDispatcher.logger = instance.Logger;
      instance._LoggingDispatcher.logger = instance.Logger;
      instance._Store = new Store(config, instance);
      instance._Store.isLocalStorageAvailable = instance._Persistence.determineLocalStorageAvailability(window.localStorage);
      instance._Events.stopTracking();
      resetPageViewTracking();
      instance._PageViewTracker = void 0;
      if (!keepPersistence) {
        instance._Persistence.resetPersistence();
      }
      instance._Persistence.forwardingStatsBatches.uploadsTable = {};
      instance._Persistence.forwardingStatsBatches.forwardingStatsEventQueue = [];
      instance._preInit = {
        readyQueue: [],
        pixelConfigurations: [],
        integrationDelays: {},
        forwarderConstructors: [],
        isDevelopmentMode: false
      };
    };
    this.ready = function(f) {
      var _a2, _b2, _c;
      var noFunctionalWithoutId = ((_a2 = self._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(self._Store);
      var shouldExecute = isFunction(f) && (((_b2 = self._Store) === null || _b2 === void 0 ? void 0 : _b2.isInitialized) || ((_c = self._Store) === null || _c === void 0 ? void 0 : _c.identityCallFailed) && self._RoktManager.isReady() || noFunctionalWithoutId);
      if (shouldExecute) {
        f();
      } else {
        self._preInit.readyQueue.push(f);
      }
    };
    this.getEnvironment = function() {
      return self._Store.SDKConfig.isDevelopmentMode ? Constants.Environment.Development : Constants.Environment.Production;
    };
    this.getVersion = function() {
      return Constants.sdkVersion;
    };
    this.setAppVersion = function(version2) {
      var queued = queueIfNotInitialized(function() {
        self.setAppVersion(version2);
      }, self);
      if (queued) return;
      self._Store.SDKConfig.appVersion = version2;
      self._Persistence.update();
    };
    this.setDeviceId = function(guid) {
      var queued = queueIfNotInitialized(function() {
        self.setDeviceId(guid);
      }, self);
      if (queued) return;
      this._Store.setDeviceId(guid);
    };
    this.isInitialized = function() {
      return self._Store ? self._Store.isInitialized : false;
    };
    this.getAppName = function() {
      return self._Store.SDKConfig.appName;
    };
    this.setAppName = function(name) {
      var queued = queueIfNotInitialized(function() {
        self.setAppName(name);
      }, self);
      if (queued) return;
      self._Store.SDKConfig.appName = name;
    };
    this.getAppVersion = function() {
      return self._Store.SDKConfig.appVersion;
    };
    this.stopTrackingLocation = function() {
      self._SessionManager.resetSessionTimer();
      self._Events.stopTracking();
    };
    this.startTrackingLocation = function(callback) {
      if (!isFunction(callback)) {
        self.Logger.warning("Warning: Location tracking is triggered, but not including a callback into the `startTrackingLocation` may result in events logged too quickly and not being associated with a location.");
      }
      self._SessionManager.resetSessionTimer();
      self._Events.startTracking(callback);
    };
    this.setPosition = function(lat, lng) {
      var queued = queueIfNotInitialized(function() {
        self.setPosition(lat, lng);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      if (typeof lat === "number" && typeof lng === "number") {
        self._Store.currentPosition = {
          lat,
          lng
        };
      } else {
        self.Logger.error("Position latitude and/or longitude must both be of type number");
      }
    };
    this.startNewSession = function() {
      self._SessionManager.startNewSession();
    };
    this.endSession = function() {
      self._SessionManager.endSession(true);
    };
    this.logBaseEvent = function(event, eventOptions) {
      var queued = queueIfNotInitialized(function() {
        self.logBaseEvent(event, eventOptions);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      if (typeof event.name !== "string") {
        self.Logger.error(Messages.ErrorMessages.EventNameInvalidType);
        return;
      }
      if (!event.eventType) {
        event.eventType = EventType.Unknown;
      }
      if (!self._Helpers.canLog()) {
        self.Logger.error(Messages.ErrorMessages.LoggingDisabled);
        return;
      }
      self._Events.logEvent(event, eventOptions);
    };
    this.logEvent = function(eventName, eventType, eventInfo, customFlags, eventOptions) {
      var queued = queueIfNotInitialized(function() {
        self.logEvent(eventName, eventType, eventInfo, customFlags, eventOptions);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      if (typeof eventName !== "string") {
        self.Logger.error(Messages.ErrorMessages.EventNameInvalidType);
        return;
      }
      if (!eventType) {
        eventType = EventType.Unknown;
      }
      if (!self._Helpers.isEventType(eventType)) {
        self.Logger.error("Invalid event type: " + eventType + ", must be one of: \n" + JSON.stringify(EventType));
        return;
      }
      if (!self._Helpers.canLog()) {
        self.Logger.error(Messages.ErrorMessages.LoggingDisabled);
        return;
      }
      self._Events.logEvent({
        messageType: MessageType$1.PageEvent,
        name: eventName,
        data: eventInfo,
        eventType,
        customFlags
      }, eventOptions);
    };
    this.logError = function(error, attrs) {
      var queued = queueIfNotInitialized(function() {
        self.logError(error, attrs);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      if (!error) {
        return;
      }
      if (typeof error === "string") {
        error = {
          message: error
        };
      }
      var data = {
        m: error.message ? error.message : error,
        s: "Error",
        t: error.stack || null
      };
      if (attrs) {
        var sanitized = self._Helpers.sanitizeAttributes(attrs, data.m);
        for (var prop in sanitized) {
          data[prop] = sanitized[prop];
        }
      }
      self._Events.logEvent({
        messageType: MessageType$1.CrashReport,
        name: error.name ? error.name : "Error",
        eventType: EventType.Other,
        data
      });
    };
    this.logLink = function(selector, eventName, eventType, eventInfo) {
      self._Events.addEventHandler("click", selector, eventName, eventInfo, eventType);
    };
    this.logForm = function(selector, eventName, eventType, eventInfo) {
      self._Events.addEventHandler("submit", selector, eventName, eventInfo, eventType);
    };
    this.logPageView = function(eventName, attrs, customFlags, eventOptions) {
      var queued = queueIfNotInitialized(function() {
        self.logPageView(eventName, attrs, customFlags, eventOptions);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      if (self._Helpers.canLog()) {
        if (!self._Helpers.Validators.isStringOrNumber(eventName)) {
          eventName = "PageView";
        }
        if (!attrs) {
          attrs = {
            hostname: window.location.hostname,
            title: window.document.title
          };
        } else if (!self._Helpers.isObject(attrs)) {
          self.Logger.error("The attributes argument must be an object. A " + _typeof(attrs) + " was entered. Please correct and retry.");
          return;
        }
        if (customFlags && !self._Helpers.isObject(customFlags)) {
          self.Logger.error("The customFlags argument must be an object. A " + _typeof(customFlags) + " was entered. Please correct and retry.");
          return;
        }
      }
      self._Events.logEvent({
        messageType: MessageType$1.PageView,
        name: eventName,
        data: attrs,
        eventType: EventType.Unknown,
        customFlags
      }, eventOptions);
    };
    this.upload = function() {
      var _a2, _b2;
      if (self._Helpers.canLog()) {
        if (self._Store.webviewBridgeEnabled) {
          self._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.Upload);
        } else {
          (_b2 = (_a2 = self._APIClient) === null || _a2 === void 0 ? void 0 : _a2.uploader) === null || _b2 === void 0 ? void 0 : _b2.prepareAndUpload(false, false);
        }
      }
    };
    this.Consent = {
      /**
       * Creates a CCPA Opt Out Consent State.
       *
       * @method createCCPAConsent
       * @param {Boolean} optOut true represents a "data sale opt-out", false represents the user declining a "data sale opt-out"
       * @param {Number} timestamp Unix time (likely to be Date.now())
       * @param {String} consentDocument document version or experience that the user may have consented to
       * @param {String} location location where the user gave consent
       * @param {String} hardwareId hardware ID for the device or browser used to give consent. This property exists only to provide additional context and is not used to identify users
       * @return {Object} CCPA Consent State
       */
      createCCPAConsent: self._Consent.createPrivacyConsent,
      /**
       * Creates a GDPR Consent State.
       *
       * @method createGDPRConsent
       * @param {Boolean} consent true represents a "data sale opt-out", false represents the user declining a "data sale opt-out"
       * @param {Number} timestamp Unix time (likely to be Date.now())
       * @param {String} consentDocument document version or experience that the user may have consented to
       * @param {String} location location where the user gave consent
       * @param {String} hardwareId hardware ID for the device or browser used to give consent. This property exists only to provide additional context and is not used to identify users
       * @return {Object} GDPR Consent State
       */
      createGDPRConsent: self._Consent.createPrivacyConsent,
      /**
       * Creates a Consent State Object, which can then be used to set CCPA states, add multiple GDPR states, as well as get and remove these privacy states.
       *
       * @method createConsentState
       * @return {Object} ConsentState object
       */
      createConsentState: self._Consent.createConsentState
    };
    this.eCommerce = {
      /**
       * Invoke these methods on the mParticle.eCommerce.Cart object.
       * Example: mParticle.eCommerce.Cart.add(...)
       * @class mParticle.eCommerce.Cart
       * @deprecated
       */
      Cart: {
        /**
         * Adds a product to the cart
         * @method add
         * @param {Object} product The product you want to add to the cart
         * @param {Boolean} [logEventBoolean] Option to log the event to mParticle's servers. If blank, no logging occurs.
         * @deprecated
         */
        add: function add(product, logEventBoolean) {
          logDeprecatedMethodUsage({
            methodName: "mPInstance.eCommerce.Cart.add()",
            warningMessage: generateDeprecationMessage("eCommerce.Cart.add()", true, "eCommerce.logProductAction()", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, self.Logger, self._ErrorReportingDispatcher);
        },
        /**
         * Removes a product from the cart
         * @method remove
         * @param {Object} product The product you want to add to the cart
         * @param {Boolean} [logEventBoolean] Option to log the event to mParticle's servers. If blank, no logging occurs.
         * @deprecated
         */
        remove: function remove(product, logEventBoolean) {
          logDeprecatedMethodUsage({
            methodName: "mPInstance.eCommerce.Cart.remove()",
            warningMessage: generateDeprecationMessage("eCommerce.Cart.remove()", true, "eCommerce.logProductAction()", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, self.Logger, self._ErrorReportingDispatcher);
        },
        /**
         * Clears the cart
         * @method clear
         * @deprecated
         */
        clear: function clear() {
          logDeprecatedMethodUsage({
            methodName: "mPInstance.eCommerce.Cart.clear()",
            warningMessage: generateDeprecationMessage("eCommerce.Cart.clear()", true, "", "https://docs.mparticle.com/developers/sdk/web/commerce-tracking")
          }, self.Logger, self._ErrorReportingDispatcher);
        }
      },
      /**
       * Sets the currency code
       * @for mParticle.eCommerce
       * @method setCurrencyCode
       * @param {String} code The currency code
       */
      setCurrencyCode: function setCurrencyCode(code) {
        var queued = queueIfNotInitialized(function() {
          self.eCommerce.setCurrencyCode(code);
        }, self);
        if (queued) return;
        if (typeof code !== "string") {
          self.Logger.error("Code must be a string");
          return;
        }
        self._SessionManager.resetSessionTimer();
        self._Store.currencyCode = code;
      },
      /**
       * Creates a product
       * @for mParticle.eCommerce
       * @method createProduct
       * @param {String} name product name
       * @param {String} sku product sku
       * @param {Number} price product price
       * @param {Number} [quantity] product quantity. If blank, defaults to 1.
       * @param {String} [variant] product variant
       * @param {String} [category] product category
       * @param {String} [brand] product brand
       * @param {Number} [position] product position
       * @param {String} [coupon] product coupon
       * @param {Object} [attributes] product attributes
       */
      createProduct: function createProduct(name, sku, price, quantity, variant, category, brand, position, coupon, attributes) {
        return self._Ecommerce.createProduct(name, sku, price, quantity, variant, category, brand, position, coupon, attributes);
      },
      /**
       * Creates a promotion
       * @for mParticle.eCommerce
       * @method createPromotion
       * @param {String} id a unique promotion id
       * @param {String} [creative] promotion creative
       * @param {String} [name] promotion name
       * @param {Number} [position] promotion position
       */
      createPromotion: function createPromotion(id, creative, name, position) {
        return self._Ecommerce.createPromotion(id, creative, name, position);
      },
      /**
       * Creates a product impression
       * @for mParticle.eCommerce
       * @method createImpression
       * @param {String} name impression name
       * @param {Object} product the product for which an impression is being created
       */
      createImpression: function createImpression(name, product) {
        return self._Ecommerce.createImpression(name, product);
      },
      /**
       * Creates a transaction attributes object to be used with a checkout
       * @for mParticle.eCommerce
       * @method createTransactionAttributes
       * @param {String or Number} id a unique transaction id
       * @param {String} [affiliation] affilliation
       * @param {String} [couponCode] the coupon code for which you are creating transaction attributes
       * @param {Number} [revenue] total revenue for the product being purchased
       * @param {String} [shipping] the shipping method
       * @param {Number} [tax] the tax amount
       */
      createTransactionAttributes: function createTransactionAttributes(id, affiliation, couponCode, revenue, shipping, tax) {
        return self._Ecommerce.createTransactionAttributes(id, affiliation, couponCode, revenue, shipping, tax);
      },
      /**
       * Logs a checkout action
       * @for mParticle.eCommerce
       * @method logCheckout
       * @param {Number} step checkout step number
       * @param {String} checkout option string
       * @param {Object} attrs
       * @param {Object} [customFlags] Custom flags for the event
       * @deprecated
       */
      logCheckout: function logCheckout(step, option, attrs, customFlags) {
        logDeprecatedMethodUsage({
          methodName: "mParticle.logCheckout",
          warningMessage: "mParticle.logCheckout is deprecated, please use mParticle.logProductAction instead"
        }, self.Logger, self._ErrorReportingDispatcher);
        if (!self._Store.isInitialized) {
          self.ready(function() {
            self.eCommerce.logCheckout(step, option, attrs, customFlags);
          });
          return;
        }
        self._SessionManager.resetSessionTimer();
        self._Events.logCheckoutEvent(step, option, attrs, customFlags);
      },
      /**
       * Logs a product action
       * @for mParticle.eCommerce
       * @method logProductAction
       * @param {Number} productActionType product action type as found [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/src/types.js#L206-L218)
       * @param {Object} product the product for which you are creating the product action
       * @param {Object} [attrs] attributes related to the product action
       * @param {Object} [customFlags] Custom flags for the event
       * @param {Object} [transactionAttributes] Transaction Attributes for the event
       * @param {Object} [eventOptions] For Event-level Configuration Options
       */
      logProductAction: function logProductAction(productActionType, product, attrs, customFlags, transactionAttributes, eventOptions) {
        var queued = queueIfNotInitialized(function() {
          self.eCommerce.logProductAction(productActionType, product, attrs, customFlags, transactionAttributes, eventOptions);
        }, self);
        if (queued) return;
        self._SessionManager.resetSessionTimer();
        self._Events.logProductActionEvent(productActionType, product, attrs, customFlags, transactionAttributes, eventOptions);
      },
      /**
       * Logs a product purchase
       * @for mParticle.eCommerce
       * @method logPurchase
       * @param {Object} transactionAttributes transactionAttributes object
       * @param {Object} product the product being purchased
       * @param {Boolean} [clearCart] boolean to clear the cart after logging or not. Defaults to false
       * @param {Object} [attrs] other attributes related to the product purchase
       * @param {Object} [customFlags] Custom flags for the event
       * @deprecated
       */
      logPurchase: function logPurchase(transactionAttributes, product, clearCart, attrs, customFlags) {
        logDeprecatedMethodUsage({
          methodName: "mParticle.logPurchase",
          warningMessage: "mParticle.logPurchase is deprecated, please use mParticle.logProductAction instead"
        }, self.Logger, self._ErrorReportingDispatcher);
        if (!self._Store.isInitialized) {
          self.ready(function() {
            self.eCommerce.logPurchase(transactionAttributes, product, clearCart, attrs, customFlags);
          });
          return;
        }
        if (!transactionAttributes || !product) {
          self.Logger.error(Messages.ErrorMessages.BadLogPurchase);
          return;
        }
        self._SessionManager.resetSessionTimer();
        self._Events.logPurchaseEvent(transactionAttributes, product, attrs, customFlags);
      },
      /**
       * Logs a product promotion
       * @for mParticle.eCommerce
       * @method logPromotion
       * @param {Number} type the promotion type as found [here](https://github.com/mParticle/mparticle-sdk-javascript/blob/master-v2/src/types.js#L275-L279)
       * @param {Object} promotion promotion object
       * @param {Object} [attrs] boolean to clear the cart after logging or not
       * @param {Object} [customFlags] Custom flags for the event
       * @param {Object} [eventOptions] For Event-level Configuration Options
       */
      logPromotion: function logPromotion(type, promotion, attrs, customFlags, eventOptions) {
        var queued = queueIfNotInitialized(function() {
          self.eCommerce.logPromotion(type, promotion, attrs, customFlags, eventOptions);
        }, self);
        if (queued) return;
        self._SessionManager.resetSessionTimer();
        self._Events.logPromotionEvent(type, promotion, attrs, customFlags, eventOptions);
      },
      /**
       * Logs a product impression
       * @for mParticle.eCommerce
       * @method logImpression
       * @param {Object} impression product impression object
       * @param {Object} attrs attributes related to the impression log
       * @param {Object} [customFlags] Custom flags for the event
       * @param {Object} [eventOptions] For Event-level Configuration Options
       */
      logImpression: function logImpression(impression, attrs, customFlags, eventOptions) {
        var queued = queueIfNotInitialized(function() {
          self.eCommerce.logImpression(impression, attrs, customFlags, eventOptions);
        }, self);
        if (queued) return;
        self._SessionManager.resetSessionTimer();
        self._Events.logImpressionEvent(impression, attrs, customFlags, eventOptions);
      },
      /**
       * Logs a refund
       * @for mParticle.eCommerce
       * @method logRefund
       * @param {Object} transactionAttributes transaction attributes related to the refund
       * @param {Object} product product being refunded
       * @param {Boolean} [clearCart] boolean to clear the cart after refund is logged. Defaults to false.
       * @param {Object} [attrs] attributes related to the refund
       * @param {Object} [customFlags] Custom flags for the event
       * @deprecated
       */
      logRefund: function logRefund(transactionAttributes, product, clearCart, attrs, customFlags) {
        logDeprecatedMethodUsage({
          methodName: "mParticle.logRefund",
          warningMessage: "mParticle.logRefund is deprecated, please use mParticle.logProductAction instead"
        }, self.Logger, self._ErrorReportingDispatcher);
        if (!self._Store.isInitialized) {
          self.ready(function() {
            self.eCommerce.logRefund(transactionAttributes, product, clearCart, attrs, customFlags);
          });
          return;
        }
        self._SessionManager.resetSessionTimer();
        self._Events.logRefundEvent(transactionAttributes, product, attrs, customFlags);
      },
      expandCommerceEvent: function expandCommerceEvent(event) {
        return self._Ecommerce.expandCommerceEvent(event);
      }
    };
    this.setSessionAttribute = function(key, value) {
      var _a2;
      var skipQueue = ((_a2 = self._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(self._Store);
      if (!skipQueue) {
        var queued = queueIfNotInitialized(function() {
          self.setSessionAttribute(key, value);
        }, self);
        if (queued) return;
      }
      if (self._Helpers.canLog()) {
        if (!self._Helpers.Validators.isValidAttributeValue(value)) {
          self.Logger.error(Messages.ErrorMessages.BadAttribute);
          return;
        }
        if (!self._Helpers.Validators.isValidKeyValue(key)) {
          self.Logger.error(Messages.ErrorMessages.BadKey);
          return;
        }
        if (self._Store.webviewBridgeEnabled) {
          self._NativeSdkHelpers.sendToNative(Constants.NativeSdkPaths.SetSessionAttribute, JSON.stringify({
            key,
            value
          }));
        } else {
          var existingProp = self._Helpers.findKeyInObject(self._Store.sessionAttributes, key);
          if (existingProp) {
            key = existingProp;
          }
          self._Store.sessionAttributes[key] = value;
          self._Persistence.update();
          self._Forwarders.applyToForwarders("setSessionAttribute", [key, value]);
        }
      }
    };
    this.setOptOut = function(isOptingOut) {
      var queued = queueIfNotInitialized(function() {
        self.setOptOut(isOptingOut);
      }, self);
      if (queued) return;
      self._SessionManager.resetSessionTimer();
      self._Store.isEnabled = !isOptingOut;
      self._Events.logOptOut();
      self._Persistence.update();
      if (self._Store.activeForwarders.length) {
        self._Store.activeForwarders.forEach(function(forwarder) {
          if (forwarder.setOptOut) {
            var result = forwarder.setOptOut(isOptingOut);
            if (result) {
              self.Logger.verbose(result);
            }
          }
        });
      }
    };
    this.setIntegrationAttribute = function(integrationId, attrs) {
      var queued = queueIfNotInitialized(function() {
        self.setIntegrationAttribute(integrationId, attrs);
      }, self);
      if (queued) return;
      if (typeof integrationId !== "number") {
        self.Logger.error("integrationId must be a number");
        return;
      }
      if (attrs === null) {
        self._Store.integrationAttributes[integrationId] = {};
      } else if (self._Helpers.isObject(attrs)) {
        if (Object.keys(attrs).length === 0) {
          self._Store.integrationAttributes[integrationId] = {};
        } else {
          for (var key in attrs) {
            if (typeof key === "string") {
              if (typeof attrs[key] === "string") {
                if (self._Helpers.isObject(self._Store.integrationAttributes[integrationId])) {
                  self._Store.integrationAttributes[integrationId][key] = attrs[key];
                } else {
                  self._Store.integrationAttributes[integrationId] = {};
                  self._Store.integrationAttributes[integrationId][key] = attrs[key];
                }
              } else {
                self.Logger.error("Values for integration attributes must be strings. You entered a " + _typeof(attrs[key]));
                continue;
              }
            } else {
              self.Logger.error("Keys must be strings, you entered a " + _typeof(key));
              continue;
            }
          }
        }
      } else {
        self.Logger.error("Attrs must be an object with keys and values. You entered a " + _typeof(attrs));
        return;
      }
      self._Persistence.update();
    };
    this.getIntegrationAttributes = function(integrationId) {
      if (self._Store.integrationAttributes[integrationId]) {
        return self._Store.integrationAttributes[integrationId];
      } else {
        return {};
      }
    };
    this.addForwarder = function(forwarder) {
      self._preInit.forwarderConstructors.push(forwarder);
    };
    this.configurePixel = function(settings) {
      self._Forwarders.configurePixel(settings);
    };
    this._getActiveForwarders = function() {
      return self._Store.activeForwarders;
    };
    this._getIntegrationDelays = function() {
      return self._preInit.integrationDelays;
    };
    this._setIntegrationDelay = function(module, shouldDelayIntegration) {
      self._preInit.integrationDelays[module] = shouldDelayIntegration;
      if (shouldDelayIntegration === true) {
        return;
      }
      var integrationDelaysKeys = Object.keys(self._preInit.integrationDelays);
      if (integrationDelaysKeys.length === 0) {
        return;
      }
      var hasIntegrationDelays = integrationDelaysKeys.some(function(integration) {
        return self._preInit.integrationDelays[integration] === true;
      });
      if (!hasIntegrationDelays) {
        self._APIClient.processQueuedEvents();
      }
    };
    this._setWrapperSDKInfo = function(name, version2) {
      var queued = queueIfNotInitialized(function() {
        self._setWrapperSDKInfo(name, version2);
      }, self);
      if (queued) return;
      if (self._Store.wrapperSDKInfo === void 0 || !self._Store.wrapperSDKInfo.isInfoSet) {
        self._Store.wrapperSDKInfo = {
          name,
          version: version2,
          isInfoSet: true
        };
      }
    };
    this._registerErrorReportingService = function(service) {
      self._ErrorReportingDispatcher.register(service);
    };
    this._registerLoggingService = function(service) {
      self._LoggingDispatcher.register(service);
    };
    var launcherInstanceGuidKey = Constants.Rokt.LauncherInstanceGuidKey;
    this.setLauncherInstanceGuid = function() {
      if (!window[launcherInstanceGuidKey] || typeof window[launcherInstanceGuidKey] !== "string") {
        window[launcherInstanceGuidKey] = self._Helpers.generateUniqueId();
      }
    };
    this.getLauncherInstanceGuid = function() {
      return window[launcherInstanceGuidKey];
    };
    this.captureTiming = function(metricsName) {
      var _a2;
      if (typeof window !== "undefined" && ((_a2 = window.performance) === null || _a2 === void 0 ? void 0 : _a2.mark)) {
        window.performance.mark(metricsName);
      }
    };
  }
  function completeSDKInitialization(apiKey, config, mpInstance) {
    var _a2, _b2, _c, _d;
    var kitBlocker = createKitBlocker(config, mpInstance);
    var getFeatureFlag = mpInstance._Helpers.getFeatureFlag;
    var AutoLogPageView = Constants.FeatureFlags.AutoLogPageView;
    if ((_a2 = mpInstance._APIClient) === null || _a2 === void 0 ? void 0 : _a2.uploader) {
      mpInstance._APIClient.uploader.destroy();
    }
    mpInstance._APIClient = new APIClient(mpInstance, kitBlocker);
    mpInstance._Forwarders = new Forwarders(mpInstance, kitBlocker);
    mpInstance._Store.processConfig(config);
    mpInstance._Identity.idCache = createIdentityCache(mpInstance);
    removeExpiredIdentityCacheDates(mpInstance._Identity.idCache);
    if (mpInstance._Store.webviewBridgeEnabled) {
      mpInstance._NativeSdkHelpers.initializeSessionAttributes(apiKey);
    } else {
      mpInstance._Persistence.initializeStorage();
      mpInstance._Store.syncPersistenceData();
      var currentUser = mpInstance.Identity.getCurrentUser();
      var currentUserMPID = currentUser ? currentUser.getMPID() : null;
      var currentUserIdentities = currentUser ? currentUser.getUserIdentities().userIdentities : {};
      mpInstance._Store.SDKConfig.identifyRequest = mpInstance._Store.hasInvalidIdentifyRequest() ? {
        userIdentities: currentUserIdentities
      } : mpInstance._Store.SDKConfig.identifyRequest;
      if (getFeatureFlag(ReportBatching)) {
        mpInstance._ForwardingStatsUploader.startForwardingStatsTimer();
      }
      var integrationSpecificIds = getFeatureFlag(CaptureIntegrationSpecificIds);
      var integrationSpecificIdsV2 = getFeatureFlag(CaptureIntegrationSpecificIdsV2);
      var isIntegrationCaptureEnabled = integrationSpecificIdsV2 && integrationSpecificIdsV2 !== CaptureIntegrationSpecificIdsV2Modes.None || integrationSpecificIds === true;
      if (isIntegrationCaptureEnabled) {
        var captureMode = void 0;
        if (integrationSpecificIds || integrationSpecificIdsV2 === CaptureIntegrationSpecificIdsV2Modes.All) {
          captureMode = "all";
        } else if (integrationSpecificIdsV2 === CaptureIntegrationSpecificIdsV2Modes.RoktOnly) {
          captureMode = "roktonly";
        }
        mpInstance._IntegrationCapture = new IntegrationCapture(captureMode);
        mpInstance._IntegrationCapture.capture();
      }
      var roktConfig = parseConfig(config, "Rokt", 181);
      if (roktConfig) {
        var accountId = (_b2 = roktConfig.settings) === null || _b2 === void 0 ? void 0 : _b2.accountId;
        mpInstance._Store.setRoktAccountId(accountId);
        var userAttributeFilters = roktConfig.userAttributeFilters;
        var roktFilteredUser = filteredMparticleUser(currentUserMPID, {
          userAttributeFilters
        }, mpInstance);
        var roktOptions = {
          sandbox: config === null || config === void 0 ? void 0 : config.isDevelopmentMode,
          launcherOptions: config === null || config === void 0 ? void 0 : config.launcherOptions,
          domain: config === null || config === void 0 ? void 0 : config.domain
        };
        mpInstance._RoktManager.init(roktConfig, roktFilteredUser, mpInstance.Identity, mpInstance._Store, mpInstance.Logger, roktOptions, mpInstance.captureTiming, mpInstance._ErrorReportingDispatcher, mpInstance._LoggingDispatcher, mpInstance._IntegrationCapture);
      }
      mpInstance._Forwarders.processForwarders(config, mpInstance._APIClient.prepareForwardingStats);
      mpInstance._Forwarders.processPixelConfigs(config);
      mpInstance._SessionManager.initialize();
      mpInstance._Events.logAST();
      if (getFeatureFlag(AutoLogPageView)) {
        if (!mpInstance._PageViewTracker) {
          mpInstance.Logger.verbose("mParticle APV: [sdk-init] creating new PageViewTracker for this instance");
          mpInstance._PageViewTracker = new PageViewTracker(mpInstance);
        }
        if (hasInitialPageViewFired()) {
          mpInstance.Logger.verbose("mParticle APV: [sdk-init] initial page view already logged this page load, skipping");
        } else {
          markInitialPageViewFired();
          mpInstance._Events.logPageView();
        }
        mpInstance._PageViewTracker.init();
      } else if (mpInstance._PageViewTracker) {
        mpInstance._PageViewTracker.teardown();
      }
      processIdentityCallback(mpInstance, currentUser, currentUserMPID, currentUserIdentities);
    }
    if (mpInstance._Store.mpid && !mpInstance._Store.identifyCalled || mpInstance._Store.webviewBridgeEnabled) {
      mpInstance._Store.isInitialized = true;
      (_c = mpInstance._CookieConsentManager) === null || _c === void 0 ? void 0 : _c.syncNoTargetingAttribute(mpInstance.Identity.getCurrentUser());
      mpInstance._preInit.readyQueue = processReadyQueue(mpInstance._preInit.readyQueue, mpInstance.Logger);
    }
    (_d = mpInstance.processQueueOnNoFunctional) === null || _d === void 0 ? void 0 : _d.call(mpInstance);
    if (mpInstance._Store.isFirstRun) {
      mpInstance._Store.isFirstRun = false;
    }
  }
  function createKitBlocker(config, mpInstance) {
    var kitBlocker;
    var dataPlanForKitBlocker;
    var kitBlockError;
    var kitBlockOptions;
    if (config.dataPlanOptions) {
      mpInstance.Logger.verbose("Customer provided data plan found");
      kitBlockOptions = config.dataPlanOptions;
      dataPlanForKitBlocker = {
        document: {
          dtpn: {
            vers: kitBlockOptions.dataPlanVersion,
            blok: {
              ev: kitBlockOptions.blockEvents,
              ea: kitBlockOptions.blockEventAttributes,
              ua: kitBlockOptions.blockUserAttributes,
              id: kitBlockOptions.blockUserIdentities
            }
          }
        }
      };
    }
    if (!dataPlanForKitBlocker) {
      if (config.dataPlan && config.dataPlan.document) {
        if (config.dataPlan.document.error_message) {
          kitBlockError = config.dataPlan.document.error_message;
        } else {
          mpInstance.Logger.verbose("Data plan found from mParticle.js");
          dataPlanForKitBlocker = config.dataPlan;
        }
      } else if (config.dataPlanResult) {
        if (config.dataPlanResult.error_message) {
          kitBlockError = config.dataPlanResult.error_message;
        } else {
          mpInstance.Logger.verbose("Data plan found from /config");
          dataPlanForKitBlocker = {
            document: config.dataPlanResult
          };
        }
      }
    }
    if (kitBlockError) {
      mpInstance.Logger.error(kitBlockError);
    }
    if (dataPlanForKitBlocker) {
      kitBlocker = new KitBlocker(dataPlanForKitBlocker, mpInstance);
    }
    return kitBlocker;
  }
  function createIdentityCache(mpInstance) {
    var _a2;
    if ((_a2 = mpInstance._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) {
      return new DisabledVault("".concat(mpInstance._Store.storageName, "-id-cache"));
    }
    return new LocalStorageVault("".concat(mpInstance._Store.storageName, "-id-cache"));
  }
  function runPreConfigFetchInitialization(mpInstance, apiKey, config) {
    mpInstance.Logger = new Logger(config);
    mpInstance._ErrorReportingDispatcher.logger = mpInstance.Logger;
    mpInstance._LoggingDispatcher.logger = mpInstance.Logger;
    mpInstance._Store = new Store(config, mpInstance, apiKey);
    window.mParticle.Store = mpInstance._Store;
    mpInstance.Logger.verbose(StartingInitialization);
    var _a2 = normalizeRoktLauncherOptions(config === null || config === void 0 ? void 0 : config.launcherOptions), noFunctional = _a2.noFunctional, noTargeting = _a2.noTargeting;
    mpInstance._CookieConsentManager = new CookieConsentManager({
      noFunctional,
      noTargeting
    });
    try {
      mpInstance._Store.isLocalStorageAvailable = mpInstance._Persistence.determineLocalStorageAvailability(window.localStorage);
    } catch (e) {
      mpInstance.Logger.warning("localStorage is not available, using cookies if available");
      mpInstance._Store.isLocalStorageAvailable = false;
    }
  }
  function processIdentityCallback(mpInstance, currentUser, currentUserMPID, currentUserIdentities) {
    if (!mpInstance._Store.identifyCalled && mpInstance._Store.SDKConfig.identityCallback && currentUser && currentUserMPID) {
      mpInstance._Store.SDKConfig.identityCallback({
        httpCode: HTTPCodes.activeSession,
        getUser: function getUser() {
          return mpInstance._Identity.mParticleUser(currentUserMPID);
        },
        getPreviousUser: function getPreviousUser() {
          var users = mpInstance.Identity.getUsers();
          var mostRecentUser = users.shift();
          var mostRecentUserMPID = mostRecentUser.getMPID();
          if (mostRecentUser && mostRecentUserMPID === currentUserMPID) {
            mostRecentUser = users.shift();
          }
          return mostRecentUser || null;
        },
        body: {
          mpid: currentUserMPID,
          is_logged_in: mpInstance._Store.isLoggedIn,
          matched_identities: currentUserIdentities,
          context: null,
          is_ephemeral: false
        }
      });
    }
  }
  function queueIfNotInitialized(func, self) {
    var _a2, _b2;
    var noFunctionalWithoutId = ((_a2 = self._CookieConsentManager) === null || _a2 === void 0 ? void 0 : _a2.getNoFunctional()) && !hasExplicitIdentifier(self._Store);
    if (((_b2 = self._Store) === null || _b2 === void 0 ? void 0 : _b2.isInitialized) || noFunctionalWithoutId) {
      return false;
    }
    self._preInit.readyQueue.push(function() {
      var _a3;
      if ((_a3 = self._Store) === null || _a3 === void 0 ? void 0 : _a3.isInitialized) {
        func();
      }
    });
    return true;
  }
  var mockFunction = function mockFunction2() {
    return null;
  };
  var _BatchValidator = (
    /** @class */
    (function() {
      function _BatchValidator2() {
      }
      _BatchValidator2.prototype.getMPInstance = function() {
        return {
          // Certain Helper, Store, and Identity properties need to be mocked to be used in the `returnBatch` method
          _Helpers: {
            sanitizeAttributes: window.mParticle.getInstance()._Helpers.sanitizeAttributes,
            generateHash: function generateHash2() {
              return "mockHash";
            },
            generateUniqueId: function generateUniqueId2() {
              return "mockId";
            },
            extend,
            createServiceUrl: mockFunction,
            parseNumber: mockFunction,
            isObject: mockFunction,
            Validators: null
          },
          _resetForTests: mockFunction,
          _APIClient: null,
          _timeOnSiteTimer: {
            getTimeInForeground: mockFunction
          },
          MPSideloadedKit: null,
          _Consent: null,
          _Events: null,
          _Forwarders: null,
          _NativeSdkHelpers: null,
          _Persistence: null,
          _preInit: null,
          Consent: null,
          _ServerModel: null,
          _SessionManager: null,
          _Store: {
            sessionId: "mockSessionId",
            sideloadedKits: [],
            devToken: "test_dev_token",
            isFirstRun: true,
            isEnabled: true,
            sessionAttributes: {},
            currentSessionMPIDs: [],
            consentState: null,
            clientId: null,
            deviceId: null,
            serverSettings: {},
            dateLastEventSent: null,
            sessionStartDate: null,
            currentPosition: null,
            isTracking: false,
            watchPositionId: null,
            cartProducts: [],
            eventQueue: [],
            currencyCode: null,
            globalTimer: null,
            context: null,
            configurationLoaded: false,
            identityCallInFlight: false,
            nonCurrentUserMPIDs: {},
            identifyCalled: false,
            isLoggedIn: false,
            cookieSyncDates: {},
            integrationAttributes: {},
            requireDelay: true,
            isLocalStorageAvailable: null,
            integrationDelayTimeoutStart: null,
            storageName: null,
            prodStorageName: null,
            activeForwarders: [],
            kits: {},
            configuredForwarders: [],
            pixelConfigurations: [],
            wrapperSDKInfo: {
              name: "none",
              version: null,
              isInfoSet: false
            },
            SDKConfig: {
              isDevelopmentMode: false,
              onCreateBatch: mockFunction
            },
            getTotalTimeOnSite: mockFunction
          },
          config: null,
          eCommerce: null,
          Identity: {
            getCurrentUser: mockFunction,
            IdentityAPI: {},
            identify: mockFunction,
            login: mockFunction,
            logout: mockFunction,
            modify: mockFunction
          },
          Logger: {
            verbose: mockFunction,
            error: mockFunction,
            warning: mockFunction
          },
          ProductActionType: null,
          ServerModel: null,
          addForwarder: mockFunction,
          generateHash: mockFunction,
          getAppVersion: mockFunction,
          getAppName: mockFunction,
          getInstance: mockFunction,
          getDeviceId: mockFunction,
          init: mockFunction,
          logBaseEvent: mockFunction,
          logEvent: mockFunction,
          logLevel: "none",
          setPosition: mockFunction,
          upload: mockFunction
        };
      };
      _BatchValidator2.prototype.createSDKEventFunction = function(event) {
        return new ServerModel(this.getMPInstance()).createEventObject(event);
      };
      _BatchValidator2.prototype.returnBatch = function(events) {
        var _this = this;
        var mpInstance = this.getMPInstance();
        var sdkEvents = Array.isArray(events) ? events.map(function(event) {
          return _this.createSDKEventFunction(event);
        }) : [this.createSDKEventFunction(events)];
        var batch = convertEvents("0", sdkEvents, mpInstance);
        return batch;
      };
      return _BatchValidator2;
    })()
  );
  var MPSideloadedKit = (
    /** @class */
    (function() {
      function MPSideloadedKit2(unregisteredKitInstance) {
        this.filterDictionary = {
          eventTypeFilters: [],
          eventNameFilters: [],
          screenNameFilters: [],
          screenAttributeFilters: [],
          userIdentityFilters: [],
          userAttributeFilters: [],
          attributeFilters: [],
          consentRegulationFilters: [],
          consentRegulationPurposeFilters: [],
          messageTypeFilters: [],
          messageTypeStateFilters: [],
          // The below filtering members are optional, but we instantiate them
          // to simplify public method assignment
          filteringEventAttributeValue: {},
          filteringUserAttributeValue: {},
          filteringConsentRuleValues: {}
        };
        this.kitInstance = unregisteredKitInstance;
      }
      MPSideloadedKit2.prototype.addEventTypeFilter = function(eventType) {
        var hashedEventType = KitFilterHelper.hashEventType(eventType);
        this.filterDictionary.eventTypeFilters.push(hashedEventType);
      };
      MPSideloadedKit2.prototype.addEventNameFilter = function(eventType, eventName) {
        var hashedEventName = KitFilterHelper.hashEventName(eventName, eventType);
        this.filterDictionary.eventNameFilters.push(hashedEventName);
      };
      MPSideloadedKit2.prototype.addEventAttributeFilter = function(eventType, eventName, customAttributeKey) {
        var hashedEventAttribute = KitFilterHelper.hashEventAttributeKey(eventType, eventName, customAttributeKey);
        this.filterDictionary.attributeFilters.push(hashedEventAttribute);
      };
      MPSideloadedKit2.prototype.addScreenNameFilter = function(screenName) {
        var hashedScreenName = KitFilterHelper.hashEventName(screenName, EventType.Unknown);
        this.filterDictionary.screenNameFilters.push(hashedScreenName);
      };
      MPSideloadedKit2.prototype.addScreenAttributeFilter = function(screenName, screenAttribute) {
        var hashedScreenAttribute = KitFilterHelper.hashEventAttributeKey(EventType.Unknown, screenName, screenAttribute);
        this.filterDictionary.screenAttributeFilters.push(hashedScreenAttribute);
      };
      MPSideloadedKit2.prototype.addUserIdentityFilter = function(userIdentity) {
        var hashedIdentityType = KitFilterHelper.hashUserIdentity(userIdentity);
        this.filterDictionary.userIdentityFilters.push(hashedIdentityType);
      };
      MPSideloadedKit2.prototype.addUserAttributeFilter = function(userAttributeKey) {
        var hashedUserAttributeKey = KitFilterHelper.hashUserAttribute(userAttributeKey);
        this.filterDictionary.userAttributeFilters.push(hashedUserAttributeKey);
      };
      return MPSideloadedKit2;
    })()
  );
  if (!Array.prototype.forEach) {
    Array.prototype.forEach = Polyfill.forEach;
  }
  if (!Array.prototype.map) {
    Array.prototype.map = Polyfill.map;
  }
  if (!Array.prototype.filter) {
    Array.prototype.filter = Polyfill.filter;
  }
  if (!Array.isArray) {
    Array.prototype.isArray = Polyfill.isArray;
  }
  function mParticleInstanceManager() {
    var self = this;
    this.Store = {};
    this._instances = {};
    this.IdentityType = IdentityType;
    this.EventType = EventType;
    this.CommerceEventType = CommerceEventType;
    this.PromotionType = PromotionActionType;
    this.ProductActionType = ProductActionType;
    this.RoktEvents = RoktEvents;
    this.MPSideloadedKit = MPSideloadedKit;
    if (typeof window !== "undefined") {
      this.isIOS = window.mParticle && window.mParticle.isIOS ? window.mParticle.isIOS : false;
      this.config = window.mParticle && window.mParticle.config ? window.mParticle.config : {};
    }
    this.init = function(apiKey, config, instanceName) {
      if (!config && window.mParticle && window.mParticle.config) {
        console.warn("You did not pass a config object to mParticle.init(). Attempting to use the window.mParticle.config if it exists. Please note that in a future release, this may not work and mParticle will not initialize properly");
        config = window.mParticle ? window.mParticle.config : {};
      }
      instanceName = (!instanceName || instanceName.length === 0 ? Constants.DefaultInstance : instanceName).toLowerCase();
      var client = self._instances[instanceName];
      if (client === void 0) {
        client = new mParticleInstance(instanceName);
        self._instances[instanceName] = client;
      }
      client.captureTiming(PerformanceMarkType.SdkStart);
      client.setLauncherInstanceGuid();
      client.init(apiKey, config, instanceName);
    };
    this.captureTiming = function(metricsName) {
      self.getInstance().captureTiming(metricsName);
    };
    this.getInstance = function getInstance(instanceName) {
      var client;
      if (!instanceName) {
        instanceName = Constants.DefaultInstance;
        client = self._instances[instanceName];
        if (!client) {
          client = new mParticleInstance(instanceName);
          self._instances[Constants.DefaultInstance] = client;
        }
        return client;
      } else {
        client = self._instances[instanceName.toLowerCase()];
        if (!client) {
          console.log("You tried to initialize an instance named " + instanceName + ". This instance does not exist. Check your instance name or initialize a new instance with this name before calling it.");
          return null;
        }
        return client;
      }
    };
    this.Rokt = self.getInstance()._RoktManager;
    this.getDeviceId = function() {
      return self.getInstance().getDeviceId();
    };
    this.setDeviceId = function(guid) {
      return self.getInstance().setDeviceId(guid);
    };
    this.isInitialized = function() {
      return self.getInstance().isInitialized();
    };
    this.startNewSession = function() {
      self.getInstance().startNewSession();
    };
    this.endSession = function() {
      self.getInstance().endSession();
    };
    this.setLogLevel = function(newLogLevel) {
      self.getInstance().setLogLevel(newLogLevel);
    };
    this.ready = function(argument) {
      self.getInstance().ready(argument);
    };
    this.setAppVersion = function(version2) {
      self.getInstance().setAppVersion(version2);
    };
    this.getAppName = function() {
      return self.getInstance().getAppName();
    };
    this.setAppName = function(name) {
      self.getInstance().setAppName(name);
    };
    this.getAppVersion = function() {
      return self.getInstance().getAppVersion();
    };
    this.getEnvironment = function() {
      return self.getInstance().getEnvironment();
    };
    this.stopTrackingLocation = function() {
      self.getInstance().stopTrackingLocation();
    };
    this.startTrackingLocation = function(callback) {
      self.getInstance().startTrackingLocation(callback);
    };
    this.setPosition = function(lat, lng) {
      self.getInstance().setPosition(lat, lng);
    };
    this.logBaseEvent = function(event, eventOptions) {
      self.getInstance().logBaseEvent(event, eventOptions);
    };
    this.logEvent = function(eventName, eventType, eventInfo, customFlags, eventOptions) {
      self.getInstance().logEvent(eventName, eventType, eventInfo, customFlags, eventOptions);
    };
    this.logError = function(error, attrs) {
      self.getInstance().logError(error, attrs);
    };
    this.logLink = function(selector, eventName, eventType, eventInfo) {
      self.getInstance().logLink(selector, eventName, eventType, eventInfo);
    };
    this.logForm = function(selector, eventName, eventType, eventInfo) {
      self.getInstance().logForm(selector, eventName, eventType, eventInfo);
    };
    this.logPageView = function(eventName, attrs, customFlags, eventOptions) {
      self.getInstance().logPageView(eventName, attrs, customFlags, eventOptions);
    };
    this.upload = function() {
      self.getInstance().upload();
    };
    this.eCommerce = {
      Cart: {
        add: function add(product, logEventBoolean) {
          self.getInstance().eCommerce.Cart.add(product, logEventBoolean);
        },
        remove: function remove(product, logEventBoolean) {
          self.getInstance().eCommerce.Cart.remove(product, logEventBoolean);
        },
        clear: function clear() {
          self.getInstance().eCommerce.Cart.clear();
        }
      },
      setCurrencyCode: function setCurrencyCode(code) {
        self.getInstance().eCommerce.setCurrencyCode(code);
      },
      createProduct: function createProduct(name, sku, price, quantity, variant, category, brand, position, coupon, attributes) {
        return self.getInstance().eCommerce.createProduct(name, sku, price, quantity, variant, category, brand, position, coupon, attributes);
      },
      createPromotion: function createPromotion(id, creative, name, position) {
        return self.getInstance().eCommerce.createPromotion(id, creative, name, position);
      },
      createImpression: function createImpression(name, product) {
        return self.getInstance().eCommerce.createImpression(name, product);
      },
      createTransactionAttributes: function createTransactionAttributes(id, affiliation, couponCode, revenue, shipping, tax) {
        return self.getInstance().eCommerce.createTransactionAttributes(id, affiliation, couponCode, revenue, shipping, tax);
      },
      logCheckout: function logCheckout(step, options, attrs, customFlags) {
        self.getInstance().eCommerce.logCheckout(step, options, attrs, customFlags);
      },
      logProductAction: function logProductAction(productActionType, product, attrs, customFlags, transactionAttributes, eventOptions) {
        self.getInstance().eCommerce.logProductAction(productActionType, product, attrs, customFlags, transactionAttributes, eventOptions);
      },
      logPurchase: function logPurchase(transactionAttributes, product, clearCart, attrs, customFlags) {
        self.getInstance().eCommerce.logPurchase(transactionAttributes, product, clearCart, attrs, customFlags);
      },
      logPromotion: function logPromotion(type, promotion, attrs, customFlags, eventOptions) {
        self.getInstance().eCommerce.logPromotion(type, promotion, attrs, customFlags, eventOptions);
      },
      logImpression: function logImpression(impression, attrs, customFlags, eventOptions) {
        self.getInstance().eCommerce.logImpression(impression, attrs, customFlags, eventOptions);
      },
      logRefund: function logRefund(transactionAttributes, product, clearCart, attrs, customFlags) {
        self.getInstance().eCommerce.logRefund(transactionAttributes, product, clearCart, attrs, customFlags);
      },
      expandCommerceEvent: function expandCommerceEvent(event) {
        return self.getInstance().eCommerce.expandCommerceEvent(event);
      }
    };
    this.setSessionAttribute = function(key, value) {
      self.getInstance().setSessionAttribute(key, value);
    };
    this.setOptOut = function(isOptingOut) {
      self.getInstance().setOptOut(isOptingOut);
    };
    this.setIntegrationAttribute = function(integrationId, attrs) {
      self.getInstance().setIntegrationAttribute(integrationId, attrs);
    };
    this.getIntegrationAttributes = function(moduleId) {
      return self.getInstance().getIntegrationAttributes(moduleId);
    };
    this.Identity = {
      HTTPCodes: Constants.HTTPCodes,
      aliasUsers: function aliasUsers(aliasRequest, callback) {
        self.getInstance().Identity.aliasUsers(aliasRequest, callback);
      },
      createAliasRequest: function createAliasRequest(sourceUser, destinationUser, scope) {
        return self.getInstance().Identity.createAliasRequest(sourceUser, destinationUser, scope);
      },
      getCurrentUser: function getCurrentUser() {
        return self.getInstance().Identity.getCurrentUser();
      },
      getUser: function getUser(mpid) {
        return self.getInstance().Identity.getUser(mpid);
      },
      getUsers: function getUsers() {
        return self.getInstance().Identity.getUsers();
      },
      identify: function identify(identityApiData, callback) {
        self.getInstance().Identity.identify(identityApiData, callback);
      },
      login: function login(identityApiData, callback) {
        self.getInstance().Identity.login(identityApiData, callback);
      },
      logout: function logout(identityApiData, callback) {
        self.getInstance().Identity.logout(identityApiData, callback);
      },
      modify: function modify(identityApiData, callback) {
        self.getInstance().Identity.modify(identityApiData, callback);
      },
      search: function search(workspaceApiKey, knownIdentities, callback) {
        self.getInstance().Identity.search(workspaceApiKey, knownIdentities, callback);
      }
    };
    this.sessionManager = {
      getSession: function getSession() {
        return self.getInstance()._SessionManager.getSessionId();
      }
    };
    this.Consent = {
      createConsentState: function createConsentState() {
        return self.getInstance().Consent.createConsentState();
      },
      createGDPRConsent: function createGDPRConsent(consented, timestamp, consentDocument, location2, hardwareId) {
        return self.getInstance().Consent.createGDPRConsent(consented, timestamp, consentDocument, location2, hardwareId);
      },
      createCCPAConsent: function createCCPAConsent(consented, timestamp, consentDocument, location2, hardwareId) {
        return self.getInstance().Consent.createGDPRConsent(consented, timestamp, consentDocument, location2, hardwareId);
      }
    };
    this.reset = function() {
      self.getInstance().reset(self.getInstance());
    };
    this._resetForTests = function(MPConfig, keepPersistence) {
      if (typeof keepPersistence === "boolean") {
        self.getInstance()._resetForTests(MPConfig, keepPersistence, self.getInstance());
      } else {
        self.getInstance()._resetForTests(MPConfig, false, self.getInstance());
      }
    };
    this.configurePixel = function(settings) {
      self.getInstance().configurePixel(settings);
    };
    this._setIntegrationDelay = function(moduleId, _boolean) {
      self.getInstance()._setIntegrationDelay(moduleId, _boolean);
    };
    this._getIntegrationDelays = function() {
      return self.getInstance()._getIntegrationDelays();
    };
    this.getVersion = function() {
      return self.getInstance().getVersion();
    };
    this.generateHash = function(string) {
      return self.getInstance().generateHash(string);
    };
    this.addForwarder = function(forwarder) {
      self.getInstance().addForwarder(forwarder);
    };
    this._getActiveForwarders = function() {
      return self.getInstance()._getActiveForwarders();
    };
    this._setWrapperSDKInfo = function(name, version2) {
      self.getInstance()._setWrapperSDKInfo(name, version2);
    };
    this._registerErrorReportingService = function(service) {
      self.getInstance()._registerErrorReportingService(service);
    };
    this._registerLoggingService = function(service) {
      self.getInstance()._registerLoggingService(service);
    };
  }
  var mParticleManager = new mParticleInstanceManager();
  if (typeof window !== "undefined") {
    window.mParticle = mParticleManager;
    window.mParticle._BatchValidator = new _BatchValidator();
  }
  return mParticleManager;
})();
