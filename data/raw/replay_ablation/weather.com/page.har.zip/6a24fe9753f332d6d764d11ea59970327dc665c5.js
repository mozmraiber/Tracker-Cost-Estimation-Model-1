

if (typeof _tb_dis === 'undefined' || _tb_dis === null) {
    var _tb_dis = false;
}
if (!_tb_dis) {
    var pm_ppy = "theweatherchannel";

    var _pmep = '//pm-widget.taboola.com/';
    var _pmep_geo = '//pm-widget.taboola.com/';
    if (document.URL.indexOf('https://') > -1) {
        _pmep = _pmep.replace(/88\//gi, '90/');
        _pmep_geo = _pmep_geo.replace(/88\//gi, '90/');
    }
    var _pmpmk = pm_ppy + '/pmk-20220605.44.js';
    var _pmasync = true;
    var _pmoptimization = true;
    var _pmoptimizationmanipulation = true;
    var _pmhp = false;
    var _pmsb = false;

    function _pmloadfile(fileName) {

        if (_pmasync) {
            var js, elements = document.getElementsByTagName("head")[0];
            js = document.createElement("script");
            js.setAttribute("type", "text/javascript");
            js.setAttribute("src", fileName);
            js.setAttribute('async','');
            js.setAttribute('crossorigin', 'anonymous');
            elements.appendChild(js);
        } else {
            document.writeln('<script src=' + fileName + '></script>');
        }
    }

    var pmk, pmglb, pmfa, pmad, pmdebug_c;
    pmglb = pmglb || null;
    pmfa = pmfa || null;
    pmad = pmad || null;
    pmdebug_c = pmdebug_c || null;
    pmk = pmk || null;
    var _pmenv = _tb_getUrlParameter('pmenv');
    //pm async
    var _pma = _tb_getUrlParameter('_pma');
    if (_pma == true) {
        _pmasync = true;
    }

    if (_pmenv && _pmenv == 'sandbox' && !_pmsb) {

        _pmep = '//pm-widget-sandbox.taboola.com/';
        _pmep_geo = '//pm-widget-sandbox.taboola.com/';
        var _tb_d = new Date();
        var _tb_rand = _tb_d.getTime();
        _pmpmk = pm_ppy + "/load.js?" + _tb_rand;
    }

    (function () {
        var sc = 'script', doc = document;
        _pmloadfile(_pmep + _pmpmk);
    })();
    function pmws_request_done() {
        var sc = "script", doc = document;
        if (doc.all && !window.opera) {
            doc.write('<' + sc + ' type="text/javascript" id="pm_contentloadtag" defer="defer" src="javascript:void(0)"><\/' + sc + '>');
            var pm_contentloadtag = doc.getElementById("pm_contentloadtag");
            if (pm_contentloadtag)pm_contentloadtag.onreadystatechange = function () {
                if (this.readyState == "complete") return;
            }
        }
        _pmloadfile(_pmep + _pmpmk);
    }


    function _tb_getUrlParameter(name) {
        var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
        return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
    }


     /** Generated CJS **/ var _pm_ecd = {
     'at': '//meta[@property="article:author"]/@content',
     'ablw': ['Von', 'Par', 'Por', 'Door'],
     'opd': ['author']
};


var _tb_vpx = [{
    'xpath': '//div[contains(@class, "jwplayer")]//div[contains(@style, "background-image")]',
    'attr': 'div',
    clickToPlayXPath: [{
            'xpath': '//div[contains(@class, "jwplayer")]',
            'attr': 'div'
        }
    ]
},
{
    xpath: '//div[contains(@class, "akamai-video")]',
    attr: "div"
}
];

/** Generated CJS end **/ 
}