!function(){"use strict";const e="turnstile_verified",t="turnstile_failed";(new URLSearchParams(window.location.search).get("turnstile_is_bot")??"")&&(sessionStorage.removeItem(t),localStorage.removeItem(e)),(()=>{const e=new URL(window.location.href);if(!e.pathname.startsWith("/events/"))return;const t=e.hostname,n=["promo","ref","utm_campaign","utm_content","utm_medium","utm_source","utm_term"].filter((t=>e.searchParams.has(t)));if(!n.length)return;const o=t=>{let o=t.getAttribute("href");o&&(t.dataset.trackingParamsApplied||(n.forEach((t=>{const n=e.searchParams.get(t);if(n&&!o.includes(`${t}=`)){const e=o.includes("?")?"&":"?";o+=`${e}${t}=${n}`}})),t.setAttribute("href",o),t.dataset.trackingParamsApplied="true"))},r=(e=document)=>{e.querySelectorAll(`a[href^="https://${t}/events"], a[href^="/events/"]`).forEach(o)};r();const s=new MutationObserver((function(e){e.forEach((e=>{e.addedNodes.forEach((e=>{e.nodeType===Node.ELEMENT_NODE&&(e.matches?.("a")?r(e.parentNode):r(e))}))}))}));(()=>{const e=document.body||document.documentElement||document;try{s.observe(e,{childList:!0,subtree:!0})}catch(e){document.addEventListener("DOMContentLoaded",(()=>{document.body&&s.observe(document.body,{childList:!0,subtree:!0})}),{once:!0})}})()})()}();;
(function ($) {
	"use strict";
	$(function () {
		$('#sailthru-modal').hide();

		$( ".show_shortcode" ).on( "click", function( e ) {
			e.preventDefault();
			var posTop = $(this).offset().top;
			var modal = $( "#sailthru-modal");
			modal.css("top", '100px');
			modal.css("left", Math.max(0, (($(window).width() - $(modal).outerWidth()) / 2) + $(window).scrollLeft()) + "px");

			$('.sailthru_shortcode_hidden .sailthru-signup-widget-close').show();
			modal.fadeIn();
		});

		$('#sailthru-modal .sailthru-signup-widget-close').click(function(){
			$('#sailthru-modal ').fadeOut();
		}) ;

		// when a user clicks subscribe
		$(".sailthru-add-subscriber-form").submit(async function(e){

			e.preventDefault();
			var recaptcha = $("#sailthruToken");
			var siteKey = $("#siteKey").val();
			if (!recaptcha.val() && siteKey) {
				var token = await grecaptcha.execute(siteKey, {action: 'homepage'});
				recaptcha.val(token);
			}

			var user_input = $(this).serialize();
			var form = $(this);
			$.ajax({
				url: sailthru_vars.ajaxurl,
				type: 'post',
				data: user_input,
				dataType: "json",
				xhrFields: {
					withCredentials: true
				},
				success: function (data, status) {
					if (data.success == false) {
						$('#' + form.attr('id') + " .sailthru-add-subscriber-errors").html(data.message);
					} else {
						$('#sailthru-modal .sailthru-signup-widget-close').fadeIn();
						$(form).html('');
						$(form).parent().find(".success").show();
						$(form).parent().find(".hide_toggle").hide();
					}
				}
			});

		});

	});
}(jQuery));
;
