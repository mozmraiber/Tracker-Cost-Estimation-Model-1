window.__jwpcslAbConfig = {"schemaVersion":1,"projects":{"vertical-video":{},"mock-service":{}},"updatedAt":"2026-08-06T06:10:03.712Z"};
